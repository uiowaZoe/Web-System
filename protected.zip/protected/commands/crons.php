<?php
//define('MEICAI_ENV', 'env');
define('SYSTEM_LOG_PATH', '/data/log/command-center');
error_reporting(E_ALL | E_STRICT);

// change the following paths if necessary
$yii=dirname(__FILE__).'/../../../framework/yii.php';
//$yiic=dirname(__FILE__).'/../../../framework/yiic.php';
$config=dirname(__FILE__).'/../config/env/console.php';
// remove the following lines when in production mode
//defined('YII_DEBUG') or define('YII_DEBUG',true);
// specify how many levels of call stack should be shown in each log message
defined('YII_TRACE_LEVEL') or define('YII_TRACE_LEVEL',3);

require_once($yii);
//require_once($yiic);
//require_once(dirname(__FILE__).'/../service/ccenter/predict/PredictFlushService.php');
//require_once(dirname(__FILE__).'/../service/ccenter/SystemSetService.php');
Yii::createConsoleApplication($config)->run();
