<?php
class TestCommand extends CConsoleCommand
{
	public function run($args) {
		//todo
if(isset($args[0])){

		print_r($args[0]); 
	}
else{
echo 'no params';
}
}}
