<?php
require_once(dirname(__FILE__).'/../service/ccenter/predict/PredictFlushService.php');
require_once(dirname(__FILE__).'/../service/ccenter/SystemSetService.php');
class PercentCommand extends CConsoleCommand
{
	public function run($distribute_t_arg) {
		//todo
		echo "test";
	$service = new PredictFlushService();
        if (isset($distribute_t_arg[0]))
        {
            $distribute_t = $distribute_t_arg[0];
        }else{
        	$distribute_t = CCPubService::getDefaultDistributeDate();
        }
       // echo $distribute_t;
        //$deliveryTime = strtotime($distribute_t);
        $result = $service->percent_v2($distribute_t);
        echo json_encode($result, true);
	}
}
