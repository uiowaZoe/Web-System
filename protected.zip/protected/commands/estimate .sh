#!/bin/bash
echo 'hello'
begin_date=$1
end_date=$2
unix_begin_date=`date -d "$begin_date" +%s`
unix_end_date=`date -d "$end_date" +%s`
echo $unix_begin_date
echo $unix_end_date
for((i=$unix_begin_date;i<$unix_end_date;i+=24*3600));
do
str_time=`date -d @$i +%F`
/usr/bin/php /data/www/command-center/protected/commands/crons.php percent "$str_time"
/usr/bin/php /data/www/command-center/protected/commands/crons.php estimate "$str_time"
echo $str_time
done
