<?php
require_once(dirname(__FILE__).'/../service/ccenter/predict/PredictFlushService.php');
require_once(dirname(__FILE__).'/../service/ccenter/SystemSetService.php');
class PreProcessCommand extends CConsoleCommand
{
	public function run($distribute_t_arg) {
		//todo
		echo "test";
	$service = new PredictFlushService();
        if (isset($distribute_t_arg[0]))
        {
            $distribute_t = $distribute_t_arg[0];
        }else{
        	$distribute_t = CCPubService::getDefaultDistributeDate();
        }
        if(isset($distribute_t_arg[1])){
        	$num_days = $distribute_t_arg[1];
        }else{
        	$num_days = 0;
        }
       // echo $distribute_t;
        //$deliveryTime = strtotime($distribute_t);
        $result = $service->preprocessing($distribute_t, $num_days);
        echo json_encode($result, true);
	}
}
