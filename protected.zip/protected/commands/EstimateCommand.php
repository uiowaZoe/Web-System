<?php
require_once(dirname(__FILE__).'/../service/ccenter/predict/PredictFlushService.php');
require_once(dirname(__FILE__).'/../service/ccenter/SystemSetService.php');
class EstimateCommand extends CConsoleCommand
{
	public function run($distribute_t_arg) {
		//todo
		echo "test";
		   $service = new PredictFlushService();
      //  $param = array();
        $get_cur_hour = false;
        $hour = 0;
        if (isset($distribute_t_arg[0]))
        {
            $distribute_t = $distribute_t_arg[0];//存在
            if(isset($distribute_t_arg[1])){
            	$hour = $distribute_t_arg[1];
            	$get_cur_hour = true;
            }else{
            	$get_cur_hour = false;
            }
        }else{
        	$distribute_t = CCPubService::getDefaultDistributeDate();
        	$get_cur_hour = true;
        	$hour = date('H', time());
        }
       // $param['predict_t'] = $distribute_t;
        //echo $hour;
       // exit(1);
       // echo $distribute_t;
        //$deliveryTime = strtotime($distribute_t);
        $result = $service->estimate_v2($distribute_t, $hour, $get_cur_hour);
        echo json_encode($result, true);
	}
}
