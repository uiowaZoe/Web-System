#!/bin/bash
five_day=`date +%Y-%m-%d -d "5 days ago "`
cur_hour=`date +%H -d "5 days ago "`
echo $cur_hour
echo $five_day
/usr/bin/php /data/www/command-center/protected/commands/crons.php preprocess "$five_day"


