<?php

require_once dirname(__FILE__) . '/AuthHttpClient.php';

class MeicaiAuth
{
    public static $user_info = null;
    public static $access = false;

    /**
     * 登录功能
     * @param   email       登录所需邮箱
     * @param   password    用户密码
     * @param   system_key  子系统key
     */
    public static function login($email, $password, $system_key)
    {
        $result = self::callService('/adminuser/login',
            array(
                'email' => $email,
                'password' => $password,
                'system_key' => $system_key
            ));
        return $result;
    }

    /**
     * 退出登录方法
     */
    public static function logout($user_token)
    {
        $result = self::callService('/adminuser/logout',
            array(
                'user_token' => $user_token
            ));
        return $result;
    }


    public static function getUser($user_token)
    {
        if (empty($user_token))
            return null;
        $result = self::callService('/user/tokeninfo', array(
            'user_token' => $user_token,
        ));
        if ($result['ret'] == 1)
            $user_info = $result['data'];
        else
            $user_info = null;
        return $user_info;
    }

    public static function switchCity($token, $city_id)
    {
        $result = self::callService('/adminuser/switchcity', array(
            'user_token' => $token,
            'city_id' => $city_id));
        return $result;
    }

    /**
     * 检查权限
     * @param   user_token  用户token
     * @param   entry         用户访问地址entry, 如/user/login
     * @param   system_key  子系统对应的key
     * @return  boolean
     */
    public static function checkAccess($user_token, $entry, $system_key, $params = array())
    {
        if (empty($user_token) || empty($entry) || empty($system_key))
            return false;
        $params = self::filterParams($params);
        $result = self::callService('/adminuser/checkaccess', array(
            'user_token' => $user_token,
            'entry' => $entry,
            'system_key' => $system_key,
            'params' => $params,
        ));
        $return_data = array();
        if ($result['ret'] == 1) {
            $return_data['code'] = 0;
            $return_data['user_info'] = $result['data']['user_info'];
            $return_data['access'] = $result['data']['access'];
        } else {
            $return_data['code'] = 1;
            $return_data['user_info'] = null;
            $return_data['access'] = false;
        }
        return $return_data;
    }

    /**
     * 整合SSO统一登录方法
     */
    public static function loginSSO()
    {
        $controller = Yii::app()->controller;
        if (empty($_COOKIE[MEICAI_AUTH_TOKEN_NAME])) {
            $controller->redirect(MEICAI_AUTH_LOGIN_URL);
        } else {
            $token = $_COOKIE[MEICAI_AUTH_TOKEN_NAME];
            $entry = self::getPathInfo();
            $check_result = self::checkAccess($token, $entry, MEICAI_SYSTEM_KEY);
            if ($check_result['code'] == 0) {
                if (empty($check_result['user_info']))
                    $controller->redirect(MEICAI_AUTH_LOGIN_URL);
                self::$user_info = $check_result['user_info'];
                self::$access = $check_result['access'];
            }

            return $check_result;
        }
    }

    /**
     * 退出登录方法
     */
    public static function logoutSSO()
    {
        $controller = Yii::app()->controller;
        $controller->redirect(MEICAI_AUTH_LOGOUT_URL);
    }

    /**
     * api调用
     * @param   api     要调用的api
     * @param   params  调用参数
     * @param   server  api server
     */
    public static function callService($api, $params = array(), $server = MEICAI_AUTH_SERVER)
    {
        if (empty($api))
            return false;
        $url = $server . $api;

        $client = new AuthHttpClient();
        if (defined("MEICAI_AUTH_TIMEOUT"))
            $client->setTimeout(MEICAI_AUTH_TIMEOUT);
        $result = $client->post($url, $params);

        $json = json_decode($result, true);
        return $json;
    }

    /**
     * @param $params Array
     * 过滤参数
     */
    private static function filterParams($params)
    {
        if (empty($params) || !is_array($params))
            return $params;

        $keys = array('city_id');
        $result = array();
        foreach ($keys as $key)
            $result[$key] = $params[$key];

        return $result;
    }

    public static function getPathInfo()
    {
        $pathinfo = '/' . Yii::app()->urlManager->parseUrl(Yii::app()->request);
        $pathinfo = strtolower($pathinfo);
        $infos = explode('/', $pathinfo);
        if (empty($infos[1])) {
            $infos[1] = 'site';
            $infos[2] = 'index';

        } elseif (empty($infos[2])) {
            $infos[2] = 'index';

        }
        $entry = '/' . $infos[1] . '/' . $infos[2];
        $entry = strtolower($entry);
        return $entry;
    }

    public static function listAccessByTokenAndKey($user_token, $system_key)
    {
        $result = self::callService('/role/listaccessbytokenandkey', array(
            'user_token' => $user_token,
            'system_key' => $system_key,
        ));
        return $result;
    }
}
