<?php

class AuthHttpClient
{
    public $timeout = 30;

    function __construct()
    {
        $this->init();
    }

    function __destruct()
    {
        curl_close($this->ch);
    }

    public function init()
    {
        $this->ch = curl_init();
        curl_setopt($this->ch, CURLOPT_TIMEOUT, $this->timeout);
    }

    public function get($url, $params = array())
    {
        $url = $this->createUrl($url, $params);

        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($this->ch);

        return $result;
    }

    public function post($url, $data = array())
    {
        $url = $this->createUrl($url);

        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_POST, true);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);

        if (!empty($data)) {
            $body = http_build_query($data);
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, $body);
        }

        $result = curl_exec($this->ch);
        return $result;
    }

    public function setCookies($cookies)
    {
        if (!empty($cookies) && is_array($cookies)) {
            $string = http_build_query($cookies);
            curl_setopt($this->ch, CURLOPT_COOKIE, $string);
            return true;
        } else {
            return false;
        }
    }

    public function createUrl($url, $params = array())
    {
        $tmp = trim($url);
        if (strpos($url, 'http://') !== 0 && strpos($url, 'https://') !== 0)
            $tmp = 'http://' . $tmp;

        if (!empty($params))
            $tmp .= '?' . http_build_query($params);
        return $tmp;
    }

    public function setTimeout($timeout)
    {
        if (is_numeric($timeout) && $timeout >= 0){
            $this->timeout = intval($timeout);
            curl_setopt($this->ch, CURLOPT_TIMEOUT, $this->timeout);
        }
    }
}
