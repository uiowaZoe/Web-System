<?php

/**
 * Controller is the customized base controller class.
 * All controller classes for this application should extend from this base class.
 */
class Controller extends CController
{

    # 用户信息
    public $user_info = array();
    public $layout = '//layouts/main';

    # 覆写init方法
    public function init()
    {
        /*$this->user_info = $this->_getUserInfo();
        if (empty($this->user_info)) {
            # code...
            header('location:/web/login.html');
            exit;
        }*/
        $check_result = MeicaiAuth::loginSSO();
        $this->user_info = $check_result['user_info'];
       // var_dump(  $this->user_info );
    }

    # 获取用户信息
    private function _getUserInfo()
    {
        $user_info = array();
        # 获取用户utoken
        $cookie = Yii::app()->request->cookies['utoken'];
        if ($cookie->value) {
            $param = array('user_token' => $cookie->value);
            $res = HttpClient::post(USER_INFO_URL, $param);
            if ($res['ret'] == 1) {
                $user_info = $res['data'];
            }
        }
        return $user_info;
    }


}
