<?php
/**
 * 内部接收notice继承的控制器，只允许内部服务器调用
 * User: hw
 * Date: 15-5-21
 * Time: 下午7:58
 */

class NoticeController extends ApiController
{
    public function init()
    {
        parent::init();
    }

    public function log()
    {
        $data = $_SERVER['REQUEST_METHOD'] == 'POST' && $this->getRawData() ? $this->getRawData() : $_REQUEST;
        $log = "\nMETHOD: ".$_SERVER['REQUEST_METHOD']."\r\nURL: ".$_SERVER['REQUEST_URI']."\r\nDATA: ".var_export($data, true);
        Yii::log($log, CLogger::LEVEL_INFO, 'meicai.system.access.notice');
    }

    public function getRawData()
    {
        $data = parent::getRawData();
        return isset($data['message']) ? $data['message'] : array();
    }
}