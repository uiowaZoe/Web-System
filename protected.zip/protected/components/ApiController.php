<?php
/**
 * 内部api继承的控制器，只允许内部服务器调用
 * User: hw
 * Date: 15-5-13
 * Time: 下午3:50
 */


class ApiController extends CController
{
    protected $params = array();

    /**
     * init
     */
    public function init()
    {
        $this->checkAccess();
        $this->params = $this->getRawData();
        $this->log();
    }

    /**
     * 检查来源，禁止外部请求直接访问
     */
    public function checkAccess(){
        $client_ip  = HttpClient::getIP();
        if (!HttpClient::isPrivateIP(ip2long($client_ip)))
        {
            $this->renderError('禁止外部访问!');
        }
    }

    public function log()
    {
        $data = $_SERVER['REQUEST_METHOD'] == 'POST' && $this->params ? $this->params : $_REQUEST;
        $log = "\nMETHOD: ".$_SERVER['REQUEST_METHOD']."\r\nURL: ".$_SERVER['REQUEST_URI']."\r\nDATA: ".var_export($data, true);
        Yii::log($log, CLogger::LEVEL_INFO, 'meicai.system.access.api');
    }

    /**
     * Render Json to front app
     *
     * @param $a
     */
    public function renderJson($a)
    {
        header("Content-type:application/json;charset=utf-8");
        $r['ret']   = 1;
        $r['data']  = $a;
        echo json_encode($r);
        exit;
    }

    /**
     * reutrn json error
     *
     * @param $msg
     */
    public function renderError($msg, $code = 0)
    {
        header("Content-type:application/json;charset=utf-8");
        $a['ret']   = 0;
        $a['error'] = array('code' => $code, 'msg' => $msg);
        echo json_encode($a);
        exit;
    }

    public function renderPage($data, $page_info) {
        $data['total_pages']    = ceil($data['total'] / $page_info['per_page']);
        $data['per_page']       = $page_info['per_page'];
        $data['page']           = $page_info['page'];
        $this->renderJson($data);
    }

    public function pageInfo() {
        $info['per_page']   = max(1, (int) Util::getDefault($this->params, 'per_page', 20));
        $info['page']       = max(1, (int) Util::getDefault($this->params, 'page', 1));
        $info['start']      = ($info['page'] - 1) * $info['per_page'];
        $info['limit']      = $info['per_page'];
        return $info;
    }

    /**
     * 统一异常处理
     * add by panzhiqi
     */
    public function runAction($action) {
        try{
            parent::runAction($action);
        }
        catch (ServiceException $e){
            $this->renderError($e->getMessage(), $e->getCode());
        }
        catch (Exception $e) {
            $this->renderError($e->getMessage(), $e->getCode());
        }
    }

    public function checkEmpty()
    {
        $arr = func_get_args();
        foreach($arr as $v) {
            if (empty($_POST[$v])){
                $this->renderError($v . ' is empty');
            }
        }
    }

    public function checkParams($params)
    {
        if ($params === null) return null;
        else {
            $postStr = $this->getRawData();
            foreach ($params as $key => $value) {
                if (!isset($postStr[$key]) || $postStr[$key] === '') {
                    if (!empty($value['required'])) {
                        //必填
                        return $this->renderError('缺少参数 ' . $key);
                    }
                    if (isset($value['default'])) {
                        $postStr[$key] = $value['default'];
                    }
                } else {
                    //类型验证
                    if (isset($value['int']) && $value['int']) {
                        if (!is_numeric($postStr[$key])) {
                            return $this->renderError('参数类型不对 ' . $key);
                        }
                    }
                }
            }


            return $postStr;

        }
    }

    public  function  getRawData()
    {

        $method = Yii::app()->request->getRequestType();

        $decode = false;
        if ($method == 'POST') {
            $postStr = file_get_contents("php://input");
            $decode = true;
        } else {
            $postStr = $_GET;
        }
        if (empty($postStr)) {
            return $this->renderError('缺少请求参数');
        } else {
            if ($decode) {
                $postStr = json_decode((string)$postStr, true);
                switch (json_last_error()) {
                    case JSON_ERROR_NONE:
                        break;
                    case JSON_ERROR_DEPTH:

                    case JSON_ERROR_CTRL_CHAR:

                    case JSON_ERROR_SYNTAX:

                    case JSON_ERROR_STATE_MISMATCH:

                    case JSON_ERROR_UTF8:

                    default:
                        throw new Exception('json格式转换错误');
                }
            }
        }
        return $postStr;
    }
}
