<?php
/**
 * Created by PhpStorm.
 * User: wangbiwen
 * Date: 2015/9/15
 * Time: 12:01
 */

class Job extends EMongoDocument {
    public $_id;
    public $user;
    public $c_t;
    public $u_t;
    public $single;
    public $crontabtime;
    public $cmd;
  //  public $jobid;

    public static function model($className = __CLASS__){
        return parent::model($className);
    }

    public function getCollectionName()
    {
        return 'Job';
    }

    public function addInfo($crontabtime,$cmd,$user,$c_t,$u_t,$single) {

        $this->crontabtime=$crontabtime;
        $this->cmd=$cmd;
        $this->user=$user;
        $this->c_t=$c_t;
        $this->u_t=$u_t;
        $this->single=$single;
        $this->save();
    }


    public function  detailInfo($_id){



    }
    
    public function  editInfo($_id,$crontabtime,$cmd,$user,$c_t,$u_t,$single){

        $update=$this->findByPk($_id);
        $update->crontabtime=$crontabtime;
        $update->cmd=$cmd;
        $update->user=$user;
        $update->c_t=$c_t;
        $update->u_t=$u_t;
        $update->single=$single;
        $update->save();//保存...
    }

    // 删除(提示安全问题)
    public  function  delInfo($_id){
        $id=$_id;
        $this->deleteByPk(new MongoId($id));
    }
}