<?php
/**
 * Created by PhpStorm.
 * User: bgl
 * Date: 2015/9/16
 * Time: 11:05
 */
class JobLog extends EMongoDocument {
    public $_id;
    public $user;
    public $c_t;
    public $u_t;
   // public $single;
    public $result;
    public $runtime;
    public $cr_t;
    public $jobid;

    public static function model($className = __CLASS__){
        return parent::model($className);
    }

    public function getCollectionName()
    {
        return 'JobLog';
    }




}