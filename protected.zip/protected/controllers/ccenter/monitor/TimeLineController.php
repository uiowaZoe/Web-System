<?php

/**
 * 分拣监控页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class TimeLineController extends Controller
{
    public $layout = '//layouts/main';

    # 新建群发任务页面
    public function ActionPage()
    {
        $para = CCPubService::getPara();
        $city_list = CCPubService::getCityList( $this->user_info);

        $class1_list = CCPubService::getClass1List_goods();
        $class2_list = CCPubService::getClass2List_goods();
        $first_city = CCPubService::getFirstCity($this->user_info);

        $this->render('page', array(
            'first_city'=>$first_city,
            'city_list' => $city_list,
            'warehouselist' => json_encode(CCPubService::getWarehouseList($this->user_info)),
            'class1_list' => $class1_list,
            'class2_list' => json_encode($class2_list),
            'weight_rows' => [],
            'xAxis' => [],
            'frate' => [],
            'distribute_t' =>CCPubService::getDefaultDistributeDate(),
            'flushinterval' =>SystemSetService::getSystemKey("flushinter"),
            'good_list' => CCPubService::getClassList(),
            'city' => $para["city"]
        ));
    }

    public function actionSearch()
    {

        $para = CCPubService::getPara();
        $startTimeInt = strtotime($para["distribute_t"]);
        $xAxis = CCPubService::getTimeLineX($startTimeInt);
        //模拟完成百分比数据（静态）

        $yData = TimeLineService::getTimeLineData($para["delivery_time"], $para["city"], $para["warehouse"], $para["class1"], $para["class2"],$this->user_info);

        //  var_dump($rows);
        echo json_encode(array(
            'xAxis' => $xAxis,
            'data' => $yData
        ), true);
    }

    public function actionNow()
    {
        $para = CCPubService::getPara();
        $startTimeInt = strtotime($para["distribute_t"]);
        $nowData = TimeLineService::getNowData($para["delivery_time"], $para["city"], $para["warehouse"], $para["class1"], $para["class2"],$this->user_info);
        //  var_dump($rows);
        echo json_encode(array(
            'nowdata' => $nowData,
            'nowtime'=>date("Y-m-d H:i:s", time())
        ), true);
    }

}

