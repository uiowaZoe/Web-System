
<?php
/**
 * Created by PhpStorm.
 * User: guanzhongyang
 * Date: 2015/9/23
 * Time: 11:32
 */
class SystemDataController extends Controller
{
    public $layout = '//layouts/main';

    public function  ActionsystemData()
    {
        //$flush_list=["0","1"];
        $this->render('systemData');
    }

    public function Actiongetdata()
    {
        $list =systemDataService::getData();
        echo json_encode($list,true);
    }

    public function Actionedit()
    {
        $sname = $_GET['sname'];
        $svalue = $_GET["svalue"];
        $skey = $_GET["skey"];
        systemDataService::edit($skey,$sname,$svalue);
        $list =systemDataService::getData();
        echo json_encode($list,true);
    }
}