<?php

/**
 * 分拣监控页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class DataFlushController extends Controller
{
    public $layout = '//layouts/main';

    # 新建群发任务页面
    public function ActionPage()
    {
        $result = SystemSetService::getSystemKey("dataflush");
        $this->render('page', array('distribute_t' => CCPubService::getDefaultDistributeDate(),
            'flushinterval' =>SystemSetService::getSystemKey("flushinter"),
            'dataflush' => $result
        ));
    }

    public function  actionDisplay()
    {
        $service = new DataFlushService();
        $distribute_t = CCPubService::getDefaultDistributeDate();
        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $deliveryTime = strtotime($distribute_t);
        $result = $service->datadisplay($deliveryTime);
        echo json_encode($result, true);

    }

    public function  actionFlush()
    {


        $service = new DataFlushService();


        $distribute_t = CCPubService::getDefaultDistributeDate();
        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $deliveryTime = strtotime($distribute_t);
        $result = $service->flush($deliveryTime);
        echo json_encode($result, true);
    }

    public function  actionReset()
    {
        $service = new DataFlushService();

        $distribute_t = CCPubService::getDefaultDistributeDate();
        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $deliveryTime = strtotime($distribute_t);
        $result = $service->reset($deliveryTime);
        echo json_encode($result, true);
    }

    public function  actionStop()
    {
        $result = SystemSetService::updateSystemKey("dataflush", "0");
        echo json_encode(1, true);
    }

    public function  actionStart()
    {
        $result = SystemSetService::updateSystemKey("dataflush", "1");
        echo json_encode(1, true);
    }
}

