<?php

/**
 * 分拣监控页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class CitysController extends Controller
{
    public $layout = '//layouts/main';

    public function ActionPage()
    {
        $city_list = CCPubService::getALLCityList();
        //$rate = $service->getCitysRate($para["delivery_time"], $city_list);
        $this->render('page', array(
            //'rate'=>$rate,
            'city_list' => $city_list,
            'distribute_t' => CCPubService::getDefaultDistributeDate(),
        ));
    }

    public function ActionSearch()
    {
        $para = CCPubService::getPara();
        $service = new CitysService();
        //$rows = $service->getCitysWeight($para["delivery_time"]);
        $service = new CitysService();
        $city_list = CCPubService::getALLCityList();
        //城市列表
        $xAxis = array();
        foreach ($city_list as $key => $value) {
            $xAxis[] =  $value;
        }
       //array_shift($xAxis);
        //var_dump($xAxis);
        //分拣率
        $rate = $service->getCitysRate($para["delivery_time"], $city_list,$this->user_info);

        //yzx
        $expect= $service->getCitysExpect($para["delivery_time"],$city_list,$this->user_info);
        $real=$service->getCitysReal($para["delivery_time"],$city_list,$this->user_info);

        echo json_encode(array(
            'city_list' => $city_list,
            'xAxis' => $xAxis,
            'rate' => $rate,
            'expect'=>$expect,
            'real'=>$real
        ), true);
    }

}

