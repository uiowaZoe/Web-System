<?php

/**
 * Created by PhpStorm.
 * User: bgl
 * Date: 2015/8/27
 * Time: 12:56
 */
class ClassController extends Controller
{
    public $layout = '//layouts/main';


    # 新建群发任务页面
    public function ActionPage()
    {
        $class1_list = CCPubService::getClass1List_goods();
        $class1_Ids = array();
        foreach ($class1_list as $key => $value) {
            $class1_Ids[] = intval($value["id"]);//string-->int
        }
        $para = CCPubService::getPara();
        $class_list = CCPubService::getClassList();
        $city_list = CCPubService::getCityList($this->user_info);
        $first_city = CCPubService::getFirstCity($this->user_info);
        //$warehouse = CCPubService::getWarehouseList($this->user_info);
        //$service = new ClassService();
       // $rate = $service->getClass1Data($para["delivery_time"], $city_list,$warehouse);
        $this->render('page', array(
            'first_city'=>$first_city,
            'city_list' => $city_list,
            'warehouselist' => json_encode(CCPubService::getWarehouseList($this->user_info)),
            'class_list' => $class_list,
            'distribute_t' => $para["distribute_t"],
            'city' => $para["city"],
            'warehouse' => $para["warehouse"],
            'class1_Ids' => $class1_Ids
        ));
    }

    # 新建群发任务页面
    public function ActionSearchClass1()
    {
        $warehouse = "";
        if (isset($_GET["warehouse"]))//是否存在"warehouse"的参数
        {
            $warehouse = $_GET["warehouse"];//存在
        }
        $para = CCPubService::getPara();
        $service = new ClassService();
        $rows = $service->getClass1Data($para["delivery_time"], $para["city"], $para["warehouse"],$this->user_info);
        $class_list = CCPubService::getClass1List_goods();
        $xAxis = array();
        $rate=array();
        $map= UtilService::rowsToMap($rows, "class1", "rate");
        foreach ($class_list as $key => $value) {
            $xAxis[] = $value["name"];
            if (isset($map[$value["id"]])) {
                $rate[] = $map[$value["id"]];
            } else {
                $rate[] = 0;
            }

        }

        //expect_num
        $mapexpect = UtilService::rowsToMap($rows, "class1", "expect_num");
        $expect_num = array();
        foreach ($class_list as $key => $value) {

            $class2_Ids[] = intval($value["id"]);//string-->int
            if (isset($mapexpect[$value["id"]])) {
                $expect_num[] = $mapexpect[$value["id"]];
            } else {
                $expect_num[] = 0;
            }
        }
        //real_num
        $realmap = UtilService::rowsToMap($rows, "class1", "real_num");
        $real_num = array();
        foreach ($class_list as $key => $value) {

            $class2_Ids[] = intval($value["id"]);//string-->int
            if (isset($realmap[$value["id"]])) {
                $real_num[] = $realmap[$value["id"]];
            } else {
                $real_num[] = 0;
            }
        }

        //$rate = $service->getClassRate($rows, $class_list);
        if (isset($_GET["city"]))//是否存在"city"的参数
        {
            $city = $_GET["city"];//存在
        }
        $num = $service->getNumData($para["delivery_time"], $city, $warehouse,$this->user_info);
        if (count($num) == 0) {
            $num[0]["real_num"] = 0;
            $num[0]["expect_num"] = 0;
        }
        $rows= $service->getClass1Data($para["delivery_time"],$para["city"],$para["warehouse"],$this->user_info);
        $data =array();
        foreach($rows as $value){
            $data[]= $value;
        }
        echo json_encode(array(
            'data'=>$data,
            'xAxis' => $xAxis,
            'real_num'=>$real_num,
            'expect_num'=>$expect_num,
            'rate' => $rate,
            'realNum' => $num[0]["real_num"],
            'expectNum' => $num[0]["expect_num"]
        ), true);

    }

    # class2小类页面


    public function ActionSearchClass2()
    {

        $class1Id = intval($_REQUEST["class1_Id"]);//yzx
        $class2_list = CCPubService::getClass2ListByClass1id_goods($class1Id);//yzx_
        $class2_Ids = array();

        $para = CCPubService::getPara();
        $service = new ClassService();
        $rows = $service->getClass2Data($para["delivery_time"], $para["city"], $para["warehouse"], $class1Id,$this->user_info);
        $xAxis = array();

        $map = UtilService::rowsToMap($rows, "class2", "rate");
        $rate = array();
        foreach ($class2_list as $key => $value) {
            $xAxis[] = $value["name"];
            $class2_Ids[] = intval($value["id"]);//string-->int
            if (isset($map[$value["id"]])) {
                $rate[] = $map[$value["id"]];
            } else {
                $rate[] = 0;
            }
        }

        //expect_num
        $mapexpect = UtilService::rowsToMap($rows, "class2", "expect_num");
        $expect_num = array();
        foreach ($class2_list as $key => $value) {

            $class2_Ids[] = intval($value["id"]);//string-->int
            if (isset($mapexpect[$value["id"]])) {
                $expect_num[] = $mapexpect[$value["id"]];
            } else {
                $expect_num[] = 0;
            }
        }
        //real_num
        $realmap = UtilService::rowsToMap($rows, "class2", "real_num");
        $real_num = array();
        foreach ($class2_list as $key => $value) {

            $class2_Ids[] = intval($value["id"]);//string-->int
            if (isset($realmap[$value["id"]])) {
                $real_num[] = $realmap[$value["id"]];
            } else {
                $real_num[] = 0;
            }
        }
        $data =array();
        foreach($rows as $value){
            $data[]= $value;
        }
        echo json_encode(array(
            'data'=>$data,
            'xAxis' => $xAxis,
            'real_num'=>$real_num,
            'expect_num'=>$expect_num,
            'rate' => $rate,
            'class1Id' => $class1Id,
            'class2_Ids' => $class2_Ids//arraytojson
        ), true);
    }
}

