<?php

/**
 * 分拣监控页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class CisController extends Controller
{
    public $layout = '//layouts/main';

    # 新建群发任务页面

    public function ActionPage()
    {
        $para = CCPubService::getPara();
        $first_city = CCPubService::getFirstCity($this->user_info);
        $distribute_t = CCPubService::getDefaultDistributeDate();
        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $class2_list = CCPubService::getClass2List_goods();
        $this->render('page', array(
            'first_city'=>$first_city,
            'city_list' => CCPubService::getCityList( $this->user_info),
            'distribute_t' => $para["delivery_time"],
            'warehouselist' => json_encode(CCPubService::getWarehouseList($this->user_info)),
            'good_list' => CCPubService::getClassList(),
           // 'class1_list' => CCPubService::getClass1List(),
        		'class1_list' =>CCPubService::getClass1List_goods(),
            'distribute_t' =>$distribute_t,
            'city' => $para["city"],
            'warehouse' => $para["warehouse"],
            'class1' => $para["class1"],
            'class2' =>  $para["class2"],
            'class2_list' => json_encode($class2_list)
        ));
    }

    public function actionSearchCis()
    {
        $para = CCPubService::getPara();

        $rows = CisService::CisSearch($para,$this->user_info);
        $total = count($rows);
        if(!isset($_GET['page'])||!intval($_GET['page'])||$_GET['page']>$total)//page可能的四种状态
        {
            $page=1;
        }
        else
        {
            $page=$_GET['page'];//如果不满足以上四种情况，则page的值为$_GET['page']
        }
        $startNum = ($page-1)*20;//开始条数

        $per_page = 20;
        $list =CisService::getPage($para,$startNum,$this->user_info);
        $pp=array(
            "total_pages" => ceil($total/20),
            "total"  => $total,
            "per_page" => $per_page,
            "page"   => $page,
            "rows" => $list
        );




//        $test=array_merge($list,$pp);
         echo json_encode($pp,true);


    }



}


