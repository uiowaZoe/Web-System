<?php

/**
 * Created by PhpStorm.
 * User: gzy
 * Date: 2015/8/27
 * Time: 12:56
 */
class PredictDetailController extends Controller
{
    public $layout = '//layouts/main';


    # 新建群发任务页面
    public function ActionDetail()
    {
        $delivery_time = $_REQUEST["delivery_time"];
        $city = $_REQUEST["city"];
        $ciid = $_REQUEST["ciid"];
        $warehouse = $_REQUEST["warehouse"];
        $item_name = $_REQUEST["item_name"];
        $n=strpos($item_name,'-');
        $item_name_v2="未识别的商品名称";
        if($n){
            $item_name_v2=substr($item_name,0,$n);
        }
        $city_list = CCPubService::getCityList($this->user_info);
        $city_name="北京";
        foreach ($city_list as $key => $value) {
                if ($city == $key) {
                    $city_name=$value;
                }
        }
        $this->render('detail', array(
            'item_name'=>$item_name,
            'city_name'=>$city_name,
            'delivery_time'=>$delivery_time,
            'city'=>$city,
            'ciid'=>$ciid,
            'warehouse'=>$warehouse

        ));
    }

    # 近日每个时刻的预测数据

    public function actionSearchPredictData()
    {
        $para = CCPubService::getPara();
        $timeline = PredictDetailService::getTimeline($para,$this->user_info,$para["delivery_time"]);
        $yData = PredictDetailService::searchDetail($para,$this->user_info);
        $xAxis = array();
        $predict_num=array();

        $map= UtilService::rowsToMap($yData, "timepoint", "predict_num");



        foreach ($timeline as $key => $value) {
        $xAxis[] = $value["timepoint"];

        if (isset($map[$value["timepoint"]])) {
            $predict_num[] = $map[$value["timepoint"]];
        } else {
           $predict_num[] = 0;
        }

    }

        $predict_high=array();
        $maphigh= UtilService::rowsToMap($yData, "timepoint", "high_predict_num");
        foreach ($timeline as $key => $value) {

            if (isset($maphigh[$value["timepoint"]])) {
                $predict_high[] = $maphigh[$value["timepoint"]];
            } else {
                $predict_high[] = 0;
            }

        }

        $predict_low=array();
        $maplow= UtilService::rowsToMap($yData, "timepoint", "low_predict_num");
        foreach ($timeline as $key => $value) {

            if (isset($maplow[$value["timepoint"]])) {
                $predict_low[] = $maplow[$value["timepoint"]];
            } else {
                $predict_low[] = 0;
            }

        }
       // var_dump($map);
        echo json_encode(array(
            'predict_num'=>$predict_num,
            'xAxis' => $xAxis,
            'predict_low'=>$predict_low,
            'predict_high'=>$predict_high,
            'data' => $yData
        ), true);

    }


    # 今日预测值误差表格
    public function actionSearchdifference()
    {
        $para = CCPubService::getPara();
        $timeline = PredictDetailService::getTimeline($para,$this->user_info,$para["delivery_time"]);
        $expect_rows=PredictDetailService::getEcpectnum($para,$this->user_info,$para["delivery_time"]);
        $yData = PredictDetailService::searchDetail($para,$this->user_info);
        $map_avg = UtilService::rowsToMap($yData, "timepoint", "predict_num");

        //得到平均预测量的相关数据

        $differ_num_avg=array();
        $xAxis=array();
        $predict_avg=array();
        foreach ($timeline as $key => $value) {
            $xAxis[] = $value["timepoint"];

            if (isset($map_avg[$value["timepoint"]])) {
                $predict_avg[] = $map_avg[$value["timepoint"]];
                if($expect_rows[0]["expect_num"]!=null){
                    if($map_avg[$value["timepoint"]]>$expect_rows[0]["expect_num"]){
                        $differ_num_avg[] = $map_avg[$value["timepoint"]]-$expect_rows[0]["expect_num"];
                    }
                    else{
                        $differ_num_avg[] = $expect_rows[0]["expect_num"]-$map_avg[$value["timepoint"]];
                    }
                }
                else{
                    $expect_rows[0]=0;
                    $differ_num_avg[] = $map_avg[$value["timepoint"]];
                }
            } else {
                $predict_avg[] = 0;
                $differ_num_avg[] = 0;
            }

        }
        //得到最大值预测数据
        $map_high= UtilService::rowsToMap($yData, "timepoint", "high_predict_num");
        $differ_num_high=array();
        $predict_high=array();
        foreach ($timeline as $key => $value) {

            if (isset($map_high[$value["timepoint"]])) {
                $predict_high[] = $map_high[$value["timepoint"]];
                if($expect_rows[0]["expect_num"]!=null){
                    if($map_high[$value["timepoint"]]>$expect_rows[0]["expect_num"]){
                        $differ_num_high[] = $map_high[$value["timepoint"]]-$expect_rows[0]["expect_num"];
                    }
                    else{
                        $differ_num_high[] = $expect_rows[0]["expect_num"]-$map_high[$value["timepoint"]];
                    }
                }
                else{
                    $differ_num_high[] = $map_high[$value["timepoint"]];
                }
            } else {
                $predict_high[] = 0;
                $differ_num_high[] = 0;
            }

        }


        //得到最小值预测数据

        $map_low= UtilService::rowsToMap($yData, "timepoint", "low_predict_num");
        $differ_num_low=array();
        $predict_low=array();
        foreach ($timeline as $key => $value) {

            if (isset($map_low[$value["timepoint"]])) {
                $predict_low[] = $map_low[$value["timepoint"]];
                if($expect_rows[0]["expect_num"]!=null){
                    if($map_low[$value["timepoint"]]>$expect_rows[0]["expect_num"]){
                        $differ_num_low[] = $map_low[$value["timepoint"]]-$expect_rows[0]["expect_num"];
                    }
                    else{
                        $differ_num_low[] = $expect_rows[0]["expect_num"]-$map_low[$value["timepoint"]];
                    }
                }
                else{
                    $differ_num_low[] = $map_low[$value["timepoint"]];
                }
            } else {
                $predict_low[] = 0;
                $differ_num_low[] = 0;
            }

        }

        $expect_num=array();
        foreach ($timeline as $key => $value) {
            if($expect_rows[0]["expect_num"]!= null){
                $expect_num[] = $expect_rows[0]["expect_num"];
            }
            else{
                $expect_num[]=0;
            }

        }

        $smallerone_avg=array();
        $lenghth_avg = count($predict_avg);
        for($i=0;$i<$lenghth_avg;$i++){
            if($predict_avg[$i]<$expect_num[$i]){
                $smallerone_avg[]=$predict_avg[$i];
            }
            else{
                $smallerone_avg[]=$expect_num[$i];
            }
        }

        $smallerone_low=array();
        $lenghth_low = count($predict_low);
        for($i=0;$i<$lenghth_low;$i++){
            if($predict_low[$i]<$expect_num[$i]){
                $smallerone_low[]=$predict_low[$i];
            }
            else{
                $smallerone_low[]=$expect_num[$i];
            }
        }

        $smallerone_high=array();
        $lenghth_high = count($predict_high);
        for($i=0;$i<$lenghth_high;$i++){
            if($predict_high[$i]<$expect_num[$i]){
                $smallerone_high[]=$predict_high[$i];
            }
            else{
                $smallerone_high[]=$expect_num[$i];
            }
        }






        echo json_encode(array(
            'expect_num'=>$expect_num,
            'xAxiss' => $xAxis,
            'predict_avg'=>$predict_avg,
            'expect_rows'=>$expect_rows,
            'differ_num_avg'=>$differ_num_avg,
            'smallerone_avg'=>$smallerone_avg,


            'predict_low'=>$predict_low,
            'differ_num_low'=>$differ_num_low,
            'smallerone_low'=>$smallerone_low,


            'predict_high'=>$predict_high,
            'differ_num_high'=>$differ_num_high,
            'smallerone_high'=>$smallerone_high,
        ), true);




    }


}

