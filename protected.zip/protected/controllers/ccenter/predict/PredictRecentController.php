<?php
/**
 * Created by PhpStorm.
 * User: gzy
 * Date: 2015/10/16
 * Time: 13:46
 */
class PredictRecentController extends Controller
{
    public $layout = '//layouts/main';


    # 新建群发任务页面
    public function Actionpage()
    {
        $delivery_time = $_REQUEST["delivery_time"];
        $city = $_REQUEST["city"];
        $ciid = $_REQUEST["ciid"];
        $warehouse = $_REQUEST["warehouse"];
        $item_name = $_REQUEST["item_name"];
        $n=strpos($item_name,'-');
        $item_name_v2="未识别的商品名称";
        if($n){
            $item_name_v2=substr($item_name,0,$n);
        }
        $city_list = CCPubService::getCityList($this->user_info);
        $city_name="北京";
        foreach ($city_list as $key => $value) {
            if ($city == $key) {
                $city_name=$value;
            }
        }
        $this->render('page', array(
            'item_name'=>$item_name,
            'city_name'=>$city_name,
            'delivery_time'=>$delivery_time,
            'city'=>$city,
            'ciid'=>$ciid,
            'warehouse'=>$warehouse

        ));
    }

    # 近日每个时刻的预测数据

    public function actionSearchRecentData()
    {
        $para = CCPubService::getPara();
        $recent = CCPubService::getRecentDate($para["delivery_time"]);
        //得到每一日的expect，predict数据$expect_rows$predict_rows
        $expect_rows = array();
        $predict_rows = array();
        $long = array();
        $timelingarray =array();
        $timeline = array();
        for ($i = 0; $i < count($recent); $i++) {
           $timelingarray[]=PredictDetailService::getTimeline($para, $this->user_info, $recent[$i]);
            $long[]=count($timelingarray[$i]);

        }
        
        $max=0;
        for ($i = 0; $i < count($recent); $i++) {
            if($max<$long[$i]){
                $max=$long[$i];
                $timeline=$timelingarray[$i];
            }
        }

        //$timeline = PredictDetailService::getTimeline($para, $this->user_info, $recent[0]);
        //$expect_rows = PredictDetailService::getEcpectnum_v2($para, $this->user_info, 7);
        for ($i = 0; $i < count($recent); $i++) {

            $expect_rows[] = PredictDetailService::getEcpectnum($para, $this->user_info, $recent[$i]);
            $predict_rows[] = PredictDetailService::getPredictnum($para, $this->user_info, $recent[$i]);

        }


    // exit(1);
            //构造要返回到页面的数组$predict_num$expect_num$rate0123456$xAxis
        $xAxis = array();
        $predict_num = array();
        $expect_num = array();

        //array name

        $rate = array();
        $rate[0]=$rate0=array();
        $rate[1]=$rate1=array();
        $rate[2]=$rate2=array();
        $rate[3]=$rate3=array();
        $rate[4]=$rate4=array();
        $rate[5]=$rate5=array();
        $rate[6]=$rate6=array();

       /*   $rows_ret = array();
         foreach ($rows_from_db as $index=>$value){
         	$row_ret[$value['delivery_time']]['city'] = $value['city'];
         	//$row_ret[$value['delivery_time']]['city'] =$value[''];
         	$row_ret[$value['delivery_time']]['expect_num'] =$value['expect_num'];
         	$rows_ret[] = $row_ret;
         }  */
        for ($i = 0; $i < count($recent); $i++) {
            if (isset($expect_rows[$i][0]["expect_num"])) {
                $expect_num[] = $expect_rows[$i][0]["expect_num"];
            } else {
                $expect_num[] = 0;
            }
        }
        for ($i = 0; $i < count($recent); $i++) {
            if(isset($predict_rows[$i])){
                $map = UtilService::rowsToMap($predict_rows[$i], "timepoint", "predict_num");
                foreach ($timeline as $key => $value) {

                    if (isset($map[$value["timepoint"]])) {
                        $predict_num[$i][] = $map[$value["timepoint"]];
                        if($expect_num[$i]!=0) {


                            $differ_num = $map[$value["timepoint"]] - $expect_num[$i];
                            $rate[$i][] = round($differ_num / $expect_num[$i], 2) * 100;
                        }
                        else{
                            $rate[$i][]=100;
                        }

                    }

                    else{
                        $rate[$i][]=100;
                        $predict_num[$i][]=0;


                    }
                }
            }

        }
        foreach ($timeline as $key => $value) {
            $xAxis[] = $value["timepoint"];

        }
            echo json_encode(

                array(
                    'xAxis'=>$xAxis,

                    'timeline'=>$timeline,
                    'rate'=>$rate,
                    'recentdate'=>$recent,
                    'expect_num'=>$expect_num,
                    'expect_rows'=>$expect_rows,
                    'predict_num'=>$predict_num,
                    'predict_rows'=>$predict_rows

            ), true);

        }



}