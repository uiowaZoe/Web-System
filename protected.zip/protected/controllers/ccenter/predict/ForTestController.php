<?php


class ForTestController extends Controller
{
    public $layout = '//layouts/main';

    # 新建群发任务页面

    public function Actionpage()
    {
        $para = CCPubService::getPara();
        $first_city = CCPubService::getFirstCity($this->user_info);
        $distribute_t = CCPubService::getDefaultDistributeDate();
        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $class2_list = CCPubService::getClass2List_goods();
        $this->render('page', array(

            'first_city' => $first_city,
            'city_list' => CCPubService::getCityList($this->user_info),
            'warehouselist' => json_encode(CCPubService::getWarehouseList($this->user_info)),
            'class1_list' => CCPubService::getClass1List_goods(),
            'distribute_t' => $distribute_t,
            'city' => $para["city"],
            'warehouse' => $para["warehouse"],
            'class1' => $para["class1"],
            'class2' => $para["class2"],
            'class2_list' => json_encode($class2_list)
        ));
    }

    public function actionSearch()
    {
        $para = CCPubService::getPara();
        $rows = ForTestService::PredictCisSearch($para,$para["delivery_time"]);
        $total = count($rows);

        if (!isset($_GET['page']) || !intval($_GET['page']) || $_GET['page'] > $total)//page可能的四种状态
        {
            $page = 1;
        } else {
            $page = intval($_GET['page']);//如果不满足以上四种情况，则page的值为$_GET['page']
        }
        $startNum = ($page - 1) * 20;//开始条数
        $per_page = 20;
        $list = ForTestService::getPage($para, $startNum, $this->user_info);

        echo json_encode(array(
            "total_pages" => ceil($total / 20),
            "total" => $total,
            "per_page" => $per_page,
            "page" => $page,
            "rows" => $list,
            "data"=>$rows
        ), true);


    }

//    public function actionSearch_v2(){
//        $para = CCPubService::getPara();
//        $rows = ForTestService::PredictCisSearch_v2($para,$this->user_info);
//        $total = count($rows);
//
//        if(!isset($_GET['page'])||!intval($_GET['page'])||$_GET['page']>$total)//page可能的四种状态
//        {
//            $page=1;
//        }
//        else
//        {
//            $page=intval($_GET['page']);//如果不满足以上四种情况，则page的值为$_GET['page']
//        }
//        $startNum = ($page-1)*20;//开始条数
//        $per_page = 20;
//        $list =ForTestService::getPage_v2($para,$startNum,$this->user_info);
//
//        echo json_encode(array(
//            "total_pages" => ceil($total/20),
//            "total"  => $total,
//            "per_page" => $per_page,
//            "page"   => $page,
//            "rows" => $list
//        ),true);
//
//
//    }
//
//}

   public function actionBefore()
   {
       $para = CCPubService::getPara();
       $rows = array();
       $rows[0] = strval(strtotime("-1 day", $para["delivery_time"]));
       $data = array();
       $data_all =array();
       $data_today =ForTestService::PredictCisSearch($para,$para["delivery_time"]);
       $map_today = UtilService::rowsToMap($data_today, "delivery_time", "expect_num");
       $expect_today = $map_today[$para["delivery_time"]];
       $data[0] = ForTestService::PredictCisSearch($para, $rows[0]);
       $data_all[0] = ForTestService::PredictSearchall($para,$rows[0]);
       $recentrows = array();
       $recentrows[0] = date('Y-m-d', $rows[0]);
       $expect_add =0;
       $rate_add = 0;
       $rate=array();

       for ($n = 1; $n < 21; $n++) {
           $before = $rows[$n - 1];
           $rows[$n] = strval(strtotime("-1 day", $before));
           $recentrows[$n] = date('Y-m-d', $rows[$n]);
           $data[$n] = ForTestService::PredictCisSearch($para, $rows[$n]);
           $data_all[$n] = ForTestService::PredictSearchall($para,$rows[$n]);

       }

       for($n=0;$n <21;$n++){
           if (isset($data[$n])) {
               $map = UtilService::rowsToMap($data[$n], "delivery_time", "expect_num");
               $map_all = UtilService::rowsToMap($data_all[$n],"delivery_time", "expect_num");
               foreach ($rows as $key=>$value) {

                   if (isset($map[$value])) {
                       $expect_add = $expect_add + $map_all[$value];
                       $rate[$n]=round($map[$value]/$map_all[$value],6);//每天数据占比
                       $rate_add=$rate_add+$rate[$n];
                   }
               }
           }

       }
       $avg_expect=round($expect_add/21,6);
       $avg_rate=round($rate_add/21,6);//特定时间的平均比例

       $max_rate=$rate[0];
       for($n=1;$n<20;$n++){
           if($max_rate<$rate[$n]){
               $max_rate=$rate[$n];
           }
       }

       $min_rate=$rate[0];
       for($n=1;$n<21;$n++){
           if($min_rate>$rate[$n]){
               $min_rate=$rate[$n];
           }
       }
       $rows = array
       (
           "predict_num" =>  round($expect_today/$avg_rate,2),
           "predict_high"=>round($expect_today/$min_rate,2),
           "predict_low"=>round($expect_today/$max_rate,2),
       );

       echo json_encode(array(
           "data" => $data,//选定的时间的数据组
           "data_all"=>$data_all,
           "expect_add" => $expect_add,//历史订单量之和
           "avg_expect"=>$avg_expect,//16点之前的预测数据
           "rate"=>$rate,
           "avg_rate"=>$avg_rate,
           "max_rate"=>$max_rate,
           "min_rate"=>$min_rate,
           "expect_today"=>$expect_today,
           "predict_num"=>round($expect_today/$avg_rate,2),//16点之后的预测数据
           "predict_high"=>round($expect_today/$min_rate,2),
           "predict_low"=>round($expect_today/$max_rate,2),
           "rows"=>$rows
       ), true);
   }



}


