<?php

/**
 * 分拣监控页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class PredictFlushController extends Controller
{
    public $layout = '//layouts/main';
/**
 * 提供给定时任务的接口，用于预测数据
 * input：时间节点
 * output：预测数据塞入表t_cc_predict_phase_ci
 * id	int	11	0	0	-1	0	0	0		0					-1	0
city	int	11	0	0	0	0	0	0		0					0	0
warehouse	int	11	0	0	0	0	0	0		0					0	0
ci	int	11	0	0	0	0	0	0		0					0	0
delivery_time	int	11	0	0	0	0	0	0		0	配送时间				0	0
timepoint	int	11	0	0	0	0	0	0		0					0	0
predict_num	int	11	0	0	0	0	0	0		0					0	0
expect_num	int	11	0	0	0	0	0	0		0					0	0
class1	int	11	0	0	0	0	0	0	0	0	大类				0	0
class1_name	varchar	255	0	0	0	0	0	0		0		utf8	utf8_general_ci		0	0
class2	int	11	0	0	0	0	0	0	0	0	小类				0	0
class2_name	varchar	255	0	0	0	0	0	0		0	小类名称	utf8	utf8_general_ci		0	0
item_name	varchar	255	0	0	0	0	0	0		0		utf8	utf8_general_ci		0	0
 
 */
    public function  actionEstimate()
    {
        $service = new PredictFlushService();
      //  $param = array();
        $get_cur_hour = false;
        $hour = 0;
        if (isset($_GET["distribute_t"]))
        {
            $distribute_t = $_GET["distribute_t"];//存在
            if(isset($_GET['predict_hour'])){
            	$hour = $_GET['predict_hour'];
            	$get_cur_hour = true;
            }else{
            	$get_cur_hour = false;
            }
        }else{
        	$distribute_t = CCPubService::getDefaultDistributeDate();
        	$get_cur_hour = true;
        	$hour = date('H', time());
        }
       // $param['predict_t'] = $distribute_t;
        //echo $hour;
       // exit(1);
       // echo $distribute_t;
        //$deliveryTime = strtotime($distribute_t);
        $result = $service->estimate($distribute_t, $hour, $get_cur_hour);
        echo json_encode($result, true);
    }

    /**
     * Calucate the percent of the ci
     * 18 19 20 21 22 23,每个点包括一个百分比，什么时候刷新由定时机制决定
     * input：无,每次评定的是前一个月的数据
     * output:数据入表：t_cc_predict_base_percent
     * id	int	11	0	0	-1	0	0	0		0					-1	0
city	int	11	0	0	0	0	0	0		0					0	0
warehouse	int	11	0	0	0	0	0	0		0					0	0
ci	int	11	0	0	0	0	0	0		0					0	0
timepoint	int	11	0	0	0	0	0	0		0					0	0
percent	double	11	4	0	0	0	0	0		0					0	0
     */
    public function actionPercent()
    {
    	$service = new PredictFlushService();
        if (isset($_GET["distribute_t"]))
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }else{
        	$distribute_t = CCPubService::getDefaultDistributeDate();
        }
       // echo $distribute_t;
        //$deliveryTime = strtotime($distribute_t);
        $result = $service->percent($distribute_t);
        echo json_encode($result, true);
    }
}

