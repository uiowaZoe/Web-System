<?php

/**
 * 分拣监控页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class PredictDataController extends Controller
{
    public $layout = '//layouts/main';

    # 新建群发任务页面

    public function ActionPage()
    {
        $para = CCPubService::getPara();
        $first_city = CCPubService::getFirstCity($this->user_info);
        $distribute_t = CCPubService::getDefaultDistributeDate();
        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $class2_list = CCPubService::getClass2List_goods();
        $this->render('page', array(

            'first_city'=>$first_city,
            'city_list' => CCPubService::getCityList( $this->user_info),
            'warehouselist' => json_encode(CCPubService::getWarehouseList($this->user_info)),
            'good_list' => CCPubService::getClassList(),
            'class1_list' => CCPubService::getClass1List_goods(),
            'distribute_t' =>$distribute_t,
            'city' => $para["city"],
            'warehouse' => $para["warehouse"],
            'class1' => $para["class1"],
            'class2' =>  $para["class2"],
            'class2_list' => json_encode($class2_list)
        ));
    }

    public function actionSearchPredict()
    {
        $para = CCPubService::getPara();
        $rows = PredictDataService::PredictCisSearch($para,$this->user_info);
        $total = count($rows);

        if(!isset($_GET['page'])||!intval($_GET['page'])||$_GET['page']>$total)//page可能的四种状态
        {
            $page=1;
        }
        else
        {
            $page=intval($_GET['page']);//如果不满足以上四种情况，则page的值为$_GET['page']
        }
        $startNum = ($page-1)*20;//开始条数
        $per_page = 20;
        $list =PredictDataService::getPage($para,$startNum,$this->user_info);

            echo json_encode(array(
                "total_pages" => ceil($total/20),
                "total"  => $total,
                "per_page" => $per_page,
                "page"   => $page,
                "rows" => $list
            ),true);



    }

    public function  actionPredictOut(){
        $file_type = "vnd.ms-excel";
        $file_ending = "xls";
        $para = CCPubService::getPara();
        header("Content-Type: application/$file_type;charset=utf-8");
        header("Content-Disposition: attachment; filename='生产分拣预测信息表.$file_ending");

        $rows = PredictDataService::PredictCisSearch($para,$this->user_info);
        $title = PredictDataService::getTitle();
        $allnum=count($rows);

        echo "<table><tr>";
        //导出表头（也就是表中拥有的字段）
        $t_field=array();
        $alltitle=count($title);
        if($allnum!=0) {
            for ($num = 1; $num < $alltitle; $num++) {
                if (isset($title[$num]["Field"]) && $title[$num]["Field"] != "expect_num"
                    && $title[$num]["Field"] != "class1" && $title[$num]["Field"] != "class2"
                ) {
                    $t_field[] = $title[$num]["Field"];
                    if ($title[$num]["Field"] == "ciid") {
                        echo "<th>" . "商品编号" . "</th>";
                    } else if ($title[$num]["Field"] == "city") {
                        echo "<th>" . "城市" . "</th>";
                    } else if ($title[$num]["Field"] == "warehouse") {
                        echo "<th>" . "仓库" . "</th>";
                    } else if ($title[$num]["Field"] == "item_name") {
                        echo "<th>" . "商品名称" . "</th>";
                    } else if ($title[$num]["Field"] == "class1_name") {
                        echo "<th>" . "一级分类" . "</th>";
                    } else if ($title[$num]["Field"] == "class2_name") {
                        echo "<th>" . "二级分类" . "</th>";
                    } else if ($title[$num]["Field"] == "delivery_time") {
                        echo "<th>" . "配送时间" . "</th>";
                    } else if ($title[$num]["Field"] == "timepoint") {
                        echo "<th>" . "预测时间点" . "</th>";
                    } else if ($title[$num]["Field"] == "high_predict_num") {
                        echo "<th>" . "预测最大值" . "</th>";
                    } else if ($title[$num]["Field"] == "low_predict_num") {
                        echo "<th>" . "预测最小值" . "</th>";
                    } else if ($title[$num]["Field"] == "predict_num") {
                        echo "<th>" . "预测平均值" . "</th>";
                    }
                }
            }
        }
        echo "</tr>";
        if($allnum!=0){
            for($num=0;$num<$allnum;$num++){
                echo "<tr>";
                foreach($t_field as $f_key)
                    if(isset($rows[$num][$f_key])){
                        echo "<td>".$rows[$num][$f_key]."</td>";
                    }
                echo "</tr>";
            }

        }
        echo "</table>";
        exit(1);

    }

}


