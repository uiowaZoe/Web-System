<?php

/**
 * 分拣监控页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class RunController extends ApiController
{
    public function  actionMonitorFlush()
    {
        $service = new DataFlushService();
        $distribute_t = CCPubService::getDefaultDistributeDate();
        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $deliveryTime = strtotime($distribute_t);
        $result = $service->flush($deliveryTime);
        echo json_encode($result, true);
    }

}

