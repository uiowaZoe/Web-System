<?php

error_reporting(E_ALL ^ E_DEPRECATED);
/**
 * 定时任务页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class JobController extends Controller
{
    public $layout = '//layouts/main';

    public function  ActionList()
    {
        $this->render('list2');
    }

    //getDataList
    public function  actionGetdata(){

        $_result = Job::model()->findAll();

        foreach ($_result as &$value) {
            $value['_id'] .= ' ';//将mogodbid转换，其后拼接一个空格字符串即可
        }
        echo json_encode($_result,true);
    }

    public function  actionAdd()
    {
        $crontabtime = $_GET['crontabtime'];
        $cmd = $_GET["cmd"];
        $c_t = $_GET["c_t"];
        $u_t = $_GET["u_t"];
        $single = $_GET["single"];
        $user = $_GET["user"];
        $model = new Job();
        $model->addInfo($crontabtime,$cmd,$user,$c_t,$u_t,$single);

        $_result = Job::model()->findAll();

        foreach ($_result as $value) {
            $value["_id"].=' ';
        }
        echo json_encode($_result,true);
    }

    public function  actionDel()
    {
        $_id=$_REQUEST["obj_Id"];
        if($_id!=null){
            $_id=$_REQUEST["obj_Id"];
        }else{
            $_id=0;
        }

        $model = new Job();
        $model->delInfo($_id);
        $_result = Job::model()->findAll();

        foreach ($_result as $value) {
            $value['_id'].=' ';
        }
        echo json_encode($_result,true);
    }

    //详情页面
    public function  actionDetail(){
        $model = new Job();
        $result=$model->findByPk(new MongoId('55f8d9c3610c6f702c000030'));
        $this->render('detail', array('result'=>$result));
    }
    //修改
    public function  actionEdit(){
        $_id = trim($_GET['crontab_id']);//去空格
        $crontabtime = $_GET['crontabtime'];
        $cmd = $_GET["cmd"];
        $c_t = $_GET["c_t"];
        $u_t = $_GET["u_t"];
        $single = $_GET["single"];
        $user = $_GET["user"];

        $model = new Job();
        $model->editInfo(new MongoId($_id),$crontabtime,$cmd,$user,$c_t,$u_t,$single);
        $_result = Job::model()->findAll();

        foreach($_result as $value){
            $value['_id'].=' ';

        }
        echo json_encode($_result,true);
    }

    public function  actionRun(){

        $p1=$_REQUEST["cmd"];
        $p2=$_REQUEST["crontabtime"];
     //   $p="curl localhost:9200/medcl2/_search";
        $result=exec("cmd /c $p1");
        $pp=array(
           "cmd"=>$p1,
            "crontabtime"=>$p2,
            "result"=>$result
        );
        $ppp=array($pp);
      // var_dump($result);
      echo json_encode($ppp,true);
    }

    public function  actionJobLog()
    {
        $rows1 = Job::model()->findAll();
        $rows2 = JobLog::model()->findAll();
            function _mergerArray($array1, $array2, $field1, $field2= "")
            {
                $array=Job::model()->findAll();
                $ret = array();

                foreach ($array2 as $key => $value) {
                        $array3["$value[$field2]"] = $value;
                }
                foreach ($array1 as $key => $value) {
                    if ($value["single"] == "true") {
                        $ret[] = array_merge((array)$array3["$value[$field1]"], (array)$value);
                    }
                    else
                    {
                        $ret[] =$array[$key];
                    }
                }
                return $ret;
            }

            $ret = _mergerArray($rows1, $rows2, "_id", "jobid");
            foreach($ret as &$value){
            $value['_id'].='';
            }
            echo json_encode($ret, true);
        }

  public function actionTest(){
      $rows1 = Job::model()->findAll();
      $rows2 = JobLog::model()->findAll();
      $ret = array();
      foreach($rows2 as $item) $ret[$item['id']] = $item['shop_name'];

      foreach($rows1 as $key => $item) {
          $exist = array_key_exists($item['id'], $ret);
          $arr[$key]['shop_name'] = $exist ? $ret[$item['id']] : '';
      }
      echo json_encode($ret,true);
  }
}
