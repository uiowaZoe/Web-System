<?php

/**
 * 定时任务页面
 *
 * @author wbw
 * @date 2015-07-08
 */
class JobLogController extends Controller
{

public function  ActionPage(){
    $this ->render(
        "log"
    );

}
    public function  actionLog()
    {
      //  $id=$_REQUEST["obj_id"];
        $single="true";
 //       var_dump($id);
//        try {
//            $jobid = new MongoId($id);
//        } catch (MongoException $ex) {
//            $jobid = new MongoId();
//        }
      $id="55f2bcae78038cadd22ce727";
        if ($single=="true") {
            $rows = JobLog::model()->findAllByAttributes(array("jobid" => new MongoId($id)));
        }else{
            $rows="";
        }
            echo json_encode($rows, true);

    }

}

