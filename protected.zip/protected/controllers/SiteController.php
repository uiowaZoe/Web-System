<?php

class SiteController extends Controller
{
    public function actionIndex()
    {
      //  var_dump('hello');
    	$this->render('index');
    }
}
