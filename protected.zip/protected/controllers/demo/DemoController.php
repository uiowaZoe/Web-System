<?php
/**
 * Created by PhpStorm.
 * User: hw
 * Date: 15-5-13
 * Time: 下午6:02
 */

class DemoController extends ApiController
{
    public function actionIndex()
    {
        $app = new DemoApp();
        $app->getInfo(1);

        echo 'the file is '.__FILE__;
    }
}
