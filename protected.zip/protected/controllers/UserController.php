<?php
/**
 * Created by PhpStorm.
 * User: 宇
 * Date: 2015/3/1
 * Time: 14:51
 */

/**
 * Class UserController
 * 微信商户controller
 */
class UserController extends ApiController
{
    /**
     * 根据 token 获取用户信息
     */
    public function actionTokenInfo()
    {
        if (empty($_POST['user_token']))
            $this->renderError(AuthUtils::errorInfo('COMMON_WRONG_PARAMS'));
        $user_info = TokenService::getTokenInfo($_POST['user_token']);

        $this->renderJson($user_info);
    }


    /**
     * 用户登录
     */
    public function actionLogin()
    {

        $phone = $_POST['phone'];
        $password = $_POST['password'];
        $system_key = $_POST['system_key'];
        $result = CompanyService::checkLogin($phone, $password);
        if ($result['code'] == 0) {
            $user_token = TokenService::setCompanyToken($result, $system_key);
            $this->renderJson($user_token);
        } else {
            $this->renderError($result);
        }
    }



}