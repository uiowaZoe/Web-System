<div class="panel panel-default" xmlns="http://www.w3.org/1999/html">
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>

                <input type="text" class="form-control date-pick" value="<?= $delivery_time; ?>"

                       name="delivery_time">
                <!--                <input type="text" class="form-control date-pick" value="-->
                <? //= date('Y-m-d', time()); ?><!--"-->
                <!--                       name="distribute_t">-->
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">商品名称</label>

                <input type="text" class="form-control "
                       name="item_name" id="item_name" value="<?= $item_name; ?>" readonly>

            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">商品编号</label>

                <input type="text" class="form-control "
                       name="ciid" id="ciid" value="<?= $ciid; ?>" readonly>

            </div>
            <div class="form-group mc-form-group">
                <label>城市</label>
                <input type="text" class="form-control "
                       name="city_name" id="city_name" value="<?= $city_name; ?>" readonly>

                <input type="hidden" class="form-control "
                       name="city" id="city" value="<?= $city; ?>" readonly>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>

                <input type="text" class="form-control "
                       name="warehouse" id="warehouse" value="<?= $warehouse; ?>" readonly>

            </div>

            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>

        </form>
    </div>
</div>

<div id="main" style="height:500px;border:1px solid #ccc;padding:10px;"></div>

<!--Step:2 Import echarts-all.js-->
<!--Step:2 引入echarts-all.js-->
<script src="/static/echarts/echarts-all.js"></script>
<script src="/static/echarts/green.js"></script>
<script type="text/javascript">
    var showdata=null;
    var showexpect=null;
    var showpredict=null;
    var showrecent=null;
    function getShowDate(data, datatype) {
        var y = new Array();
        for (index = 0; index < data.length; index++) {
            if (data[index] != 0) {
                y[index] = data[index][datatype];
            } else {
                y[index] = 0;
            }
        }
        return y;
    }
    $(function () {
        var optionPie = {
            title: {
                text: '七日预测数据',
                subtext: ''
            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name
                        + '<br/>' +showrecent[0] + ' : ' + showdata[0][tar.dataIndex] + '%真实值：'+showexpect[0]+'预测值：'+showpredict[0][tar.dataIndex]+'<br/>'
                        + '<br/>' + showrecent[1] + ' : ' + showdata[1][tar.dataIndex] + '%真实值：'+showexpect[1]+'预测值：'+showpredict[1][tar.dataIndex]+'<br/>'
                        + '<br/>' + showrecent[2]+ ' : ' + showdata[2][tar.dataIndex] + '%真实值：'+showexpect[2]+'预测值：'+showpredict[2][tar.dataIndex]+'<br/>'
                        + '<br/>' + showrecent[3]+ ' : ' + showdata[3][tar.dataIndex] + '%真实值：'+showexpect[3]+'预测值：'+showpredict[3][tar.dataIndex]+'<br/>'
                        + '<br/>' + showrecent[4] + ' : ' + showdata[4][tar.dataIndex] + '%真实值：'+showexpect[4]+'预测值：'+showpredict[4][tar.dataIndex]+'<br/>'
                        +  '<br/>' + showrecent[5] + ' : ' + showdata[5][tar.dataIndex] + '%真实值：'+showexpect[5]+'预测值：'+showpredict[5][tar.dataIndex]+'<br/>'
                        +  '<br/>' + showrecent[6]+ ' : ' + showdata[6][tar.dataIndex] + '%真实值：'+showexpect[6]+'预测值：'+showpredict[6][tar.dataIndex]+'<br/>';
                }
            },
            legend: {
                data: ['此前一天误差率','此前两天误差率','此前三天误差率','此前四天误差率','此前五天误差率',
                    '此前六天误差率','此前七天误差率'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: true,
                feature: {

                    mark: {show: false},
                    dataView: {show: false, readOnly: false},
                    magicType: {show: false, type: ['line', 'bar']},
                    restore: {show: false}
                }
            },

            calculable: true,

            xAxis: [
                {
                    type: 'category',
                    data: [1],
                    axisLabel: {
                        rotate: 60
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '误差率',
                    axisLabel: {
                        formatter: '{value}% '
                    }
                }
            ],
            series: [
                {
                    name: '此前一天误差率',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: []
                },
                {
                    name: '此前两天误差率',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [0]
                },
                {
                    name: '此前三天误差率',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [0]
                },
                {
                    name: '此前四天误差率',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [0]
                },
                {
                    name: '此前五天误差率',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [0]
                },
                {
                    name: '此前六天误差率',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [0]
                },
                {
                    name: '此前七天误差率',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [0]
                }

            ]
        };
        var dateOptions = {
            dateFormat: "yy-mm-dd"
        };
        $('.date-pick').datepicker(dateOptions);
        var differ_rate = echarts.init(document.getElementById('main'));
        differ_rate.setOption(optionPie);
        $('#search_btn').click(differRate);
        function differRate() {
            var params = YC.Util.getFormData("search_form");
            $.get("/ccenter/predict/PredictRecent/SearchRecentData", params, function (data) {
                optionPie.xAxis[0].data = data.xAxis;
                showdata = data.rate;
                showexpect=data.expect_num;
                showpredict=data.predict_num;
                showrecent=data.recentdate;
                var y = new Array();
                y[100] = 0;
               for(var i=0;i<7;i++){
                   if(showdata[i].length>0){
                       optionPie.series[i].data = data.rate[i];
                   }
                   else{
                       optionPie.series[i].data = y;
                       showdata[i] = y;
                   }
               }
                differ_rate.setOption(optionPie);
            }, "json");
        }

        differRate();
    })
</script>