<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">查询条件</h3>
    </div>
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>

                <input type="text" class="form-control date-pick" value="<?= $distribute_t; ?>"

                       name="distribute_t">
                <!--                <input type="text" class="form-control date-pick" value="-->
                <? //= date('Y-m-d', time()); ?><!--"-->
                <!--                       name="distribute_t">-->
            </div>
            <div class="form-group mc-form-group">
                    <label class="control-label">预测时间点</label>
                <select name="timepoint" id="timepoint" class="form-control">
                    <option value="" selected>最新预测时间</option>
                    <?php
                    for ($time=11;$time<24; $time++) {
                        echo "<option value='" . $time . "' >" . $time ."点". "</option>";
                    }
                    ?>
                </select>


            </div>
            <div class="form-group mc-form-group">
                <label>城市</label>
                <select name="city" id="city" class="form-control">
                    <?php
                    is_array($result = $first_city) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        $first_id=$key;
                        echo "<option value='" . $key . "' selected >" . $value . "</option>";
                    }
                    is_array($result = $city_list) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        if($key != $first_id){
                            if ($city == $key) {
                                echo "<option value='" . $key . "' selected >" . $value . "</option>";
                            } else {
                                echo "<option value='" . $key . "'>" . $value . "</option>";
                            }
                        }

                        # echo "<option value='" . $key . "'>" . $value . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>

                <select class="form-control" name="warehouse" id="warehouse">

                </select>
            </div>


            <div class="form-group mc-form-group">
                <label>大类查询</label>
                <select name="class1" id="class1" class="form-control">
                    <option value=''>全部</option>
                    <?php

                    //                    is_array($result = $class1_list) ? null : $result = array();
                    foreach ($class1_list as $key => $value) {
                        #echo "<option value='" . $value["id"] . "'>" . $value["name"] . "</option>";
                        if ($class1 == $value['id']) {
                            echo "<option value='" . $value['id'] . "' selected >" . $value['name'] . "</option>";
                        } else {
                            echo "<option value='" . $value['id'] . "'>" . $value['name'] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group mc-form-group">
                <label>小类查询</label>
                <select name="class2" id="class2" class="form-control">

                </select>

            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">名称查询</label>

                <input type="text" class="form-control "
                       name="item_name" id="item_name" placeholder="请输入商品名称">

            </div>
            <div class="form-group mc-form-group">
                <label class="control-label">ci查询</label>

                <input type="text" class="form-control "
                       name="ciid" id="ciid" placeholder="请输入商品ci">

            </div>

            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>

            <div class="form-group mc-form-group">
                <button id="out_btn" type="button" class="btn btn-primary">导出页面数据</button>
            </div>

        </form>
    </div>
</div>

<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">生产分拣预测</h3></li>
    </ul>
</div>
<div id="gridPanel"></div>
<script>
    $(function () {

    FW.GridActionRenderer = Class.create(FW.ActionsRenderer, {

        addActions: function($content, grid, colum, record) {
                var $detailLink = $("<a>").append("<i class='fa fa-search-plus'></i>");
                $detailLink.attr("title", "查看今日预测与实际数据");
                $detailLink.attr("href", "javascript:void(0)");
                $detailLink.click(function () {
                    window.open("/ccenter/predict/predictDetail/detail?ciid=" +
                    record.get("ciid") + "&city=" + record.get("city") + "&warehouse=" +
                    record.get("warehouse") + "&delivery_time=" + record.get("delivery_time")+ "&timepoint="
                    + record.get("timepoint")+ "&item_name="+ record.get("item_name"));
        });

                var $recentLink = $("<a>").append("<i class='fa fa-reddit-square'></i>");
                $recentLink.attr("title", "查看近七日相关数据");
                $recentLink.attr("href", "javascript:void(0)");
                $recentLink.click(function(){
                    window.open("/ccenter/predict/predictRecent/page?ciid=" +
                    record.get("ciid") + "&city=" + record.get("city") + "&warehouse=" +
                    record.get("warehouse") + "&delivery_time=" + record.get("delivery_time")+ "&timepoint="
                    + record.get("timepoint")+ "&item_name="+ record.get("item_name"));
                });
                $content.append($detailLink);
                $content.append($recentLink);

        }
    });
        var options = {
            id: "grid_index",
            columns: [
                {label: "商品编号", name: "ciid"},
                {label: "一级分类", name: "class1_name"},
                {label: "二级分类", name: "class2_name"},
                {label: "品名", name: "item_name"},
                {label:"预测时间",name:"timepoint"},
                {label:"预测值",name:"predict_num"},
                {label:"预测最大值",name:"high_predict_num"},
                {label:"预测最小值",name:"low_predict_num"},
                {label:"城市",name:"city"},
                {label:"仓库",name:"warehouse"},
                { label: "操作", renderer: "FW.GridActionRenderer", virtual:true, htmlSafe: true}
            ],
            target: $("#gridPanel"),
            url: '/ccenter/predict/PredictData/SearchPredict',
            loadAfterRendered: false,
            pagination: true
        };
        var gridPanel = new FW.Grid(options);
        gridPanel.render();

        $('#search_btn').click(pageSearch);

        function pageSearch() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);

            $.get('/ccenter/predict/PredictData/SearchPredict', params, function (data) {
                gridPanel.setData(data);

            }, "json");
        }
        $('#out_btn').click(outexcel);

        function outexcel() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
           // $.get('/ccenter/predict/PredictData/PredictOut', params);
            location.href ="/ccenter/predict/PredictData/PredictOut?distribute_t=" + params.distribute_t +
            "&timepoint=" + $("#timepoint").val() + "&city=" + $("#city").val()+"&ciid="+params.ciid+
             "&warehouse=" + params.warehouse +"&class1=" +params.class1
            + "&class2=" + params.class2
            + "&item_name=" + params.item_name;
            }



        var dateOptions = {
            dateFormat: "yy-mm-dd"
        };
        $('.date-pick').datepicker(dateOptions);

        function JSONLength(obj) {
            var size = 0, key;
            for (key in obj) {
                if (obj.hasOwnProperty(key)) size++;
            }
            return size;
        }

        $('#city').change(cityChange)
        function cityChange() {
            var selectIndex = $(this).children('option:selected').val();
            //alert(selectIndex);
            if (selectIndex == undefined) selectIndex = '<?= $first_id ?>';
            var objSelectNow = document.getElementById("warehouse");
            objSelectNow.options.length = 0;
            var lenght = JSONLength(warehouse[selectIndex]);
            var objOption = new Array;
                for (var i = 1; i <= lenght; i++) {
                    objOption[i] = document.createElement("option");
                    objOption[i].text = warehouse[selectIndex][i]["name"];
                    objOption[i].value = warehouse[selectIndex][i]["id"];
                    objSelectNow.options.add(objOption[i]);
                }
            if(selectIndex==1){
                objOption[2].selected=true;
            }
        }

        var warehouse =<?php echo $warehouselist ?>;
        var class2_list =<?php echo $class2_list ?>;
        $('#class1').change(class1Change);
        function class1Change() {
            var selectIndex = $(this).children('option:selected').val();
            var class1value = $("#class1").val();
            // alert(class1value)
            if (selectIndex == undefined) selectIndex = '<?= $city ?>';

            var objSelectNow = document.getElementById("class2");
            objSelectNow.options.length = 0;
            var lenght = class2_list.size();
            var objOption = document.createElement("option");
            objOption.text = "全部";
            objOption.value = "";
            objSelectNow.options.add(objOption);

            for (var i = 0; i < lenght; i++) {
                if (class2_list[i]["class1_id"] == class1value) {
                    var objOption = document.createElement("option");
                    objOption.text = class2_list[i]["name"];
                    objOption.value = class2_list[i]["id"];
                    objSelectNow.options.add(objOption);
                }
            }
        }
        class1Change();
        cityChange();

        pageSearch();


    });
</script>
<script src="/static/echarts/echarts-all.js"></script>
