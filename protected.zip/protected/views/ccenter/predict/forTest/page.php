<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">查询条件</h3>
    </div>
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>

                <input type="text" class="form-control date-pick" value="<?= $distribute_t; ?>"

                       name="distribute_t">
                <!--                <input type="text" class="form-control date-pick" value="-->
                <? //= date('Y-m-d', time()); ?><!--"-->
                <!--                       name="distribute_t">-->
            </div>
            <div class="form-group mc-form-group">
                <label class="control-label">预测时间点</label>
                <select name="timepoint" id="timepoint" class="form-control">
                    <option value="24" selected>24点</option>
                    <?php
                    for ($time=11;$time<24; $time++) {
                        echo "<option value='" . $time . "' >" . $time ."点". "</option>";
                    }
                    ?>
                </select>


            </div>
            <div class="form-group mc-form-group">
                <label>城市</label>
                <select name="city" id="city" class="form-control">
                    <?php
                    is_array($result = $first_city) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        $first_id=$key;
                        echo "<option value='" . $key . "' selected >" . $value . "</option>";
                    }
                    is_array($result = $city_list) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        if($key != $first_id){
                            if ($city == $key) {
                                echo "<option value='" . $key . "' selected >" . $value . "</option>";
                            } else {
                                echo "<option value='" . $key . "'>" . $value . "</option>";
                            }
                        }

                        # echo "<option value='" . $key . "'>" . $value . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>

                <select class="form-control" name="warehouse" id="warehouse">

                </select>
            </div>

            <!---->
            <!--            <div class="form-group mc-form-group">-->
            <!--                <label>大类查询</label>-->
            <!--                <select name="class1" id="class1" class="form-control">-->
            <!--                    <option value=''>全部</option>-->
            <!--                    --><?php
            //
            //                    //                    is_array($result = $class1_list) ? null : $result = array();
            //                    foreach ($class1_list as $key => $value) {
            //                        #echo "<option value='" . $value["id"] . "'>" . $value["name"] . "</option>";
            //                        if ($class1 == $value['id']) {
            //                            echo "<option value='" . $value['id'] . "' selected >" . $value['name'] . "</option>";
            //                        } else {
            //                            echo "<option value='" . $value['id'] . "'>" . $value['name'] . "</option>";
            //                        }
            //                    }
            //                    ?>
            <!--                </select>-->
            <!--            </div>-->
            <!--            <div class="form-group mc-form-group">-->
            <!--                <label>小类查询</label>-->
            <!--                <select name="class2" id="class2" class="form-control">-->
            <!---->
            <!--                </select>-->
            <!---->
            <!--            </div>-->

            <!--            <div class="form-group mc-form-group">-->
            <!--                <label class="control-label">名称查询</label>-->
            <!---->
            <!--                <input type="text" class="form-control "-->
            <!--                       name="item_name" id="item_name" placeholder="请输入商品名称">-->
            <!---->
            <!--            </div>-->
            <div class="form-group mc-form-group">
                <label class="control-label">ci查询</label>

                <input type="text" class="form-control "
                       name="ciid" id="ciid" placeholder="请输入商品ci">

            </div>

            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询commodity数据库</button>
            </div>

            <div class="form-group mc-form-group">
                <button id="search21_btn" type="button" class="btn btn-primary">查询21天数据</button>
            </div>
        </form>
    </div>
</div>

<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">生产分拣预测，for测试</h3></li>
    </ul>
</div>
<div id="gridPanel"></div>
<div id="gridPanel_21"></div>
<script>
    $(function () {

        var options = {
            id: "grid_index",
            columns: [
                {label: "商品编号", name: "ciid"},
                {label: "二级分类", name: "class2"},
                {label:"城市",name:"city"},
                {label:"仓库",name:"warehouse"},
                {label:"时间",name:"timepoint"},
                {label:"该时间点的订单量（这一天在这个时间点之前的下单）",name:"expect_num"},
                {label:"在这个时间点预测全天订单量",dataIndex:"predict_num"}
            ],
            target: $("#gridPanel"),
            url: '/ccenter/predict/ForTest/Before',
            loadAfterRendered: false,
            pagination: true
        };
        var gridPanel = new FW.Grid(options);
        gridPanel.render();

        $('#search_btn').click(pageSearch);

        function pageSearch() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);

            $.get('/ccenter/predict/ForTest/Search', params, function (data) {
                gridPanel.setData(data);

            }, "json");
        }

//        var options_21 = {
//            id: "grid_index_21",
//            columns: [
//                {label: "商品编号", value:data.},
//                {label: "二级分类", name: "class2"},
//                {label:"城市",name:"city"},
//                {label:"仓库",name:"warehouse"},
//                {label:"日期",name:""},
//                {label:"时间",name:"timepoint"},
//                {label:"该时间点的订单量（这一天在这个时间点之前的下单）",name:"expect_num"}
//            ],
//            target: $("#gridPanel_21"),
//            url: '/ccenter/predict/ForTest/Before',
//            loadAfterRendered: false,
//            pagination: true
//        };
//        var gridPanel_21 = new FW.Grid(options_21);
//        gridPanel_21.render();
        $('#search21_btn').click(recentSearch);

        function recentSearch() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);

            $.get('/ccenter/predict/ForTest/Before', params, function (data) {


            }, "json");
        }

        $('#search_btn_v2').click(pageSearch_v2);

        function pageSearch_v2() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);

            $.get('/ccenter/predict/ForTest/Search_v2', params, function (data) {
                gridPanel.setData(data);

            }, "json");
        }



        var dateOptions = {
            dateFormat: "yy-mm-dd"
        };
        $('.date-pick').datepicker(dateOptions);

        function JSONLength(obj) {
            var size = 0, key;
            for (key in obj) {
                if (obj.hasOwnProperty(key)) size++;
            }
            return size;
        }

        $('#city').change(cityChange)
        function cityChange() {
            var selectIndex = $(this).children('option:selected').val();
            if (selectIndex == undefined) selectIndex = '<?= $first_id ?>';
            var objSelectNow = document.getElementById("warehouse");
            objSelectNow.options.length = 0;
            var lenght = JSONLength(warehouse[selectIndex]);
            var objOption = new Array;
            for (var i = 1; i <= lenght; i++) {
                objOption[i] = document.createElement("option");
                objOption[i].text = warehouse[selectIndex][i]["name"];
                objOption[i].value = warehouse[selectIndex][i]["id"];
                objSelectNow.options.add(objOption[i]);
            }
            if(selectIndex==1){
                objOption[2].selected=true;
            }
        }

        var warehouse =<?php echo $warehouselist ?>;

        cityChange();
        $("#class2").val(<?= $class2 ?>);
        $("#warehouse").val(<?= $warehouse ?>);



    });
</script>
<script src="/static/echarts/echarts-all.js"></script>
