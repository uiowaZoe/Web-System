<div class="panel panel-default" xmlns="http://www.w3.org/1999/html">
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>
                <input  type="text" class="form-control date-pick" value="<?= $delivery_time; ?>"

                        name="delivery_time" readonly>
            </div>
            <div class="form-group mc-form-group">
                <label class="control-label">商品名称</label>

                <input type="text" class="form-control "
                       name="item_name" id="item_name" value="<?= $item_name; ?>" readonly >

            </div>
            <div class="form-group mc-form-group">
                <label class="control-label">商品编号</label>

                <input type="text" class="form-control "
                       name="ciid" id="ciid" value="<?= $ciid; ?>" readonly>

            </div>
            <div class="form-group mc-form-group">
                <label>城市</label>
                <input type="text" class="form-control "
                       name="city_name" id="city_name" value="<?= $city_name; ?>" readonly>

                <input type="hidden" class="form-control "
                       name="city" id="city" value="<?= $city; ?>" readonly>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>

                <input type="text" class="form-control "
                       name="warehouse" id="warehouse" value="<?= $warehouse; ?>" readonly>

            </div>

        </form>
    </div>
</div>
<style>
    #main {
        width: 100% min-width : 752 px;
        max-width: 976px;
    }

    #predict {
        background-color: #cccccc;
        border: 2px solid #333333;
        width: 50%;
        height: 400px;
        float: left;
    }

    #diffference {
        background-color: #cccccc;
        border: 2px solid #333333;
        width: 50%;
        height: 400px;
        float: right;
    }

    #diffferencehigh {
        background-color: #cccccc;
        border: 2px solid #333333;
        width: 50%;
        height: 400px;
        float: left;
    }

    #diffferencelow {
        background-color: #cccccc;
        border: 2px solid #333333;
        width: 50%;
        height: 400px;
        float: right;
    }
</style>

<div class="panel panel-default">

    <div class="panel-body" style="padding:8px;">
        <div id="predict" style="border:1px solid #ccc;padding:10px;position:relative"></div>
        <div id="diffference" style="border:1px solid #ccc;padding:10px;position:relative"></div>
        <div id="diffferencehigh" style="border:1px solid #ccc;padding:10px;position:relative"></div>
        <div id="diffferencelow" style="border:1px solid #ccc;padding:10px;position:relative"></div>
    </div>
</div>
<!--Step:2 Import echarts-all.js-->
<!--Step:2 引入echarts-all.js-->
<script src="/static/echarts/echarts-all.js"></script>
<script src="/static/echarts/green.js"></script>
<script type="text/javascript">
    var showpredict=null;
    var showdifference=null;
    var showhigh=null;
    var showlow =null;
    function getShowDate(data, datatype) {
        var y = new Array();
        for (index = 0; index < data.length; index++) {
            if (data[index] != 0) {
                y[index] = data[index][datatype];
            } else {
                y[index] = 0;
            }
        }
        return y;
    }
    $(function () {
        var optionPie = {
            title: {
                text: '今日预测数据',
                subtext: ''
            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name+'<br/>'
                        + "预测值" + ' : ' + showpredict.predict_num[tar.dataIndex] + '<br/>'+
                         "预测最大值"+ ' : ' + showpredict.predict_high[tar.dataIndex]+'<br/>'+
                        "预测最小值"+ ' : ' + showpredict.predict_low[tar.dataIndex] ;
                }
            },
            legend: {
                data: ['预测量','最大预测量','最小预测量'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: true,
                feature: {

                    mark: {show: false},
                    dataView: {show: false, readOnly: true},
                    magicType: {show: false, type: ['line', 'bar']},
                    restore: {show: false}
                }
            },

            calculable: true,

            xAxis: [
                {
                    type: 'category',
                    data:[0],
                    axisLabel: {
                        rotate: 60
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: 'oi量',
                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series: [

                {
                    name: '预测量',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}'
                            }
                        }

                    },
                    data: [1]
                },
                {
                    name: '最大预测量',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}'
                            }
                        }

                    },
                    data: [1]
                },
                {
                    name: '最小预测量',
                    type: 'line',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}'
                            }
                        }

                    },
                    data: [1]
                }
            ]
        };
        var mypredict = echarts.init(document.getElementById('predict'));
        mypredict.setOption(optionPie);


        var optiondiffference = {
            title: {
                text: '误差情况（预测值）',
                subtext: ''
            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name + '<br/>'+
                        "误差值" + ' : ' + showdifference.differ_num_avg[tar.dataIndex] + '<br/>'+
                        "预测值" + ' : ' +showdifference.predict_avg[tar.dataIndex]+'<br/>'+
                        "实际值" + ' : ' +showdifference.expect_num[tar.dataIndex]+'<br/>' +
                        "误差率"+differPercent(showdifference.expect_num[tar.dataIndex], showdifference.predict_avg[tar.dataIndex])+"%";
                }
            },
            legend: {
                data: ['预测值','实际值','误差值'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: true,
                feature: {
                    mark: {show: false},
                    dataView: {show: false, readOnly: false},
                    magicType: {show: false, type: ['line', 'bar']},
                    restore: {show: false}
                }
            },
            calculable: true,
            xAxis: [
                {
                    type: 'category',
                    data: [1],
                    axisLabel: {
                        rotate: 60
                    }
                }

            ],
            yAxis: [
                {
                    type: 'value',
                    name: 'oi量',
                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series:
                [
                    {
                        name: '预测值',
                        type: 'line',
                        itemStyle: {
                            normal: {
                                label: {
                                    show: true,
                                    position: 'top',
                                    formatter: '{c}'
                                }
                            }

                        },
                        data: [1]
                    },


                    {
                        name: '实际值',
                        type: 'line',
                        itemStyle: {
                            normal: {
                                label: {
                                    show: true,
                                    position: 'top',
                                    formatter: '{c}'
                                }
                            }

                        },
                        data: [1]
                    },
                    {
                        name:'实际值2',
                        type:'bar',
                        stack: '1',
                        barWidth: 6,
                        itemStyle:{
                            normal:{
                                color:'rgba(0,0,0,0)'
                            },
                            emphasis:{
                                color:'rgba(0,0,0,0)'
                            }
                        },
                        data:[0]
                    },
                    {
                        name:'误差值',
                        type:'bar',
                        stack: '1',
                        data:[0]
                    }

                ]
        };
        var mydiffference = echarts.init(document.getElementById('diffference'));
        mydiffference.setOption(optiondiffference);

        var optiondiffferencehigh = {
            title: {
                text: '误差情况(预测最大值)',
                subtext: ''
            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name + '<br/>'+
                        "误差值" + ' : ' + showhigh.differ_num_high[tar.dataIndex] + '<br/>'+
                        "预测值" + ' : ' +showhigh.predict_high[tar.dataIndex]+'<br/>'+
                        "实际值" + ' : ' +showhigh.expect_num[tar.dataIndex]+'<br/>' +
                        "误差率"+differPercent(showhigh.expect_num[tar.dataIndex], showhigh.predict_high[tar.dataIndex])+"%";
                }
            },
            legend: {
                data: ['预测最大值','实际值','误差值'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: true,
                feature: {
                    mark: {show: false},
                    dataView: {show: false, readOnly: false},
                    magicType: {show: false, type: ['line', 'bar']},
                    restore: {show: false}
                }
            },
            calculable: true,
            xAxis: [
                {
                    type: 'category',
                    data: [1],
                    axisLabel: {
                        rotate: 60
                    }
                }

            ],
            yAxis: [
                {
                    type: 'value',
                    name: 'oi量',
                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series:
                [
                    {
                        name: '预测最大值',
                        type: 'line',
                        itemStyle: {
                            normal: {
                                label: {
                                    show: true,
                                    position: 'top',
                                    formatter: '{c}'
                                }
                            }

                        },
                        data: [1]
                    },


                    {
                        name: '实际值',
                        type: 'line',
                        itemStyle: {
                            normal: {
                                label: {
                                    show: true,
                                    position: 'top',
                                    formatter: '{c}'
                                }
                            }

                        },
                        data: [1]
                    },
                    {
                        name:'实际值2',
                        type:'bar',
                        stack: '1',
                        barWidth: 6,
                        itemStyle:{
                            normal:{
                                color:'rgba(0,0,0,0)'
                            },
                            emphasis:{
                                color:'rgba(0,0,0,0)'
                            }
                        },
                        data:[0]
                    },
                    {
                        name:'误差值',
                        type:'bar',
                        stack: '1',
                        data:[0]
                    }

                ]
        };
        var mydiffferencehigh = echarts.init(document.getElementById('diffferencehigh'));
        mydiffferencehigh.setOption(optiondiffferencehigh);

        var optiondiffferencelow = {
            title: {
                text: '误差情况（预测最小值）',
                subtext: ''
            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name + '<br/>'+
                        "误差值" + ' : ' + showlow.differ_num_low[tar.dataIndex] + '<br/>'+
                        "预测值" + ' : ' +showlow.predict_low[tar.dataIndex]+'<br/>'+
                        "实际值" + ' : ' +showlow.expect_num[tar.dataIndex]+'<br/>' +
                        "误差率"+differPercent(showlow.expect_num[tar.dataIndex], showlow.predict_low[tar.dataIndex])+"%";
                }
            },
            legend: {
                data: ['预测最小值','实际值','误差值'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: true,
                feature: {
                    mark: {show: false},
                    dataView: {show: false, readOnly: false},
                    magicType: {show: false, type: ['line', 'bar']},
                    restore: {show: false}
                }
            },
            calculable: true,
            xAxis: [
                {
                    type: 'category',
                    data: [1],
                    axisLabel: {
                        rotate: 60
                    }
                }

            ],
            yAxis: [
                {
                    type: 'value',
                    name: 'oi量',
                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series:
                [
                    {
                        name: '预测最小值',
                        type: 'line',
                        itemStyle: {
                            normal: {
                                label: {
                                    show: true,
                                    position: 'top',
                                    formatter: '{c}'
                                }
                            }

                        },
                        data: [1]
                    },


                    {
                        name: '实际值',
                        type: 'line',
                        itemStyle: {
                            normal: {
                                label: {
                                    show: true,
                                    position: 'top',
                                    formatter: '{c}'
                                }
                            }

                        },
                        data: [1]
                    },
                    {
                        name:'实际值2',
                        type:'bar',
                        stack: '1',
                        barWidth: 6,
                        itemStyle:{
                            normal:{
                                color:'rgba(0,0,0,0)'
                            },
                            emphasis:{
                                color:'rgba(0,0,0,0)'
                            }
                        },
                        data:[0]
                    },
                    {
                        name:'误差值',
                        type:'bar',
                        stack: '1',
                        data:[0]
                    }

                ]
        };
        var mydiffferencelow = echarts.init(document.getElementById('diffferencelow'));
        mydiffferencelow.setOption(optiondiffferencelow);


        function predictdata() {
            var params = YC.Util.getFormData("search_form");
            $.get("/ccenter/predict/PredictDetail/SearchPredictData",params,function (data) {
                showpredict=data;
                optionPie.xAxis[0].data = data.xAxis;
                if (data.predict_num.size() > 0&&data.predict_high.size()&&data.predict_low.size()) {
                    optionPie.series[0].data = data.predict_num;
                    optionPie.series[1].data = data.predict_high;
                    optionPie.series[2].data = data.predict_low;
                }
                else {
                    var y = new Array();
                    y[100] = 0;
                    optionPie.series[0].data = y;
                    optionPie.series[1].data = y;
                    optionPie.series[2].data = y;
//
                }
                mypredict.setOption(optionPie);
            }, "json");
        }
        predictdata();
        function differPercent(expect, predict) {

            return expect > 0 ? ((+((predict-expect) / expect).toFixed(4)) * 100).toFixed(2) : 0;
        }

        function differencedata() {

            var params = YC.Util.getFormData("search_form");
            $.get('/ccenter/predict/PredictDetail/Searchdifference',params,function (data) {
                showdifference=data;
                showhigh=data;
                showlow=data;
                optiondiffference.xAxis[0].data = data.xAxiss;
                if (data.expect_num.size() > 0&&data.predict_avg.size() > 0&&data.smallerone_avg.size() > 0
                    &&data.differ_num_avg.size() > 0) {
                    optiondiffference.series[0].data = showdifference.predict_avg;
                    optiondiffference.series[1].data = showdifference.expect_num;
                    optiondiffference.series[2].data = showdifference.smallerone_avg;
                    optiondiffference.series[3].data = showdifference.differ_num_avg;
                } else {
                    var y = new Array();
                    y[100] = 0;
                    optiondiffference.xAxis[0].data = [0];
                    optiondiffference.series[0].data = y;
                    optiondiffference.series[1].data = y;
                    optiondiffference.series[2].data = y;
                    optiondiffference.series[3].data = y;

                }
                mydiffference.setOption(optiondiffference);

                optiondiffferencehigh.xAxis[0].data = showhigh.xAxiss;
                if (data.expect_num.size() > 0&&data.predict_high.size() > 0&&data.smallerone_high.size() > 0
                    &&data.differ_num_high.size() > 0) {
                    optiondiffferencehigh.series[0].data = showhigh.predict_high;
                    optiondiffferencehigh.series[1].data = showhigh.expect_num;
                    optiondiffferencehigh.series[2].data = showhigh.smallerone_high;
                    optiondiffferencehigh.series[3].data = showhigh.differ_num_high;
                } else {
                    var y = new Array();
                    y[100] = 0;
                    optiondiffferencehigh.xAxis[0].data = [0];
                    optiondiffferencehigh.series[0].data = y;
                    optiondiffferencehigh.series[1].data = y;
                    optiondiffferencehigh.series[2].data = y;
                    optiondiffferencehigh.series[3].data = y;

                }
                mydiffferencehigh.setOption(optiondiffferencehigh);

                optiondiffferencelow.xAxis[0].data = showlow.xAxiss;
                if (data.expect_num.size() > 0&&data.predict_low.size() > 0&&data.smallerone_low.size() > 0
                    &&data.differ_num_low.size() > 0) {
                    optiondiffferencelow.series[0].data = showlow.predict_low;
                    optiondiffferencelow.series[1].data = showlow.expect_num;
                    optiondiffferencelow.series[2].data = showlow.smallerone_low;
                    optiondiffferencelow.series[3].data = showlow.differ_num_low;
                } else {
                    var y = new Array();
                    y[100] = 0;
                    optiondiffferencelow.xAxis[0].data = [0];
                    optiondiffferencelow.series[0].data = y;
                    optiondiffferencelow.series[1].data = y;
                    optiondiffferencelow.series[2].data = y;
                    optiondiffferencelow.series[3].data = y;

                }
                mydiffferencelow.setOption(optiondiffferencelow);
            }, "json");
        }
        differencedata();

    })
</script>
