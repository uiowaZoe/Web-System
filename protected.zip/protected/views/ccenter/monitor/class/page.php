<div class="panel panel-default">
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>
                <input type="text" class="form-control date-pick" value="<?= $distribute_t ?>"
                       id="distribute_t" name="distribute_t">
            </div>

            <div class="form-group mc-form-group">
                <label>城市</label>
                <select name="city" id="city" class="form-control">
                    <option value="">全国</option>
                    <?php
                    is_array($result = $first_city) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        $first_id=$key;
                        echo "<option value='" . $key . "' selected >" . $value . "</option>";
                    }
                    is_array($result = $city_list) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        if($key != $first_id){
                            if ($city == $key) {
                                echo "<option value='" . $key . "' selected >" . $value . "</option>";
                            } else {
                                echo "<option value='" . $key . "'>" . $value . "</option>";
                            }
                        }

                        # echo "<option value='" . $key . "'>" . $value . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>
                <select class="form-control" name="warehouse" id="warehouse">
                    <option value=""></option>

                </select>
            </div>
            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>
        </form>
    </div>
</div>

<div class="panel panel-default">

    <div class="panel-body" style="padding:8px;">
        <div>
            <div style="float:left;margin-top:5px;width:100px;font-weight: 600;">仓库总进度</div>
            <div id="total_progress" style="margin:5px 0 10px 0;"></div>
        </div>

    </div>
</div>
<!--Step:1 Prepare a dom for ECharts which (must) has size (width & hight)-->
<!--Step:1 为ECharts准备一个具备大小（宽高）的Dom-->
<style>
    #main {
        width: 100% min-width : 752 px;
        max-width: 976px;
    }

    #class1 {
        background-color: #cccccc;
        border: 2px solid #333333;
        width: 50%;
        height: 400px;
        float: left;
    }

    #class2 {
        background-color: #cccccc;
        border: 2px solid #333333;
        width: 50%;
        height: 400px;
        float: right;
    }
</style>

<div class="panel panel-default">

    <div class="panel-body" style="padding:8px;">
        <div id="class1" style="border:1px solid #ccc;padding:10px;position:relative"></div>
        <div id="class2" style="border:1px solid #ccc;padding:10px;position:relative"></div>
    </div>
</div>
<!--Step:2 Import echarts-all.js-->
<!--Step:2 引入echarts-all.js-->
<script src="/static/echarts/echarts-all.js"></script>
<script src="/static/echarts/green.js"></script>
<script type="text/javascript">
    var dateOptions = {
        dateFormat: "yy-mm-dd"
    };
    $('.date-pick').datepicker(dateOptions);
    var showdata1=null;
    var showdata2=null;
    $(function () {

        function JSONLength(obj) {
            var size = 0, key;
            for (key in obj) {
                if (obj.hasOwnProperty(key)) size++;
            }
            return size;
        }

        $('#city').change(cityChange)
        function cityChange() {
            var selectIndex = $(this).children('option:selected').val();

            if (selectIndex == undefined) selectIndex = '<?= $first_id ?>';
            var objSelectNow = document.getElementById("warehouse");
            objSelectNow.options.length = 0;
            var lenght = JSONLength(warehouse[selectIndex]);
            if (lenght > 1) {
                var objOption = document.createElement("option");
                objOption.text = "全部";
                objOption.value = "";
                objSelectNow.options.add(objOption);
            }
            for (var i = 1; i <= lenght; i++) {
                var objOption = document.createElement("option");
                objOption.text = warehouse[selectIndex][i]["name"];
                objOption.value = warehouse[selectIndex][i]["id"];
                objSelectNow.options.add(objOption);
            }
        }
        var warehouse =<?php echo $warehouselist ?>;
        cityChange();
        var optionPie = {
            title: {
                text: '大类进度情况',
                subtext: ''
            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value + '%<br/>完成' + showdata1.real_num[tar.dataIndex]+ "/总共" + showdata1.expect_num[tar.dataIndex];
                }
            },
            legend: {
                data: ['完成百分比','oi数量', '已分拣oi数'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: true,
                feature: {

                    mark: {show: false},
                    dataView: {show: false, readOnly: false},
                    magicType: {show: false, type: ['line', 'bar']},
                    restore: {show: false}
                }
            },

            calculable: true,

            xAxis: [
                {
                    type: 'category',
                    data: [0],
                    axisLabel: {
                        rotate: 60
                    }
                }
            ],
            yAxis: [
                {
                    max: 120,
                    type: 'value',
                    name: '分拣率',
                    axisLabel: {
                        formatter: '{value} %'
                    }
                    //splitArea : {show : true}
                },
                {
                    type: 'value',
                    name: 'oi量',
                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series: [

                {
                    name: '完成百分比',
                    type: 'bar',
                    yAxisIndex: 0,
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [1]
                },
                {
                    name: 'oi数量',
                    type: 'bar',
                    yAxisIndex: 1,
                    data: [1]
                },
                {
                    name: '已分拣oi数',
                    type: 'bar',
                    yAxisIndex: 1,

                    data: [1]
                }
            ]
        }
        var myclass1 = echarts.init(document.getElementById('class1'));
        myclass1.setOption(optionPie);


        var optionClass2 = {
            title: {
                text: '小类进度情况',
                subtext: ''
            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value + '%<br/>完成' + showdata2.real_num[tar.dataIndex] + "/总共" + showdata2.expect_num[tar.dataIndex];
                    return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value + '%<br/>';
                }
            },
            legend: {
                data: ['完成百分比','oi数量', '已分拣oi数'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: true,
                feature: {
                    mark: {show: false},
                    dataView: {show: false, readOnly: false},
                    magicType: {show: false, type: ['line', 'bar']},
                    restore: {show: false}
                }
            },
            calculable: true,
            xAxis: [
                {
                    type: 'category',
                    data: [1],
                    axisLabel: {
                        rotate: 60
                    }
                }

            ],
            yAxis: [
                {
                    max: 120,
                    type: 'value',
                    name: '分拣率',
                    axisLabel: {
                        formatter: '{value} %'
                    }
                    //splitArea : {show : true}
                },
                {
                    type: 'value',
                    name: 'oi量',
                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series: [

                {
                    name: '完成百分比',
                    type: 'bar',
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter: '{c}%'
                            }
                        }

                    },
                    data: [1]
                },
                {
                    name: 'oi数量',
                    type: 'bar',
                    yAxisIndex: 1,
                    data: [1]
                },
                {
                    name: '已分拣oi数',
                    type: 'bar',
                    yAxisIndex: 1,

                    data: [1]
                }

            ]
        }


        var myclass2 = echarts.init(document.getElementById('class2'));
        myclass2.setOption(optionClass2);


        var ecConfig = echarts.config;

        function eConsole(param) {
         //   alert(JSON.stringify(param));
          //  alert(param.dataIndex);
            switch (param.dataIndex) {

                <?php  foreach( $class1_Ids as $index=>$value){//依次取出数组中元素，$a是元素的键名$b是键值
                                echo '
                         case '.($index).':    //柱子1
                            flushdata2('.$value.');
                         break;';
                            }
                 ?>

                default:
                    break;
//
            }

        }

        myclass1.on(ecConfig.EVENT.CLICK, eConsole);

        function eConsole2(param) {
            for (var key in class2_Ids) {
                if (param.dataIndex == key) {
                    window.location.href = "/ccenter/monitor/cis/page?class2=" + class2_Ids[key] + "&distribute_t=" + $("#distribute_t").val() + "&city=" + $("#city").val() + "&warehouse=" + $("#warehouse").val() + "&class1=" + class1_id;
                    break;
                }
            }
        }


        function calPercent(separated, total) {
            return total > 0 ? ((+(separated / total).toFixed(4)) * 100).toFixed(2) : 0;
        }

        function renderProgress(separated, total) {
            var percent = calPercent(separated, total);
            var html = '<div class="progress" style="height:28px;margin-bottom:2px;">';
            html += '<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="color:#F03;font-weight:bold;line-height:28px;width: ' + percent + '%">';
            html += '<span style="margin-left:5px;">' + percent + '%&nbsp;&nbsp;(' + separated + '/' + total + ')</span>';
            html += '</div>';
            html += '</div>';
            return html;
        }

        $('#search_btn').click(function () {
            var y = new Array()
            y[100] = 0;
            optionPie.xAxis[0].data = [0];
            optionPie.series[0].data = y;
            optionPie.series[1].data = y;
            optionPie.series[2].data = y;
            myclass1.setOption(optionPie);

            var params = YC.Util.getFormData("search_form");
            $.get('/ccenter/monitor/class/searchclass1', params, function (data) {
                showdata1 = data;
                optionPie.xAxis[0].data = data.xAxis;
                //alert(data.data.size())
                if (data.data.size() > 0) {
                    optionPie.series[0].data = data.rate;
                    optionPie.series[1].data = data.expect_num;
                    optionPie.series[2].data = data.real_num;
                } else {
                    var y = new Array();
                    y[100] = 0;
                    optionPie.series[0].data = y;
                    optionPie.series[1].data = y;
                    optionPie.series[2].data = y;
                }
                myclass1.setOption(optionPie);
                $('#total_progress').html(renderProgress(data.realNum, data.expectNum));
            }, "json");
            <?php echo '
                    flushdata2('.$class1_Ids[0].');';
  			?>
        });
        function getShowDate(data, datatype) {
            var y = new Array();
            var index = 0
            for (index = 0; index < data.length; index++) {
                if (data[index] != 0) {
                    y[index] = data[index][datatype];
                } else {
                    y[index] = 0;
                }
            }
            return y;
        }

        var class1_id;
        var class2_Ids;//yzx

        function flushdata2(class1Id) {


            var class1Id = class1Id;
            var params = YC.Util.getFormData("search_form");
            $.get('/ccenter/monitor/class/searchclass2?class1_Id=' + class1Id, params, function (data) {
                showdata2=data;
                optionClass2.xAxis[0].data = data.xAxis;
                optionClass2.series[0].data = data.rate;
                if (data.data.size() > 0) {
                    optionClass2.series[0].data = data.rate;
                    optionClass2.series[1].data = data.expect_num;
                    optionClass2.series[2].data = data.real_num
                } else {
                    var y = new Array();
                    y[100] = 0;
                    optionClass2.series[0].data = y;
                    optionClass2.series[1].data = y;
                    optionClass2.series[2].data = y;
                }
                class2_Ids = data.class2_Ids;//yzx
                class1_id = data.class1Id;

                var myclass2 = echarts.init(document.getElementById('class2'));
                myclass2.setOption(optionClass2);
                myclass2.on(ecConfig.EVENT.CLICK, eConsole2);
            }, "json");
        }

//        cityChange();
        $('#search_btn').click();

    })
</script>
