<div class="panel panel-default">
    <div class="panel-body">
        <form id="search_form" class="form" role="form">

            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>
                <input type="text" class="form-control date-pick" value="<?= $distribute_t ?>"
                       name="distribute_t">
            </div>
            <div class="form-group mc-form-group">
                <label>城市</label>
                <select name="city" id="city" class="form-control">
                    <option value="">全国</option>
                    <?php
                    is_array($result = $first_city) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        $first_id=$key;
                        echo "<option value='" . $key . "' selected >" . $value . "</option>";
                    }
                    is_array($result = $city_list) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        if($key != $first_id){
                            if ($city == $key) {
                                echo "<option value='" . $key . "' selected >" . $value . "</option>";
                            } else {
                                echo "<option value='" . $key . "'>" . $value . "</option>";
                            }
                        }

                        # echo "<option value='" . $key . "'>" . $value . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>

                <select class="form-control" name="warehouse" id="warehouse">

                </select>
            </div>

            <div class="form-group mc-form-group">
                <label>大类查询</label>
                <select name="class1" id="class1" class="form-control">
                    <option value=''>全部</option>
                    <?php
                    foreach ($class1_list as $key => $value) {
                        echo "<option value='" . $value["id"] . "'>" . $value["name"] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group mc-form-group">
                <label>小类查询</label>
                <select name="class2" id="class2" class="form-control">

                </select>

            </div>

            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>

            <div class="form-group mc-form-group">
                <label>
                    <input type="radio" name="showtype" value="0" checked>订单数量
                </label>
                <!-- <label>
                     <input type="radio" name="showtype" value="1">订购重量
                 </label>
                 -->
            </div>

            <div class="form-group mc-form-group">

                <label> <input id="freshcheck" type="checkbox" name="flushstate">自动刷新</label>

                <label>
                    <div id="colockbox"></div>
                </label>


            </div>
        </form>
    </div>
</div>
<!--Step:1 Prepare a dom for ECharts which (must) has size (width & hight)-->
<!--Step:1 为ECharts准备一个具备大小（宽高）的Dom-->
<div id="main" style="height:500px;border:1px solid #ccc;padding:10px;"></div>

<!--Step:2 Import echarts-all.js-->
<!--Step:2 引入echarts-all.js-->
<script src="/static/echarts/echarts-all.js"></script>
<script src="/static/echarts/green.js"></script>

<script type="text/javascript">

    var warehouse =<?php echo $warehouselist ?>;
    var class2_list =<?php echo $class2_list ?>;

    function JSONLength(obj) {
        var size = 0, key;
        for (key in obj) {
            if (obj.hasOwnProperty(key)) size++;
        }
        return size;
    }

    $('#city').change(cityChange)
    function cityChange() {
        var selectIndex = $(this).children('option:selected').val();

        if (selectIndex == undefined) selectIndex = '<?= $first_id ?>';
        var objSelectNow = document.getElementById("warehouse");
        objSelectNow.options.length = 0;
        var lenght = JSONLength(warehouse[selectIndex]);

        if (lenght > 1) {
            var objOption = document.createElement("option");
            objOption.text = "全部";
            objOption.value = "";
            objSelectNow.options.add(objOption);
        }
        for (var i = 1; i <= lenght; i++) {
            var objOption = document.createElement("option");
            objOption.text = warehouse[selectIndex][i]["name"];
            objOption.value = warehouse[selectIndex][i]["id"];
            objSelectNow.options.add(objOption);
        }
    }
    cityChange();

    $('#class1').change(class1Change)
    function class1Change() {

        var selectIndex = $(this).children('option:selected').val();
        var class1value = $("#class1").val();
        // alert(class1value)
        if (selectIndex == undefined) selectIndex = '<?= $city ?>';

        var objSelectNow = document.getElementById("class2");
        objSelectNow.options.length = 0;
        var lenght = class2_list.size();
        // alert(JSON.stringify(class2_list[selectIndex][1]))
        if (lenght > 1) {
            var objOption = document.createElement("option");
            objOption.text = "全部";
            objOption.value = "";
            objSelectNow.options.add(objOption);
        }
        for (var i = 0; i < lenght; i++) {
            if (class2_list[i]["class1_id"] == class1value) {
                var objOption = document.createElement("option");
                objOption.text = class2_list[i]["name"];
                objOption.value = class2_list[i]["id"];
                objSelectNow.options.add(objOption);
            }
        }
    }
    class1Change();


    function js_date_time(unixtime) {
        var timestr = new Date(parseInt(unixtime) * 1000);
        var datetime = timestr.toLocaleString().replace(/年|月/g, "-").replace(/日/g, " ");
        return datetime;
    }
    var myChart = echarts.init(document.getElementById('main'), "");
    option = {
        title: {
            text: '仓库进度情况',
            subtext: '',
            textStyle: {
                fontSize: 20,
                fontWeight: 'bolder',
                color: '#F03'          // 主标题文字颜色
            }
        },
        tooltip: {
            trigger: 'axis',

            formatter: function (params) {

                // alert(JSON.stringify(params))
                var tar = params[0];
                // alert(showdata[tar.dataIndex])
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value + '%<br/>完成' + showdata[tar.dataIndex]["real"] + "/总共" + showdata[tar.dataIndex]["expect"];
            }

        },
        legend: {
            data: ['oi数量', '已分拣oi数', '完成百分比'],
            x: 'right',
            itemWidth: 30
        },
        toolbox: {
            show: true,
            feature: {
                mark: {show: false},
                dataView: {show: false, readOnly: false},
                magicType: {show: false, type: ['line', 'bar']},
                restore: {show: false},
                saveAsImage: {show: false}
            }
        },
        calculable: true,
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                // data : ['周一','周二','周三','周四','周五','周六','周日']
                data: []
            }
        ],
        yAxis: [
            {
                max: 120,
                type: 'value',
                name: '分拣率',
                axisLabel: {
                    formatter: '{value} %'
                }
                //splitArea : {show : true}
            },
            {
                type: 'value',
                name: 'oi量',
                axisLabel: {
                    formatter: '{value} '
                }
            }
        ],
        series: [
            {
                name: '完成百分比',
                type: 'bar',
                itemStyle: {
                    normal: {
                        label: {
                            show: true, position: 'top',
                            formatter: '{c}%'
                        }
                    }, emphasis: {label: {show: true}}
                },
                data: []
            }
            ,
            {
                name: 'oi数量',
                type: 'line',
                yAxisIndex: 1,
                data: [0]
            }
            ,
            {
                name: '已分拣oi数',
                type: 'line',
                yAxisIndex: 1,
                data: [0]
            }
        ]
    }
    var showdata = null;
    $('#search_btn').click(function () {
        var y = new Array()
        y[100] = 0;
        option.xAxis[0].data = [0];
        option.series[0].data = y;
        option.series[1].data = y;
        option.series[2].data = y;
        myChart.setOption(option);
        flushdata();
    });
    function flushdata() {
        var params = YC.Util.getFormData("search_form");

        $.get('/ccenter/monitor/timeLine/search', params, function (data) {
            showdata = data.data;
            option.xAxis[0].data = data.xAxis;
            if (data.data.size() > 0) {
                option.series[0].data = getShowDate(data.data, "rate")
                option.series[1].data = getShowDate(data.data, "expect")
                option.series[2].data = getShowDate(data.data, "real")
            } else {
                var y = new Array();
                y[100] = 0;
                option.xAxis[0].data = [0];
                option.series[0].data = y;
                option.series[1].data = y;
                option.series[2].data = y;
            }
            myChart.setOption(option);
        }, "json");

        $.get('/ccenter/monitor/timeLine/now', params, function (data) {
            nowdata = data.nowdata;
            time = data.nowtime;
            if (nowdata.expect == null) {
                nowdata.expect = 0;
            }
            if (nowdata.real == null) {
                nowdata.real = 0;
            }
            if (nowdata.rate == null) {
                nowdata.rate = 0;
            }
            else {
                option.title.text = '截止' + time + '  oi数量：' + nowdata.expect + '  已分拣oi数：' + nowdata.real + '  分拣率：' + nowdata.rate + "%";
                option.title.subtext = nowdata.sub;
            }
            option.title.text = '截止' + time + '  oi数量：' + nowdata.expect + '  已分拣oi数：' + nowdata.real + '  分拣率：' + nowdata.rate + "%";
            option.title.subtext = nowdata.sub;


            myChart.setOption(option);
        }, "json");

    }
    function getShowDate(data, datatype) {
        var y = new Array();
        var index = 0
        for (index = 0; index < data.length; index++) {
            if (data[index] != 0) {
                y[index] = data[index][datatype];
            } else {
                y[index] = 0;
            }
        }
        return y;
    }
    var dateOptions = {
        dateFormat: "yy-mm-dd"
    };
    $('.date-pick').datepicker(dateOptions);


    $('#search_btn').click();
   // var ecConfig = echarts.config;
    //alert(ecConfig)
//    function eConsole(param) {
//        switch (param.dataIndex) {
//            case 0:    //柱子1
//                window.location.href = "/ccenter/monitor/class/page?city=1&distribute_t=" + $("#distribute_t").val();
//                break;
//            case 1:    //柱子1
//                window.location.href = "/ccenter/monitor/class/page?city=2&distribute_t=" + $("#distribute_t").val();
//                break;
//            case 2:    //柱子1
//            default:
//                break;
//        }
//    }
 //   myChart.on(ecConfig.EVENT.CLICK, eConsole);
</script>
<script type="application/javascript">
    $('#freshcheck').click(freshcheckchange);
    var timer = null;
    var maxtime=<?php echo $flushinterval ?>;
    function freshcheckchange() {
        if ($("#freshcheck").is(':checked')) {
            $("#colockbox").text(maxtime);
            timer = setInterval(autoTime, 1000);
        } else {
            clearInterval(timer);
            $("#colockbox").text("");
        }
    }
    //每一秒执行一次时间更新
    function autoTime() {
        t = $("#colockbox").text();
        iRemain = t - 1;
        if (iRemain <= 0) { //如果小于零，清除调用自己，并且返回
            flushdata();
            iRemain = maxtime;
        }
        $("#colockbox").text(iRemain);
    }

</script>
