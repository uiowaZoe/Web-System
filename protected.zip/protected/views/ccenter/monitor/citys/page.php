<div class="panel panel-default">
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>
                <input type="text" class="form-control date-pick" value="<?= $distribute_t ?>"
                       name="distribute_t" id="distribute_t">
            </div>
            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>
        </form>
    </div>
</div>

<!--Step:1 Prepare a dom for ECharts which (must) has size (width & hight)-->
<!--Step:1 为ECharts准备一个具备大小（宽高）的Dom-->
<div id="main" style="height:500px;border:1px solid #ccc;padding:10px;"></div>

<!--Step:2 Import echarts-all.js-->
<!--Step:2 引入echarts-all.js-->
<script src="/static/echarts/echarts-all.js"></script>
<script src="/static/echarts/green.js"></script>
<script type="text/javascript">
    $(function () {
        var dateOptions = {
            dateFormat: "yy-mm-dd"
        };
        $('.date-pick').datepicker(dateOptions);
        var myChart = echarts.init(document.getElementById('main'));

        var optionPie = {
            title: {
                text: '全国分拣进度情况',
                subtext: '各城市分拣进度'

            },
            tooltip: {
                trigger: 'axis',
                formatter: function (params) {
                    var tar = params[0];

                    return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value + '%<br/>完成' + params[2].value+ "/总共" + params[1].value;
                }
            },

            legend: {
                data: ['完成百分比','oi数量', '已分拣oi数'],
                x: 'right',
                itemWidth: 50
            },
            toolbox: {
                show: false,
                feature: {
                    mark: {show: false},
                    dataView: {show: true, readOnly: false},
                    magicType: {show: true, type: ['line', 'bar']},
                    restore: {show: false},
                    saveAsImage: {show: false}
                }
            },
            calculable: false,
            dataZoom : {
                show : true,
                start : 2,
                end : 60
            },
            xAxis: [
                {
                    type: 'category',
                    axisLabel: {
                        interval: 0
                    },

                    data: [0]
                }
            ],
            yAxis: [
                {
                    max: 120,
                    type: 'value',
                    name: '完成百分比',
                    axisLabel: {
                        formatter: '{value} %'
                    }
                    //splitArea : {show : true}
                },
                {
                    type: 'value',
                    name: 'oi量',
                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series: [
                {
                    name: '完成百分比',
                    type: 'bar',
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                position: 'top',
                                formatter:'{c} %'
                            }
                        }, emphasis: {label: {show: true}}
                    },
                    data: [1]
                },
                {
                    name: 'oi数量',
                    type: 'bar',
                    yAxisIndex: 1,

                    data: [1]
                },
                {
                    name: '已分拣oi数',
                    type: 'bar',
                    yAxisIndex: 1,
                    data: [1]
                }

            ]
        };
        function getShowDate(data, datatype) {
            var y = new Array();
            var index = 0;
            for (index = 0; index < data.length; index++) {
                if (data[index] != 0) {
                    y[index] = data[index][datatype];
                } else {
                    y[index] = 0;
                }
            }
            return y;
        }
        myChart.setOption(optionPie);
        var ecConfig = echarts.config;
        //alert(ecConfig)
        function eConsole(param) {
            switch (param.dataIndex) {
                <?php
                 $index=0;
                 foreach( $city_list as $id=>$value){//依次取出数组中元素，$a是元素的键名$b是键值
                                echo '
                         case '.$index.':    //柱子1
                         window.location.href = "/ccenter/monitor/class/page?city='.$id.'&distribute_t="+$("#distribute_t").val();
                         break;';
                         $index++;
                            }
                 ?>
                default:
                    break;
            }
        }
        myChart.on(ecConfig.EVENT.CLICK, eConsole);


        var showdata=null;

        $('#search_btn').click(function () {
            var params = YC.Util.getFormData("search_form");
            $.get('/ccenter/monitor/citys/search', params, function (data) {
                showdata = data;
                optionPie.xAxis[0].data = data["xAxis"];
                if (data.rate.size() > 0 ) {
                    optionPie.series[0].data = data["rate"];
                    optionPie.series[1].data = data["expect"];
                    optionPie.series[2].data = data["real"];
                } else {
                    var y = new Array();
                    y[300] = 0;
                    optionPie.series[0].data = y;
                    optionPie.series[1].data = y;
                    optionPie.series[2].data = y;
                }
                myChart.setOption(optionPie);
            }, "json");
        });
        $('#search_btn').click();
        //myChart.setOption(option);
    });

</script>
