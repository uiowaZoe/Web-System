<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">查询条件</h3>
    </div>
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>

                <input type="text" class="form-control date-pick" value="<?= $distribute_t; ?>"

                       name="distribute_t">
                <!--                <input type="text" class="form-control date-pick" value="-->
                <? //= date('Y-m-d', time()); ?><!--"-->
                <!--                       name="distribute_t">-->
            </div>
            <div class="form-group mc-form-group">
                <label>城市</label>
                <select name="city" id="city" class="form-control">
                    <option value="">全国</option>
                    <?php
                    is_array($result = $first_city) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        $first_id=$key;
                        echo "<option value='" . $key . "' selected >" . $value . "</option>";
                    }
                    is_array($result = $city_list) ? null : $result = array();
                    foreach ($result as $key => $value) {
                        if($key != $first_id){
                            if ($city == $key) {
                                echo "<option value='" . $key . "' selected >" . $value . "</option>";
                            } else {
                                echo "<option value='" . $key . "'>" . $value . "</option>";
                            }
                        }

                        # echo "<option value='" . $key . "'>" . $value . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>

                <select class="form-control" name="warehouse" id="warehouse">

                </select>
            </div>


            <div class="form-group mc-form-group">
                <label>大类查询</label>
                <select name="class1" id="class1" class="form-control">
                    <option value=''>全部</option>
                    <?php

                    //                    is_array($result = $class1_list) ? null : $result = array();
                    foreach ($class1_list as $key => $value) {
                        #echo "<option value='" . $value["id"] . "'>" . $value["name"] . "</option>";
                        if ($class1 == $value['id']) {
                            echo "<option value='" . $value['id'] . "' selected >" . $value['name'] . "</option>";
                        } else {
                            echo "<option value='" . $value['id'] . "'>" . $value['name'] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group mc-form-group">
                <label>小类查询</label>
                <select name="class2" id="class2" class="form-control">

                </select>

            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">名称查询</label>

                <input type="text" class="form-control "
                       name="item_name" id="item_name" placeholder="请输入商品名称">

            </div>

            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>
        </form>
    </div>
</div>
<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">生产分拣监控</h3></li>
    </ul>
</div>
<div id="gridPanel"></div>
<script>
    $(function () {

        FW.ClassRenderer = Class.create(FW.Grid.DefaultColumnRenderer, {
            cell: function (grid, column, record) {
                var cityId = '1'//YC.user.city_id;
                var kind = record.get('class1');
                if (cityId == '1') {
                    if (kind == 1) {
                        return '蔬菜水果';
                    } else if (kind == 2) {
                        return '禽蛋肉类';
                    } else if (kind == 3) {
                        return '米面粮油';
                    } else if (kind == 4) {
                        return '调料其他';
                    } else if (kind == 5) {
                        return '水产冻货';
                    } else if (kind == 8) {
                        return '酒水饮料';
                    } else if (kind == 11) {
                        return '餐厨用品';
                    } else if (kind == 16) {
                        return '8月特惠';
                    } else {
                        return '未知';
                    }
                } else {
                    return class1;
                }
            }
        });
        function calPercent(separated, total) {
            return total > 0 ? ((+(separated / total).toFixed(4)) * 100).toFixed(2) : 0;
        }

        function renderProgress(separated, total) {
            var percent = calPercent(separated, total);
            var html = '<div class="progress" style="height:28px;margin-bottom:2px;">';
            html += '<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="color:#ddd;line-height:28px;width: ' + percent + '%">';
            html += '<span style="margin-left:5px;">' + percent + '%&nbsp;&nbsp;(' + separated + '/' + total + ')</span>';
            html += '</div>';
            html += '</div>';
            return html;
        }

        FW.ProgressRenderer = Class.create(FW.Grid.DefaultColumnRenderer, {
            cell: function (grid, column, record) {
                var real_num = +record.get('real_num');
                var expect_num = +record.get('expect_num');
                return renderProgress(real_num, expect_num);


            }
        });

        var options = {
            id: "grid_index",
            columns: [
                {label: "标品编号", name: "siid"},
                {label: "商品编号", name: "ciid"},
                {label: "一级分类", name: "class1", renderer: "FW.ClassRenderer", htmlSafe: true},
                {label: "二级分类", name: "class2_name"},
                {label: "品名", name: "item_name"},
                {label: "oi数", name: "expect_num"},
                {label: "下单总斤数", name: "expect_weight"},
                {label: "已分拣oi数", name: "real_num"},
                {label: "已分拣斤数", name: "real_weight"},
                {label: "配送时间", name: "delivery_time"},
                {label: "分拣完成比例", name: "accomplish_sorting", renderer: "FW.ProgressRenderer", htmlSafe: true}
            ],
            target: $("#gridPanel"),
            url: '/ccenter/monitor/cis/SearchCis',
            loadAfterRendered: false,
            pagination: true
        };
        var gridPanel = new FW.Grid(options);
        gridPanel.render();
        $('#search_btn').click(pageSearch);

        function pageSearch() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);

            $.get('/ccenter/monitor/cis/SearchCis', params, function (data) {
                gridPanel.setData(data);
                var total_count = 0;
                var separated_count = 0;
                var total_vegetable_count = 0;
                var separated_vegetable_count = 0;
                var total_other_count = 0;
                var separated_other_count = 0;
                _.each(data, function (item) {
                    total_vegetable_count += +item.vegetable_count;
                    separated_vegetable_count += +item.separated_vegetable_count;
                    total_other_count += +item.other_count;
                    separated_other_count += +item.separated_other_count;
                    total_count += +item.vegetable_count + +item.other_count;
                    separated_count += +item.separated_vegetable_count + +item.separated_other_count;
                });

            }, "json");
        }

        var dateOptions = {
            dateFormat: "yy-mm-dd"
        };
        $('.date-pick').datepicker(dateOptions);

        function JSONLength(obj) {
            var size = 0, key;
            for (key in obj) {
                if (obj.hasOwnProperty(key)) size++;
            }
            return size;
        }

        $('#city').change(cityChange)
        function cityChange() {
            var selectIndex = $(this).children('option:selected').val();

            if (selectIndex == undefined) selectIndex = '<?= $first_id ?>';
            var objSelectNow = document.getElementById("warehouse");
            objSelectNow.options.length = 0;
            var lenght = JSONLength(warehouse[selectIndex]);
            if (lenght > 1) {
                var objOption = document.createElement("option");
                objOption.text = "全部";
                objOption.value = "";
                objSelectNow.options.add(objOption);
            }
            for (var i = 1; i <= lenght; i++) {
                var objOption = document.createElement("option");
                objOption.text = warehouse[selectIndex][i]["name"];
                objOption.value = warehouse[selectIndex][i]["id"];
                objSelectNow.options.add(objOption);
            }
        }

        var warehouse =<?php echo $warehouselist ?>;
        var class2_list =<?php echo $class2_list ?>;
        $('#class1').change(class1Change);
        function class1Change() {

            var selectIndex = $(this).children('option:selected').val();
            var class1value = $("#class1").val()
            // alert(class1value)
            if (selectIndex == undefined) selectIndex = '<?= $city ?>';

            var objSelectNow = document.getElementById("class2");
            objSelectNow.options.length = 0;
            var lenght = class2_list.size();
            var objOption = document.createElement("option");
            objOption.text = "全部";
            objOption.value = "";
            objSelectNow.options.add(objOption);

            for (var i = 0; i < lenght; i++) {
                if (class2_list[i]["class1_id"] == class1value) {
                    var objOption = document.createElement("option");
                    objOption.text = class2_list[i]["name"];
                    objOption.value = class2_list[i]["id"];
                    objSelectNow.options.add(objOption);
                }
            }
        }

        cityChange();
        class1Change();
        $("#class2").val(<?= $class2 ?>);
        $("#warehouse").val(<?= $warehouse ?>);

        pageSearch();


    });
</script>
<script src="/static/echarts/echarts-all.js"></script>
