<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">系统参数列表</h3></li>
    </ul>
</div>
<div id="gridPanel"></div>


<!--点击编辑图标后的弹出框-->
<script id="flushinter_render_tmpl" type="text/x-handlebars-template">
    <div id="dialog_message"></div>
    <form method="GET" action="{{action}}" class="form-horizontali row" role="form" name="flushinter">
        <div class="form-group mc-form-group">
            <input type="hidden" class="form-control" name="skey" value="{{skey}}"/>
            <input type="hidden" class="form-control" name="sname" value="{{sname}}"/>
            <label name="sname" id="sname">{{sname}}</label>
            <input type="text" class="form-control" name="svalue" value="{{svalue}}"/>
        </div>
    </form>
</script>
<script id="dataflush_render_tmpl" type="text/x-handlebars-template">
    <div id="dialog_message"></div>
    <form method="GET" action="{{action}}" class="form-horizontali row" role="form" name="flushdata">
        <div class="form-group mc-form-group">
            <input type="hidden" class="form-control" name="skey" value="{{skey}}"/>
            <input type="hidden" class="form-control" name="sname" value="{{sname}}"/>
            <label name="sname" id="sname">{{sname}}</label>
            <select name="svalue" id="svalue" class="form-control">
                <option value="{{svalue}}" selected >{{svalue}}</option>
                <option value="1"  >1</option>
                <option value="0"  >0</option>
            </select>
        </div>

    </form>
</script>
<script>
    $(function () {
        /*ui表格的按钮*/

        var UidemoActionDialogOption = {
            header: '',
            handlers: [
                {label:"取消", class:"-step-cancel"},
                {
                    label:"确定",
                    callback: function(){
                        $dialog = this.$dialog;
                        $component = this.component;
                        var gridPanel = $("#gridPanel").grid();//渲染
                        $dialog.find("form").ajaxSubmit({
                            data:{},
                            dataType:'json',
                            success: function(data){
                                var flush =data.svalue;
                                if(data==undefined) {
                                    FW.GlobalMessage.addMessages(data.messages, $dialog.find('#dialog_message'));

                                } else {
                                    $dialog.modal("hide");
                                    if (gridPanel != null) {
                                        gridPanel.setData(data);//回调填充数据并重新加载修改后的最新页面
                                    }
                                }
                            }
                        });
                        return false;
                    }
                }
            ]
        };
        /*dialog生成函数*/
        var flushinterActionDialog = FW.Component.XXX1TTT = Class.create(FW.Component.Base, FW.Component.WizardSupport, {
            render: function() {
                var source = $('#flushinter_render_tmpl').html();
                var template = Handlebars.compile(source);
                var context = this.option("data");
                var $dom = $(template(context));
                this._setDom($dom);

                return this.$dom;
            }
        });

        FW.Component.ActAsDialog(flushinterActionDialog, UidemoActionDialogOption);

        var dataflushActionDialog = FW.Component.XXX1TTT = Class.create(FW.Component.Base, FW.Component.WizardSupport, {
            render: function() {
                var source = $('#dataflush_render_tmpl').html();
                var template = Handlebars.compile(source);
                var context = this.option("data");
                var $dom = $(template(context));
                this._setDom($dom);

                return this.$dom;
            }
        }); FW.Component.ActAsDialog(dataflushActionDialog, UidemoActionDialogOption);
        FW.GridActionRenderer = Class.create(FW.ActionsRenderer, {
            addActions: function($content, grid, colum, record) {
                var $editLink = $("<a>").append("<i class='fa fa-pencil-square-o'></i>");
                $editLink.attr("title", "编辑");
                $editLink.attr("href", "javascript:void(0)");
                $editLink.click(function(){
                    var data = {
                        skey: record.get("skey"),
                        sname: record.get("sname"),
                        svalue: record.get("svalue"),
                        action: "/ccenter/monitor/systemdata/edit" //确定后,发送表单提交处理的url，同其action一致
                    };
                    if (data.skey=="dataflush"){
                        new dataflushActionDialog.asDialog({data:data}).show({}, {header: "编辑dataflush参数"});
                    }
                    else {
                        new flushinterActionDialog.asDialog({data:data}).show({}, {header: "编辑参数"});
                    }
                });
                $content.append($editLink);
            }
        });

        var options = {
            id: "grid_index",
            columns: [
                {label: "skey", name: "skey"},
                {label: "sname", name: "sname"},
                {label: "svalue", name: "svalue"},
                { label: "操作", renderer: "FW.GridActionRenderer", virtual:true, htmlSafe: true}
            ],
            target: $("#gridPanel"),
            url: '/ccenter/monitor/systemData/getdata',
            loadAfterRendered: false,
            pagination: false
        };


        var gridPanel = new FW.Grid(options);
        gridPanel.render();

        function pageShow(){
            $.get('/ccenter/monitor/systemData/getdata', function (data) {
                gridPanel.setData(data);
            }, "json");
        }
        pageShow();//  先触发进入展示列表数据

    });
</script>
