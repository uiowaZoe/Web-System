<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">查询条件</h3>
    </div>
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>
                <input type="text" class="form-control date-pick" value="<?=date('Y-m-d',time());?>" name="distribute_t">
            </div>
            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>
        </form>
    </div>
</div>
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">进度</h3>
    </div>
    <div class="panel-body" style="padding:8px;">
        <div>
            <div style="float:left;margin-top:5px;width:64px;font-weight: 600;">总进度</div>
            <div id="total_progress" style="margin:5px 0 10px 0;"></div>
        </div>
        <div>
            <div style="float:left;margin-top:5px;width:64px;font-weight: 600;">蔬菜进度</div>
            <div id="vegetable_progress" style="margin:5px 0 10px 0;"></div>
        </div>
        <div>
            <div style="float:left;margin-top:5px;width:64px;font-weight: 600;">其他进度</div>
            <div id="other_progress" style="margin:5px 0 10px 0;"></div>
        </div>
    </div>
</div>
<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">线路分拣监控</h3></li>
    </ul>
</div>
<div id="gridPanel"></div>
<script>
    $(function() {

        FW.OperateAreaRenderer = Class.create(FW.Grid.DefaultColumnRenderer, {
            cell : function(grid, column, record) {
                var cityId = '1'//YC.user.city_id;
                var operate_area = record.get('operate_area');
                if(cityId == '1') {
                    if (operate_area == 1) {
                        return '北京仓库1';
                    } else if (operate_area == 2) {
                        return '北京仓库2';
                    } else {
                        return '未知';
                    }
                }else{
                    return operate_area;
                }
            }
        });

        function calPercent(separated, total){
            return total > 0 ? ((+(separated / total).toFixed(4)) * 100).toFixed(2) : 0;
        }

        function renderProgress(separated, total){
            var percent = calPercent(separated, total);
            var html = '<div class="progress" style="height:28px;margin-bottom:2px;">';
            html += '<div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="color:#ddd;line-height:28px;width: ' + percent +'%">';
            html += '<span style="margin-left:5px;">' + percent +'%&nbsp;&nbsp;(' + separated + '/' + total + ')</span>';
            html += '</div>';
            html += '</div>';
            return html;
        }
        FW.ProgressRenderer = Class.create(FW.Grid.DefaultColumnRenderer, {
            cell : function(grid, column, record) {
                var vegetable_count = +record.get('vegetable_count');
                var separated_vegetable_count = +record.get('separated_vegetable_count');
                var other_count = +record.get('other_count');
                var separated_other_count = +record.get('separated_other_count');
                var total_count = vegetable_count + other_count;
                var separated_total_count = separated_vegetable_count + separated_other_count;
                if(column.name == 'vegetable_progress'){
                    return renderProgress(separated_vegetable_count, vegetable_count);
                }else if(column.name == 'other_progress'){
                    return renderProgress(separated_other_count, other_count);
                }else if(column.name == 'total_progress'){
                    return renderProgress(separated_total_count, total_count);
                }

            }
        });

        var options = {
            id: "grid_index",
            columns: [
                { label: "车辆ID", name: "car_group_id"},
                { label: "车辆名称", name: "car_name"},
                { label: "区域", name: "area_name"},
                { label: "分拣点", name: "operate_area", renderer: "FW.OperateAreaRenderer", htmlSafe: true},
                { label: "蔬菜进度", name: "vegetable_progress", renderer: "FW.ProgressRenderer", htmlSafe: true},
                { label: "其他进度", name: "other_progress", renderer: "FW.ProgressRenderer", htmlSafe: true},
                { label: "总进度", name: "total_progress", renderer: "FW.ProgressRenderer", htmlSafe: true},
            ],
            target: $("#gridPanel"),
            url:'/ccenter/monitor/realtimemonitor/separationStat',
            loadAfterRendered: false,
            pagination: false
        };
        var gridPanel = new FW.Grid(options);
        gridPanel.render();


        $('#search_btn').click(function(){
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
            $.get('/ccenter/monitor/realtimemonitor/separationStat', params, function(data){
                gridPanel.setData(data);
                var total_count = 0;
                var separated_count = 0;
                var total_vegetable_count = 0;
                var separated_vegetable_count = 0;
                var total_other_count = 0;
                var separated_other_count = 0;
                _.each(data, function(item){
                    total_vegetable_count += +item.vegetable_count;
                    separated_vegetable_count += +item.separated_vegetable_count;
                    total_other_count += +item.other_count;
                    separated_other_count += +item.separated_other_count;
                    total_count += +item.vegetable_count + +item.other_count;
                    separated_count += +item.separated_vegetable_count + +item.separated_other_count;
                });
                $('#total_progress').html(renderProgress(separated_count, total_count));
                $('#vegetable_progress').html(renderProgress(separated_vegetable_count, total_vegetable_count));
                $('#other_progress').html(renderProgress(separated_other_count, total_other_count));
            }, "json");
        });
        var dateOptions = {
            dateFormat: "yy-mm-dd"
        };
        $('.date-pick').datepicker(dateOptions);

        $('#search_btn').click();

    });
</script>