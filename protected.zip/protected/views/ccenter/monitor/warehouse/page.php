﻿<div class="panel panel-default">
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">配送日期</label>
                <input type="text" class="form-control date-pick" value="<?= $distribute_t ?>"
                     id="distribute_t"  name="distribute_t">
            </div>

            <div class="form-group mc-form-group">
                <label>城市</label>
                <select name="city" id="city" class="form-control">
                    <?php
                    foreach ($city_list as $key => $value) {
                        # code...
                        if ($city == $key) {
                            echo "<option value='" . $key . "' selected >" . $value . "</option>";
                        } else {
                            echo "<option value='" . $key . "'>" . $value . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">仓库</label>

                <select class="form-control" name="warehouse" id="warehouse">

                </select>
            </div>
            <div class="form-group mc-form-group">
                <button id="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>
        </form>
    </div>
</div>


<!--Step:1 Prepare a dom for ECharts which (must) has size (width & hight)-->
<!--Step:1 为ECharts准备一个具备大小（宽高）的Dom-->
<div id="main" style="height:500px;border:1px solid #ccc;padding:10px;"></div>

<!--Step:2 Import echarts-all.js-->
<!--Step:2 引入echarts-all.js-->
<script src="/static/echarts/echarts-all.js"></script>
<script src="/static/echarts/green.js"></script>
<script type="text/javascript">
    var dateOptions = {
        dateFormat: "yy-mm-dd"
    };
    $('.date-pick').datepicker(dateOptions);

    $(function () {
        function JSONLength(obj) {
            var size = 0, key;
            for (key in obj) {
                if (obj.hasOwnProperty(key)) size++;
            }
            return size;
        }

        $('#city').change(cityChange)
        function cityChange() {

            var selectIndex = $(this).children('option:selected').val();

            if (selectIndex == undefined) selectIndex = '<?= $city ?>';
            var objSelectNow = document.getElementById("warehouse");
            objSelectNow.options.length = 0;
            var lenght = JSONLength(warehouse[selectIndex])

            for (var i = 1; i <= lenght; i++) {
                var objOption = document.createElement("option");
                objOption.text = warehouse[selectIndex][i]["name"];
                objOption.value = warehouse[selectIndex][i]["id"];
                objSelectNow.options.add(objOption);
            }
        }

        var warehouse =<?php echo $warehouselist ?>;
        var optionPie={
           title: {
            text: '仓库进度情况',
            subtext: '截止03:00'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['生产时间', '完成百分比']
        },
        toolbox: {
            show: true,
            feature: {
                mark: {show: false},
                dataView: {show: false, readOnly: false},
                magicType: {show: false, type: ['line', 'bar']},
                restore: {show: false},
                saveAsImage: {show: true}
            }
        },
        calculable: true,
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                // data : ['周一','周二','周三','周四','周五','周六','周日']
                data: [<?php
                            foreach ($xAxis as  $value) {
                                # code...
                                echo "'".$value."',";
                            }
                        //echo   $xAxis ;
                 ?>]
            }
        ],
        yAxis: [
            {
                type: 'value',
                axisLabel: {
                    formatter: '{value} %'
                }
                //splitArea : {show : true}
            }
        ],
        series: [

            // {
            //     name:'订购数',
            //     type:'line',
            //     data:[ <?php
                //         echo   $weight ;
                //  ?>]
            // },
            // {
            //     name:'分拣数',
            //     type:'line',
            //     data:[<?php
                //         echo   $sort_weight ;
                //  ?>]
            // },
            {
                name: '完成百分比',
                type: 'line',
                itemStyle: {
                    normal: {
                        label: {
                            show: true, position: 'top'
                        }
                    }

                },
                data:[<?php 
                        foreach ($frate as $value) {
                            # code...
                            echo $value.","; 
                        }
                        
                       // echo $frate;

                        ?>]
               // data : [0,10,12,26,39,68,72,79,81,85,86,93,95,96,97,98,99,100]
            }

        ]
     }
        var myChart = echarts.init(document.getElementById('main'),theme);
        myChart.setOption(optionPie);



        cityChange();

      

        $('#search_btn').click(function () {
            var params = YC.Util.getFormData("search_form");
            $.get('/ccenter/monitor/warehouse/search', params, function (data) {
                //optionPie.legend.data=label;
                optionPie.series[0]['data'] = data.frate;
                myChart.setOption(optionPie);
            }, "json");
        });
    })
</script>
