<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">数据刷新</h3></li>
    </ul>
</div>
<div class="panel panel-default">
    <div class="panel-body">
        <div>
            <form id="search_form" name="search_form" class="form" role="form">
                <div class="form-group mc-form-group">
                    <label class="control-label">配送日期</label>
                    <input type="text" class="form-control date-pick" value="<?= $distribute_t ?>"
                           id="distribute_t" name="distribute_t">
                    <label> <input id="freshcheck" type="checkbox" name="flushstate">自动刷新</label>
                    <label>
                        <div id="colockbox"></div>
                    </label>
                </div>
            </form>


        </div>
        <?php
        if ($dataflush == 1) {
            ?>
            <div class="form-group mc-form-group">
                <button id="flush_stop" type="button" class="btn btn-primary">正在同步，点击关闭</button>
            </div>
        <?php
        } else {
            ?>
            <div class="form-group mc-form-group">
                <button id="flush_start" type="button" class="btn btn-primary">同步关闭，点击开始</button>
            </div>
        <?php
        }
        ?>
        <div class="form-group mc-form-group">
            <button id="flush_btn" type="button" class="btn btn-primary">刷新</button>
        </div>
        <div class="form-group mc-form-group">
            <button id="reset_btn" type="button" class="btn btn-primary">重置今日数据</button>
        </div>
    </div>
</div>

<div id="gridPanel"></div>
<script>
    var dateOptions = {
        dateFormat: "yy-mm-dd "
    };
    $('.date-pick').datepicker(dateOptions);
    $(function () {
        var options = {
            id: "grid_index",
            columns: [
                {label: "配送时间", name: "delivery_time"},
                {label: "刷新时间", name: "timepoint"},
                {label: "数据状态", name: "isflush"}
            ],
            target: $("#gridPanel"),
            url: '/ccenter/monitor/dataFlush/display',
            loadAfterRendered: true,
            pagination: false
        };
        var gridPanel = new FW.Grid(options);
        gridPanel.render();
        function search_btn() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
            $.get('/ccenter/monitor/dataFlush/display', params, function (data) {
                gridPanel.setData(data);

            }, "json");
        }

        $('#flush_btn').click(function () {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
            $.get('/ccenter/monitor/dataFlush/flush', params, function (data) {
                search_btn()

            }, "json");

        });
        $('#flush_stop').click(function () {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
            $.get('/ccenter/monitor/dataFlush/stop', params, function (data) {
                location.reload()
            }, "json");
        });
        $('#flush_start').click(function () {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
            $.get('/ccenter/monitor/dataFlush/start', params, function (data) {
                location.reload()
            }, "json");
        });
        $('#reset_btn').click(function () {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
            $.get('/ccenter/monitor/dataFlush/reset', params, function (data) {
                gridPanel.setData(data);
                search_btn()
            }, "json");

        });
    });

</script>
<script type="application/javascript">
    $('#freshcheck').click(freshcheckchange);
    var timer = null;
    var maxtime = <?php echo $flushinterval ?>;;
    function freshcheckchange() {
        if ($("#freshcheck").is(':checked')) {
            $("#colockbox").text(maxtime);
            timer = setInterval(autoTime, 1000);
        } else {
            clearInterval(timer);
            $("#colockbox").text("");
        }
    }
    //每一秒执行一次时间更新
    function autoTime() {
        t = $("#colockbox").text();
        iRemain = t - 1;
        if (iRemain <= 0) { //如果小于零，清除调用自己，并且返回
            $('#flush_btn').click();
            iRemain = maxtime;
        }
        $("#colockbox").text(iRemain);
    }

</script>
