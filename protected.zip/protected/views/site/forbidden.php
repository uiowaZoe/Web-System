<style>
body{
    position:absolute;
    width: 100%;
    height: 100%;
    background-color: RoyalBlue;
}
h1#warning{
    margin-top: 200px;
    text-align: center;
}
</style>
<div class="container">
    <h1 id="warning"class="alert alert-danger">你没有权限访问此页面!</h1>
</div>
