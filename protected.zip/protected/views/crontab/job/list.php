<?php
///**
// * Created by PhpStorm.
// * User: wangbiwen
// * Date: 2015/9/15
// * Time: 11:10
// */
//echo "test_list";
//echo "<hr/>";
//echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> "; //解决乱码
////$arr=array('1','2','3','4');
//
////form
//echo "<form action='/crontab/job/add' method='post'>";
//    echo "<table>";
//        echo "<tr>";
//            echo "
//                <td><input name='crontabtime' id='crontabtime' type='text' /></td>
//                <td><input name='cmd' id='cmd' type='text' /></td>
//                <td><input type='submit' value='添加' /></td>
//                ";
//        echo "</tr>";
//
//
//    echo "</table>";
//echo "<form>";
//
//
////list
//echo "<table border='1' style='text-align: center'>";
//
//        echo "<tr>
//                <td>_id序列</td>
//                <td>z属性</td>
//                <td>crontabtime</td>
//                <td>cmd</td>
//                <td>操作</td>
//              </tr>";
//
//                foreach($result as  $value)
//                {
//                    echo "<tr>
//
//                            <td>".$value['_id']."</td>
//                            <td>".$value['z']."</td>
//                            <td>".$value['crontabtime']."</td>
//                            <td>".$value['cmd']."</td>
//
//                          </tr>";
//
//                }
//
//
//    echo "</table>";
//?>
<!---->
<!--<!--<td>"."<a href='#' onclick=".deleteItem($value['_id']);">删除</a>"."</td>-->-->
<!---->
<!---->
<!--<script type="text/javascript">-->
<!---->
<!--    function deleteItem(_id){-->
<!--        var _id = _id;-->
<!--        alert(_id);-->
<!--        window.location.href="/crontab/job/del?_id="+_id;-->
<!---->
<!---->
<!--//        return;-->
<!--    }-->
<!---->
<!--</script>-->
<!---->
<!--<!-- html <div></div>-->-->
