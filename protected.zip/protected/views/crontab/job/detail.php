<?php
/**
 * Created by PhpStorm.
 * User: wangbiwen
 * Date: 2015/9/15
 * Time: 11:10
 */

echo "detail";
echo "<hr/>";
echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> "; //解决乱码


echo "<form action='/crontab/job/edit' method='post'>";

//    echo"<input name='_id' id='_id' type='hidden' value=".$result['_id']." />";
echo "<table border='1' style='text-align: center'>";

    echo "<tr>
        <td>_id序列</td>

        <td>crontabtime</td>
        <td>cmd</td>
        <td>z属性</td>
        <td>操作</td>
    </tr>";

//    foreach($result as  $value)
//    {
    echo "<tr>


        <td>".$result['_id']."</td>

        <input name='objectid' id='_id' type='hidden' value=".$result['_id']." />
        <td><input name='crontabtime' id='crontabtime' type='text' value=".$result['crontabtime']." /></td>
        <td><input name='cmd' id='cmd' type='text' value=".$result['cmd']." /></td>
        <td><input name='z' id='z' type='text' value=".$result['z']." /></td>
        <td><input type='submit' value='保存' /></td>
    </tr>";

//    }


    echo "</table>";
echo "</form>"
?>

