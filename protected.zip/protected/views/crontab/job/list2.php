<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title"></h3>
    </div>
    <div class="panel-body">
        <div class="form-group mc-form-group">
                <button id="add_btn" name="add_btn" type="button" class="btn btn-primary">添加</button>
        </div>


</div>
<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">任务结果列表</h3></li>
    </ul>
</div>
<div id="gridPanel"></div>

<!--点击编辑图标后的弹出框-->
<script id="uidemo_render_tmpl" type="text/x-handlebars-template">
    <div id="dialog_message"></div>
    <form method="GET" action="{{action}}" class="form-horizontali row" role="form">
        <input type="hidden" class="form-control" name="crontab_id" value="{{_id}}"/>
        <div class="form-group mc-form-group">
            <label>任务定时时间</label>
            <input type="text" name="crontabtime" class="form-control" value="{{crontabtime}}"/>
        </div>
        <div class="form-group mc-form-group">
            <label>任务内容</label>
            <input type="text" name="cmd" class="form-control" value="{{cmd}}" >
            <button id="run_btn" name="run_btn" type="button" class="btn btn-primary" style="display:inline;width:30%;vertical-align:middle">测试</button>
        </div>

        <div class="form-group mc-form-group">
            <label>任务创建时间</label>
            <input type="text" name="c_t" class="form-control" value="{{c_t}}"/>
        </div>
        <div class="form-group mc-form-group">
            <label>任务修改时间</label>
            <input type="text" name="u_t" class="form-control" value="{{u_t}}"/>
        </div>
        <div class="form-group mc-form-group">
            <label>任务创建人</label>
            <input type="text" name="user" class="form-control" value="{{user}}"/>
        </div>
        <div class="form-group mc-form-group">
            <label>任务有效</label>
            <input type="text" name="single" class="form-control" value="{{single}}"/>
        </div>



    </form>

</script>

    <script id="joblog_table_tmpl" type="text/x-handlebars-template">
        <table class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>任务创建人</th>
<!--                <th>任务内容</th>-->
                <th>任务创建时间</th>
                <th>任务修改时间</th>
                <th>任务最后执行时间</th>
                <th>任务执行时间</th>
                <th>任务结果</th>
            </tr>
            </thead>
            <tbody>
            {{#each jobs}}
            <tr>
                <td>{{user}}</td>
<!--                <td>{{cmd}}</td>-->
                <td>{{c_t}}</td>
                <td>{{u_t}}</td>
                <th>{{cr_t}}</th>
                <td>{{runtime}}</td>
                <td>{{result}}</td>
            </tr>
            {{/each}}
            </tbody>
        </table>
    </script>


    <script id="job_table_tmpl" type="text/x-handlebars-template">
        <table class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>crontabtime</th>
                <th>cmd</th>
                <th>result</th>
            </tr>
            </thead>
            <tbody>
            {{#each jobs}}
            <tr>
                <td>{{crontabtime}}</td>
                <td>{{cmd}}</td>
                <td>{{result}}</td>
            </tr>
            {{/each}}
            </tbody>
        </table>
    </script>

<script>
    $(function () {
        /*ui表格的按钮*/

        var UidemoActionDialogOption = {
            header: '',
            handlers: [
                {label:"取消", class:"-step-cancel"},
                {
                    label:"确定",
                    callback: function(){
                        $dialog = this.$dialog;
                        $component = this.component;
                        var gridPanel = $("#gridPanel").grid();//可以代替下面的2行渲染
//                            var gridPanel = new FW.Grid(options);
//                            gridPanel.render();

                        $dialog.find("form").ajaxSubmit({
                            data:{},
                            dataType:'json',
                            success: function(data){

                                if(data==undefined) {
                                    FW.GlobalMessage.addMessages(data.messages, $dialog.find('#dialog_message'));
                                } else {
                                    $dialog.modal("hide");
                                    if (gridPanel != null) {
                            //           grid.view.applyResultHandler()(data);
                                        gridPanel.setData(data);//回调填充数据并重新加载修改后的最新页面
                                   }
                                }
                            }
                        });
                        return false;
                    }
                }
            ]
        };
        /*dialog生成函数*/
        var UidemoActionDialog = FW.Component.XXX1TTT = Class.create(FW.Component.Base, FW.Component.WizardSupport, {
            render: function() {
                var source = $('#uidemo_render_tmpl').html();
                var template = Handlebars.compile(source);
                var context = this.option("data");
                var $dom = $(template(context));
                this._setDom($dom);

                return this.$dom;
            }
        });

        FW.Component.ActAsDialog(UidemoActionDialog, UidemoActionDialogOption);

        FW.GridActionRenderer = Class.create(FW.ActionsRenderer, {
            addActions: function($content, grid, colum, record) {
                var $editLink = $("<a>").append("<i class='fa fa-pencil-square-o'></i>");
                $editLink.attr("title", "编辑");
                $editLink.attr("href", "javascript:void(0)");
                $editLink.click(function(){
                    var data = {
                        _id: record.get("_id"),
                        crontabtime: record.get("crontabtime"),
                        cmd: record.get("cmd"),
                        user: record.get("user"),
                        single: record.get("single"),
                        c_t: record.get("c_t"),
                        u_t: record.get("u_t"),
                        action: "/crontab/job/edit" //确定后,发送表单提交处理的url，同其action一致
                    };

                    new UidemoActionDialog.asDialog({data:data}).show({}, {header: "编辑"});

                });

                var $detailLink = $("<a>").append("<i class='fa fa-search-plus'></i>");
                $detailLink.attr("title", "查看详情");
                $detailLink.attr("href", "javascript:void(0)");
                $detailLink.click(function(){
//                    alert("这是一个查看详情用弹出框，请参考'弹出框--展示表格弹出框'");

                    var data = {
                        _id: record.get("_id"),
                        crontabtime: record.get("crontabtime"),
                        cmd: record.get("cmd"),
                        user: record.get("user"),
                        single: record.get("single"),
                        c_t: record.get("c_t"),
                        u_t: record.get("u_t"),
                        action: "/crontab/job/edit" //确定后,发送表单提交处理的url，同其action一致
                    };
                    new UidemoActionDialog.asDialog({data:data}).show({}, {header: "详情"});
                });

                var joblog_Table_DialogOption = {
                    header: '',
                    handlers: [
                        {label:"确定", class:"-step-cancel"}
                    ]
                };

                /*dialog生成函数*/
                var joblog_Table_Dialog = FW.Component.XXX1TTT = Class.create(FW.Component.Base, FW.Component.WizardSupport, {
                    render: function() {
                        var source = $('#joblog_table_tmpl').html();
                        var template = Handlebars.compile(source);
                        var context = this.option("data");
                        var $dom = $(template(context));
                        this._setDom($dom);

                        return this.$dom;
                    }
                });


                var job_Table_Dialog = FW.Component.XXX1TTT = Class.create(FW.Component.Base, FW.Component.WizardSupport, {
                    render: function() {
                        var source = $('#job_table_tmpl').html();
                        var template = Handlebars.compile(source);
                        var context = this.option("data");
                        var $dom = $(template(context));
                        this._setDom($dom);

                        return this.$dom;
                    }
                });

                FW.Component.ActAsDialog(joblog_Table_Dialog, joblog_Table_DialogOption);
                FW.Component.ActAsDialog(job_Table_Dialog, joblog_Table_DialogOption);

                var jobloglist ={};
                var obj_id= record.get("_id");
                var single=record.get("single");
                $.get('/crontab/joblog/Log?obj_id='+obj_id+'&single='+single, function(data){
                        jobloglist = data;
                  }, 'json');

                var $searchLink = $("<a>").append("<i class='fa fa-plus'></i>");
                $searchLink.attr("title", "结果");
                $searchLink.attr("href", "javascript:void(0)");
                $searchLink.click(function(){
                        var data = {
                            jobs: jobloglist
                        };
                     new joblog_Table_Dialog.asDialog({data:data}).show({}, {header: "任务结果"});
                });


                var joblist ={};
                var cmd= record.get("cmd");
                var crontabtime= record.get("crontabtime");
                $.get('/crontab/job/Run?cmd='+cmd+'&crontabtime='+crontabtime, function(data){
                    joblist = data;
                }, 'json');
                var $runLink = $("<a>").append("<i class='fa fa-reddit-square'></i>");
                $runLink.attr("title", "结果");
                $runLink.attr("href", "javascript:void(0)");
                $runLink.click(function(){
                    var data = {
                        jobs:joblist
                    };
                    new job_Table_Dialog.asDialog({data:data}).show({}, {header: "任务结果"});
                });

                var $delLink = $("<a>").append("<i class='fa fa-trash-o'></i>");
                $delLink.attr("title", "删除");
                $delLink.attr("href", "javascript:void(0)");
                $delLink.click(function(){
                        new FW.Modal.confirm('确定要进行删除吗?', function(result){
                            if (!result) {
                                return ;
                            }
                            // 在这里写点击确认以后要做的操作

                                var obj_id= record.get("_id");

                            $.get('/crontab/job/del?obj_Id='+obj_id, function (data) {
                                gridPanel.setData(data);
                            }, "json");
                    });
                });

                $('#run_btn').click(function(){
                    var joblist ={};
                    var cmd= record.get("cmd");
                    var crontabtime= record.get("crontabtime");
                    $.get('/crontab/job/Run?cmd='+cmd+'&crontabtime='+crontabtime, function(data){
                        joblist = data;
                    }, 'json');
                    var data = {
                        jobs:joblist
                    };
                    new job_Table_Dialog.asDialog({data:data}).show({}, {header: "任务结果"});
                });

                $content.append($editLink);
                $content.append($detailLink);
                $content.append($searchLink);
                $content.append($runLink);
                $content.append($delLink);
            }
        }

        );


        var options = {
            id: "grid_index",
            columns: [
             //   {label: "_id", name: "_id"},
                {label: "任务创建人", name: "user"},
                {label: "任务定时时间", name: "crontabtime"},
                {label: "任务内容", name: "cmd"},
                {label: "任务创建时间", name: "c_t"},
                {label: "任务修改时间", name: "u_t"},
                {label: "任务最后执行时间", name: "cr_t"},
                {label: "任务运行时间(毫秒/ms)", name: "runtime"},
                {label: "属性有效", name: "single"},
                { label: "操作", renderer: "FW.GridActionRenderer", virtual:true, htmlSafe: true}
            ],
            target: $("#gridPanel"),
            url: '/crontab/job/JobLog',
            loadAfterRendered: false,
            pagination: false
        };


        var gridPanel = new FW.Grid(options);
        gridPanel.render();

        function pageShow(){
            $.get('/crontab/job/JobLog', function (data) {
                gridPanel.setData(data);
            }, "json");
        }
        pageShow();//  先触发进入展示列表数据

        $('#add_btn').click(function(){
            var data = {
                action: "/crontab/job/add" //确定后,发送表单提交处理的url，同其action一致
            };
            new UidemoActionDialog.asDialog({data:data}).show({}, {header: "添加"});
        });



        $('#dialog-show-grid').click(function(){
            new joblog_Dialog.asDialog().show({}, {header: "详细信息"});
        });

        //点击编辑按钮触发编辑函数
//        function updateByObjectId(object_id){
//            var obj_id = object_id;
////            alert(obj_id);
////            window.location.href=""; //无法做到ajax
//            $.get('/crontab/job/edit?crontab_jobid='+obj_id, function (data) {
//                gridPanel.setData(data);//回调填充数据并重新加载修改后的最新页面
//            }, "json");
//        }




    });
</script>

<script src="/static/echarts/echarts-all.js"></script>
