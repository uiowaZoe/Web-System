<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">查询条件</h3>
    </div>
    <div class="panel-body">
        <form id="search_form" class="form" role="form">
            <div class="form-group mc-form-group">
                <label class="control-label">任务时间</label>
                <input type="text" class="form-control "
                       name="job_time" id="job_time" placeholder="请输入任务时间">
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">任务内容</label>
                <input type="text" class="form-control "
                       name="job_name" id="job_name" placeholder="请输入任务名称">
            </div>

            <div class="form-group mc-form-group">
                <label class="control-label">任务有效</label>
                <input type="text" class="form-control "
                       name="job_sig" id="job_name" placeholder="请输入任务有效">
            </div>

            <div class="form-group mc-form-group">
                <button id="search_btn" name="search_btn" type="button" class="btn btn-primary">查询</button>
            </div>
        </form>
    </div>
</div>
<div class="grid-message -auto-binded" data-grid-id="grid_index" style="display: block;"></div>
<div class="grid-head">
    <ul class="nav nav-tabs">
        <li><h3 class="fw-mt0">任务结果查询</h3></li>
    </ul>
</div>
<div id="gridPanel"></div>
<script>
    $(function () {
        var options = {
            id: "grid_index",
            columns: [
                {label: "任务内容", name: "cmd"},
                {label: "任务时间", name: "crontabtime"},
                {label: "开始时间", name: "starttime"},
                {label: "运行时间(纳秒/ns)", name: "runtime"},
                {label: "任务结果", name: "result"}
            ],
            target: $("#gridPanel"),
            url: '/crontab/joblog/Log',
            loadAfterRendered: false,
            pagination: false
        };
        var gridPanel = new FW.Grid(options);
        gridPanel.render();
        $('#search_btn').click(pageSearch);

        function pageSearch() {
            var params = YC.Util.getFormData("search_form");
            gridPanel.updateDefaultParams(params);
            $.get('/crontab/jobLog/log', params,function (data) {
                gridPanel.setData(data);
            }, "json");
        }
        pageSearch();

    });
</script>
<script src="/static/echarts/echarts-all.js"></script>
