<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <meta charset="utf-8">
    <meta http-equiv="pragma" content="no-cache" />
    <meta name="format-detection" content="telephone=no" />
    <title>菜品列表</title>
    <link rel="stylesheet" href="/assets/weixin/css/reset.css">
    <link rel="stylesheet" href="/assets/weixin/css/demo.css?v=5">
</head>
<body style="background-color:#21b387;">
<?php echo $content; ?>
</body>
</html>