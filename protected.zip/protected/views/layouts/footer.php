<footer>
    <div class="container">
        <p>云杉美菜 @ auth</p>
    </div>
</footer>