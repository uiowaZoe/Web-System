<?php /* @var $this Controller */ ?>
<!DOCTYPE html>
<html xml:lang="en" lang="en">
<?php include 'header.php'; ?>

<body  class="pg-common" id="page">
    <?php include 'nav.php'; ?>
	<?php echo $content; ?>
	<?php include 'footer.php'; ?>
</body>
</html>
