<?php
$nav = array();
$user_info =$this->user_info;
$access = MeicaiAuth::listAccessByTokenAndKey($_COOKIE[MEICAI_AUTH_TOKEN_NAME], MEICAI_SYSTEM_KEY);
if ($access['ret'] == 1) {
    $data = $access['data'];
    foreach ($data as $row) {
        $nav[] = $row['entry'];
    }
    $user_roles = $user_info["roles"];

    foreach($user_roles as $key=>$value){
        if(isset($user_roles["command_center"])&&isset($value["name"]) &&isset($user_info["name"])){
            $user_role = $value["name"];
            $user_name = $user_info["name"];
        }else{
            $user_role = "无本系统权限";
            $user_name = "未识别的用户名";
        }
    }
}
?>
<header class="navbar navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header"><a href="http://beta.cpu.yunshanmeicai.com/" title="美菜网"><i class="fa logo"></i> 生产监控</a>
        </div>
        <nav class="collapse navbar-collapse in" aria - expanded="false">
            <ul class="nav navbar-nav navbar-left">
                <?php if (in_array("/ccenter/monitor/citys/page", $nav)) { ?>
                    <li><a href="/ccenter/monitor/citys/page"> 全国进度</a></li>
                <?php } ?>
                <?php if (in_array("/ccenter/monitor/class/page", $nav)) { ?>
                    <li><a href="/ccenter/monitor/class/page"> 仓库大类</a></li>
                <?php } ?>
                <?php if (in_array("/ccenter/monitor/cis/page", $nav)) { ?>
                    <li><a href="/ccenter/monitor/cis/page"> 商品分拣情况</a></li>
                <?php } ?>
                <?php if (false) { ?>
                    <li><a href="/ccenter/monitor/realTimeMonitor/separation"> 线路分拣情况</a></li>
                <?php } ?>
                <?php if (in_array("/ccenter/monitor/timeline/page", $nav)) { ?>
                    <li><a href="/ccenter/monitor/timeLine/page"> 分拣进度情况</a></li>
                <?php } ?>
                <?php if (in_array("/ccenter/monitor/dataflush/page", $nav)) { ?>
                    <li><a href="/ccenter/monitor/dataFlush/page"> 数据刷新</a></li>
                <?php } ?>
                <?php if (true) { ?>
                    <li><a href="/ccenter/predict/predictData/page">预测数据</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">

                <li><a href="<?php echo MEICAI_AUTH_LOGOUT_URL; ?>">退出登录</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">

                <li><a href=""><?php echo $user_name; ?></a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">

                <li><a href=""><?php echo $user_role; ?></a></li>
            </ul>
        </nav>
    </div>
</header>