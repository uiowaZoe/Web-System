<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" href="/static/dist/ui.css?v=1">
    <link rel="stylesheet" href="/static/dist/theme-mcc.css?v=1">
    <script src="/static/dist/ui.js"></script>
    <script src="/static/dist/common.js"></script>
    <script src="/static/dist/moment.js"></script>
    <!--<script src="/static/dist/common.js"></script>-->
    <!--<script src="/static/dist/support.js"></script>-->
    <!--<script src="/static/dist/jquery.multi-select.js"></script>-->
    <!--<script src="/static/dist/jstree.min.js"></script>-->
    <!--<script src="/static/dist/jquery.datetimepicker.js"></script>-->
    <!--<script src="/static/dist/moment.js"></script>-->
    <title>生产指挥中心</title>
</head>
