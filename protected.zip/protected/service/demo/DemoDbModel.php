<?php
class DemoDbModel extends ServiceDbModelBase
{
    public function getDbConnection()
    {
        return Yii::app()->demodb;
    }

    public function tableName()
    {
        return 'demo_table';
    }

    public static function model($className = __CLASS__)
    {
        return parent::model($className);
    }
}
