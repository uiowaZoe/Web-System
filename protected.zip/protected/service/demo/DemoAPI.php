<?php

class DemoAPI extends ServiceApiBase
{
    public function __construct() {
        $this->service_url = DEMO_SERVICE_URL;

    	$this->manager = new DemoManager();
    }

    public function get($id) {
    	return $this->manager->get($id);
    }

    /*************************** 以下为http接口 ****************************/
    public function getListByIds($oi_ids) {
        $this->method = 'orderitem/getlistbyids';
        return $this->callService($oi_ids);
    }
}
