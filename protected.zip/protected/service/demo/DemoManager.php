<?php
class DemoManager extends ServiceManagerBase
{
    private $demo_dbmodel;

    public function __construct() {
    	$this->demo_dbmodel = new DemoDbModel();
    }

    public function get($id) {
    	if (!is_numeric($id)) return $this->errorParamInvalid('id');
    	$info = $this->demo_dbmodel->get($id);
    	// do something
    	return $info;

    }
}
