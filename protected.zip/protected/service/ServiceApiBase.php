<?php
/**
 * Service api abstract class
 */
abstract class ServiceApiBase
{
    protected $service_url = '';
    protected $method = '';
    private $start_request_time = 0;

    public function callService($params)
    {
        $header = array('Content-Type:application/json;charset=UTF-8');
        $url    = $this->service_url . '/' . $this->method;
        $data   = json_encode($params);
        $this->start_request_time = microtime(true);
        try{
            $result = HttpClient::post($url, $data, true, $header);
        } catch (Exception $e) {
            $this->error_log($url, $data, $e->getMessage());
            throw new ServiceException($e->getMessage(), $e->getCode());
        } finally {
            $this->log($url, $data);
        }

        if ($result['ret'] == 0) {
            throw new ServiceException($result['error']['msg'], $result['error']['code']);
        }
        return $result['data'];
    }

    private function log($url, $data) {
        $end_time = microtime(true);
        $log = "\nUSE:".round(($end_time - $this->start_request_time) * 1000, 2)."ms\nURL:{$url}\nDATA:{$data}";
        Yii::log($log, CLogger::LEVEL_INFO, 'meicai.http_api.access');
    }

    private function error_log($url, $data, $result) {
        $log = "\nURL:{$url}\nDATA:{$data}\nRESULT:{$result}\n";
        Yii::log($log, CLogger::LEVEL_ERROR, 'meicai.http_api.error');
    }
}
