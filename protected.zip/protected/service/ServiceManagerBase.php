<?php
/**
 * Service manager abstract class
 */

abstract class ServiceManagerBase
{
	private function error($code, $msg) {
		throw new ServiceException($msg, $code);
	}
	/**
	 * error system exception
	 */
    protected function errorSystemException($msg) {
		return $this->error(Service::ERROR_SYSTEM_EXCEPTION, $msg);
	}
	/**
	 * error invalid parameter
	 */
    protected function errorParamInvalid($msg) {
		return $this->error(Service::ERROR_INVALID_PARAM, $msg);
	}
	/**
	 * error resource exist
	 */
    protected function errorResourceExist($msg) {
		return $this->error(Service::ERROR_RESOURCE_EXIST, $msg);
	}
	/**
	 * error resource not exist
	 */
    protected function errorResourceNotExist($msg) {
		return $this->error(Service::ERROR_RESOURCE_NOT_EXIST, $msg);
	}
	/**
	 * error resource not exist
	 */
    protected function errorOptFail($msg) {
		return $this->error(Service::ERROR_OPT_FAIL, $msg);
	}
}
