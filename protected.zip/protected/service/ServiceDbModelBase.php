<?php

/**
 * Service modle abstract class
 */
abstract class ServiceDbModelBase extends CActiveRecord
{
    public $count;
    private $update_attributes = array();

    public function __set($name,$value)
    {
        if ($name == 'attributes' && is_array($value)) {
            $this->update_attributes = array_merge($this->update_attributes, $value);
        } else {
            $this->update_attributes[$name] = $value;
        }
        parent::__set($name, $value);
    }

    //重写save方法，去掉update时修改所有字段的问题
    public function save($runValidation=true, $attributes=null)
    {
        if (null === $attributes && !empty($this->update_attributes)) {
            $attributes = array_keys($this->update_attributes);
        }
        return parent::save($runValidation, $attributes);
    }


    /**
     * @alias           格式化
     * @description     根据查询返回结果进行格式化操作
     * @param           $select ,需要格式化的字段列表。
     * @return          格式化后的结果数组。
     */
    public function convertToArray($select = null)
    {
        if (empty($select)) {
            $item = $this->attributes;
        } else {
            foreach ($select as $key) {
                if ($key == 'c_t' || $key == 'u_t')
                    $item[$key] = date("Y-m-d H:i:s", $this->getAttribute($key));
                else
                    $item[$key] = $this->getAttribute($key);
            }
        }

        return $item;
    }

    /**
     * @alias           获取单表项
     * @description     根据用户传入id，返回单个表项的信息
     * @param           $id ,查询的表项的主键id
     * @param           $select ,返回的字段
     * @return          结果数组
     */
    public function getById($id, $select = array())
    {
        if (empty($id))
            return array();

        $params[] = array('id', '=', $id);
        $result = $this->get($params, $select);

        if (empty($result))
            return array();

        return $result[0];
    }

    /**
     * @alias           插入单条数据
     * @description     根据输入，插入单条数据
     * @param           $attributes 插入字段数组
     * @return          成功返回插入数据，错误返回false
     */
    public function create($attributes, $u_t = true)
    {
        $class = get_class($this);
        $model = new $class;
        if (!isset($attributes['id'])) {
            $attributes['c_t'] = time();
            $u_t && $attributes['u_t'] = time();
            foreach ($attributes as $key => $value) {
                $model->{$key} = $value;
            }

            //$model->setIsNewRecord(true);
            if ($model->save()) {
                return $model->convertToArray();
            }
        }

        return false;
    }

    /**
     * @alias           批量插入数据
     * @description     根据输入，批量插入数据
     * @param           $params 数组，需要插入的数据。例如array(array('lu_commodity_item_id' => XX, 'c_t' => XXX), array('lu_commodity_item_id' => XX, 'c_t' => XXX))
     * @return          成功返回插入的数量，错误返回false
     */
    public function batchCreate($params)
    {
        if (empty($params)) {
            return false;
        }
        $attributes = $this->getAttributes();
        foreach ($params as &$param) { //插入的任何一个字段不能为null，如果为null则改为0
            foreach ($param as &$v) {
                empty($v) && $v = 0;
            }
            if (!array_key_exists('c_t', $param) && array_key_exists('c_t', $attributes))
                $param['c_t'] = time();
            if (!array_key_exists('u_t', $param) && array_key_exists('u_t', $attributes))
                $param['u_t'] = time();
        }

        foreach ($params as $value) {
            $valueList[] = '("' . join('", "', array_values($value)) . '")';
        }

        $sql = 'INSERT' . ' INTO ' . $this->tableName() . '(`' . join('`, `', array_keys($params[0])) . '`) VALUES ' . join(', ', $valueList);
        $dataReader = $this->getDbConnection()->createCommand($sql)->query();

        return $dataReader->count();
    }
    
    /**
     * 批量更新表数据
     * 在一个表中批量更新数据
     * @param $attributes 二维数组，需要更新的数据字段和对应的值。
     * @param $condition  二维数据，对应$attributes的条件where
     * @param $model 需要插入的表名称
     * @return int
     */
    public function batchUpdate($attributes,$condition)
    {
        $valueList = array();
        if (empty($attributes) or empty($condition)) {
            return 0;
        }
        $fields = $this->getAttributes();
        foreach ($attributes as $key=>$param) { //插入的任何一个字段不能为null，如果为null则改为0
            $valueStr = '';
            if (array_key_exists('u_t', $fields)) {
                !isset($param['u_t']) && $param['u_t'] = time();
            } else {
                unset($param['u_t']);
            }
            foreach ($param as $k => $v) {
                empty($v) && $v = 0;
                if(gettype($v) == "string"){//string型字段需要加引号
                    $valueStr.= $k. ' = "'.$v.'"'.',';
                }else{
                    $valueStr.= $k.' = '.$v.',';
                }
            }
            $valueStr = rtrim($valueStr,',');
            $where= ' where ';
            if(array_key_exists($key,$condition) and !empty($condition[$key])){
                foreach ($condition[$key] as $k => $v) {
                    if(gettype($v) == "string"){
                        $where.= $k. ' = "'.$v.'"'.' and ';
                    }else{
                        $where.= $k.' = '.$v.' and ';
                    }
                }
                $where = rtrim($where,'and ');
            }else{
                return 'batchUpdate '.$this->tableName() .' 失败';
            }
            $valueList[] = 'update '. $this->tableName() . ' set ' . $valueStr . $where;
        }
        $sql = join('; ', $valueList);
        $dataReader = $this->getDbConnection()->createCommand($sql)->query();
        return $dataReader->count();
    }

    /**
     * @alias           修改数据
     * @description     修改数据
     * @param           $id 修改数据的主键
     * @param           $attributes 修改字段数组
     * @return          成功返回true，错误返回false
     */
    public function updateById($id, $attributes)
    {
        if (!empty($id) && !isset($attributes['id'])) {
            $condition = is_array($id) ? ('id in('.join(',', $id).')') : ('id='.$id);
            if(!isset($attributes['u_t'])) {
            	$attributes['u_t'] = time();
            }
            $ret = $this->updateAll($attributes, $condition);
            if ($ret > 0)
                return true;
        }

        return false;
    }

    /**
     * @alias           获得过滤条件
     * @description     获取过滤条件字符串
     * @param           $param过滤条件数组
     * @return          过滤条件字符串
     */
    public function _getCondition($params, $op = 'AND')
    {
        $condition = $op === 'AND' ? " 1>0 " : " 1<0 ";
        if (!empty($params)) { //如果params为空则返回所有数据
            foreach ($params as $key => $value) {
                if($key === 'or'){
                    $condition .= " $op ".' ('.$this->_getCondition($value, 'OR').')';
                    continue;
                }
                if(!isset($value['name']))
                {
                    list($value['name'], $value['type'], $value['value']) = $value;
                }
                if ('like' == strtolower($value['type'])) {
                    $condition .= " $op " . $value['name'] . ' LIKE \'%' . $value['value'].'%\'';
                } else if ('in' == strtolower($value['type'])) {
                    $condition .= " $op " . $value['name'] . ' in(' . join(',', $value['value']) . ')';
                } else if ('not in' == strtolower($value['type'])) {
                    $condition .= " $op " . $value['name'] . ' not in(' . join(',', $value['value']) . ')';
                } else if ('is' == strtolower($value['type'])) {
                    $condition .= " $op " . $value['name'] . ' is ' . $value['value'];
                } else if ('is not' == strtolower($value['type'])) {
                    $condition .= " $op " . $value['name'] . ' is not ' . $value['value'];
                } else {
                    $condition .= " $op " . $value['name'] . ' ' . $value['type'] . ' ' . '\'' . $value['value'] . '\'';
                }
            }
        }
        return $condition;
    }

    /**
     * @alias           批量修改
     * @description     根据过滤条件，更新指定字段
     * @param           $condition 过滤条件
     * @param           $attributes 修改字段数组
     * @return          成功返回true，错误返回false
     */
    public function updateByCondition($attributes, $params)
    {
        $attributes['u_t'] = time();
        $condition = $this->_getCondition($params);
        $ret = $this->updateAll($attributes, $condition);
        return $ret;
    }

    /**
     * @alias           修改单条数据
     * @description     修改单挑数据
     * @param           $id 修改数据的主键
     * @param           $attributes 修改字段数组
     * @return          成功返回true，错误返回false
     */
    public function increaseByCondition($counters, $params)
    {
        $condition = $this->_getCondition($params);
        $this->updateAll(array('u_t' => time()), $condition);
        $ret = $this->updateCounters($counters, $condition);
        return $ret;
    }

    /**
     * @alias           查询
     * @description     查询数据表
     * @param           $param过滤条件数组
     * @param           $select返回字段数组
     * @param           $order排序字段
     * @param           $limit返回数据最多条数
     * @param           $offset跳过条数
     * @param           $distinct是否去重
     * @return          查询结果数组
     */
    public function get($params, $select = array(), $order = null, $limit = null, $offset = null, $distinct = false)
    {
        $models = $this->_getAllModels($params, $select, $order, $limit, $offset, $distinct);
        $result = array();
        foreach ($models as $model) {
            $item = $model->convertToArray($select);
            $result[] = $item;
        }

        return $result;
    }

    /**
     * @alias           查询
     * @description     查询数据表,把$id_name做为key组织结果数组
     * @param           $id_name使用该字段作为key组织返回数组 。
     * @param           $param过滤条件数组
     * @param           $select返回字段数组
     * @param           $order排序字段
     * @param           $limit返回数据最多条数
     * @param           $offset跳过条数
     * @param           $distinct是否去重
     * @return          查询结果数组
     */
    public function getWithId($id_name, $params, $select = array(), $order = null, $limit = null, $offset = null, $distinct = false)
    {
        $models = $this->_getAllModels($params, $select, $order, $limit, $offset, $distinct);
        $result = array();
        foreach ($models as $model) {
            $item = $model->convertToArray($select);
            $result[$model->getAttribute($id_name)] = $item;
        }
        return $result;
    }

    /**
     * @alias           获取指定id字段list
     * @description     获取指定id字段list
     * @param           $param过滤条件数组
     * @param           $select id字段名称
     * @param           $order排序字段
     * @param           $limit返回数据最多条数
     * @param           $offset跳过条数
     * @return          id字段数组
     */
    public function getIdList($params, $select, $order = null, $limit = null, $offset = null)
    {

        $models = $this->_getAllModels($params, array($select), $order, $limit, $offset, true);

        $result = array();
        foreach ($models as $model) {
            $item = $model->convertToArray(array($select));
            $result[] = $item[$select];
        }

        return $result;
    }

    /**
     * @alias           查询内容并返回结果并获取指定id字段list
     * @description     查询内容并返回结果并获取指定id字段list
     * @param           $param过滤条件数组
     * @param           $select id字段名称
     * @param           $order排序字段
     * @param           $limit返回数据最多条数
     * @param           $offset跳过条数
     * @return          id字段数组
     */
    public function getInfoAndIdList($id_name_list, $id_name, $params, $select, $order = null, $limit = null, $offset = null)
    {
        $result['info'] = array();
        $models = $this->_getAllModels($params, $select, $order, $limit, $offset);
        foreach ($models as $model) {
            $item = $model->convertToArray($select);
            if (empty($id_name)) {
                $result['info'][] = $item;
            } else {
                $result['info'][$item[$id_name]] = $item;
            }

            foreach ($id_name_list as $name) {
                if (!empty($item[$name])) {
                    $id_list[$name][] = $item[$name];
                }
            }
        }

        foreach ($id_name_list as $name) {
            if (!empty($id_list[$name])) {
                $result[$name] = array_values(array_unique($id_list[$name]));
            }
        }

        return $result;
    }

    public function _getAllModels($params, $select = array(), $order = null, $limit = null, $offset = null, $distinct = false)
    {
        $criteria = new CDbCriteria;
        $criteria->condition = $this->_getCondition($params);
        if (!empty($select)) {
            $criteria->select = '`' . join("`,`", $select) . '`';
        }

        if (!empty($order)) {
            $criteria->order = $order;
        }

        if (!empty($limit)) {
            $criteria->limit = $limit;
        }
        if (isset($offset)) {
            $criteria->offset = $offset;
        }
        $criteria->distinct = $distinct;

        return $this->findAll($criteria);
    }

    public function _getSumModels($params, $select, $group, $order = null, $limit = null, $offset = null)
    {
        $criteria = new CDbCriteria;
        $criteria->condition = $this->_getCondition($params);
        if (!empty($group)) {
            $criteria->group = join(",", $group);
            $criteria->select = $criteria->group;
        } else
            $criteria->select = '1';
        foreach ($select as $key) {
            if(is_array($key))
                foreach ($key as $k=>$v) {
                    $criteria->select .= ', sum(cast(' . $k . ' as decimal(10,2))) as ' . $v;
                }
            else
                $criteria->select .= ', sum(cast(' . $key . ' as decimal(10,2))) as ' . $key;
        }
        if (!empty($order)) {
            $criteria->order = $order;
        }

        if (!empty($limit)) {
            $criteria->limit = $limit;
        }
        if (isset($offset)) {
            $criteria->offset = $offset;
        }
        return $this->findAll($criteria);
    }

    /**
     * $select 参数默认为一唯数组array('number',...) 对应的sql为： sum(number) as number。
     * 改造后可以传二维数组 array(array('number * price'=>'total_price'),'num',...) 对应的sql为：sum(number * price) as total_price
     */
    public function getSumList($params, $select, $group, $order = null, $limit = null, $offset = null)
    {
        $models = $this->_getSumModels($params, $select, $group, $order, $limit, $offset);
        $sum_list = array();
        $new_select = array();
        if (!empty($group)) {
            foreach ($group as $g) {
                $new_select[] = $g;
            }
        }
        foreach($select as $v){
            if(is_array($v))
                foreach($v as $vv){
                    $new_select[] = $vv;
                }
            else
                $new_select[] = $v;
        }
        foreach ($models as $model) {
            $item = $model->convertToArray($new_select);
            $sum_list[] = $item;
        }
        return $sum_list;
    }

    /**
     * @param $params
     * @param $group
     * @param null $order
     * @param null $limit
     * @param null $offset
     * @return CActiveRecord[]
     */
    public function _getCountModels($params, $group, $order = null, $limit = null, $offset = null)
    {
        $criteria = new CDbCriteria;
        $criteria->condition = $this->_getCondition($params);
        $criteria->group = join(",", $group);
        $criteria->select = $criteria->group;
        $criteria->select .= ', count(id) as id';

        if (!empty($order)) {
            $criteria->order = $order;
        }

        if (!empty($limit)) {
            $criteria->limit = $limit;
        }
        if (isset($offset)) {
            $criteria->offset = $offset;
        }

        return $this->findAll($criteria);
    }

    /**
     * @alias           根据指定字段或者对应的行数
     * @description     根据指定字段或者对应的行数
     * @param           $param过滤条件数组
     * @param           $name指定字段名称，根据该字段统计行数
     * @param           $order排序字段
     * @param           $limit返回数据最多条数
     * @param           $offset跳过条数
     * @return          查询结果数组
     */
    public function getCountList($params, $name, $order = null, $limit = null, $offset = null)
    {
        $models = $this->_getCountModels($params, array($name));
        $count_list = array();
        foreach ($models as $model) {
            $count_list[$model->getAttribute($name)] = $model->getAttribute('id');
        }
        return $count_list;
    }

    /**
     * @alias           根据ids查询
     * @description     根据ids查询数据表
     * @param           $ids查询的id字符串
     * @param           $select返回字段数组
     * @param           $order排序字段
     * @param           $limit返回数据最多条数
     * @param           $offset跳过条数
     * @param           $distinct是否去重
     * @return          查询结果数组
     */
    public function getByParams($params,  $select = array(), $order = 'id ASC')
    {
        $rows = array();
        $criteria = new CDbCriteria;
        $condition = " 1>0 ";
//        $p = array();
        if (!empty($params)) { //如果params为空则返回所有数据
            foreach ($params as $value) {
                if ('like' == strtolower($value['type'])) {
                    $condition .= ' AND ' . $value['name'] . ' LIKE :' . $value['name'];
                    $p[$value['name']] = '%' . $value['value'] . '%';
                } else if ('in' == strtolower($value['type'])) {
                    $condition .= ' AND ' . $value['name'] . ' in(' . $value['value'] . ')';
                } else if ('not in' == strtolower($value['type'])) {
                    $condition .= ' AND ' . $value['name'] . ' not in(' . $value['value'] . ')';
                } else if ('is' == strtolower($value['type'])) {
                    $condition .= ' AND ' . $value['name'] . ' is ' . $value['value'];
                } else {
                    $condition .= ' AND ' . $value['name'] . $value['type'] . $value['value'];
//                    $condition .= ' AND ' . $value['name'] . $value['type'] . ':' . $value['name'];
//                    $p[$value['name']] = $value['value'];
                }
            }
        }
        $criteria->condition = $condition;
        !empty($p) && $criteria->params = $p;
        $criteria->order = $order;

        if (!in_array('id', $select) && !empty($select)) array_push($select, 'id'); //如果返回的数值不为空，并且没有id，则将id插入数组
        !empty($select) && $criteria->select = $select;

        $data = $this->findAll($criteria);

        if (!empty($data)) {
            if (!empty($select)) {
                foreach ($data as $value) {
                    $row = array();
                    foreach ($select as $v) {
                        $row[$v] = $value->{$v};
                    }
                    $rows[$value->id] = $row;
                }
            } else {
                foreach ($data as $value) {
                    $rows[$value->id] = $value->attributes; //如果没有指定参数则返回表中所有字段
                }
            }

        }
        return $rows;
    }
    public function getByIds($ids, $select = array(), $order = null, $limit = null, $offset = null, $distinct = false)
    {
        if (empty($ids))
            return array();
        $params[] = array('id', 'in', $ids);
        return $this->get($params, $select, $order, $limit, $offset, $distinct);
    }

    /**
     * @alias           查询个数
     * @description     查询数据表符合条件的条目数
     * @param           $param过滤条件数组
     * @return          满足条件条目数
     */
    public function getCount($condition)
    {
        $criteria = new CDbCriteria;
        $criteria->condition = $this->_getCondition($condition);
        return (int) $this->count($criteria);
    }

    public function getDistinctCount($condition, $distinct = '') {
        $sql = 'select count(distinct '.$distinct.') as count from '.$this->tableName().' where '.$this->_getCondition($condition);
        return (int) $this->countBySql($sql);
    }
    
    /**
     * @alias           组建条件数组
     * @description    组建条件数组
     * @param           $name 字段名称
     * @param           $type 条件
     * @param           $value 值
     * @return          条件数组
     */
    public function getCondition($name, $type, $value)
    {
        return array('name' => $name, 'type' => $type, 'value' => $value);
    }

    /**
     * 根据索引数组返回对应的数据
     * @param $ids
     * @param $param
     * @param $model
     * @param array $params
     * @return array
     */
    public function getByParamIds($ids, $param, $params = array())
    {
        $rows = array();
        if (empty($ids)) {
            return $rows;
        }
        $criteria = new CDbCriteria();
        $criteria->condition = $param . ' in (' . join(',', $ids) . ')';
        if (!in_array('id', $params) && !empty($params)) array_push($params, 'id');
        !empty($params) && $criteria->select = $params;

        $data = $this->findAll($criteria);

        if (!empty($data)) {
            if (!empty($params)) {
                foreach ($data as $value) {
                    $row = array();
                    foreach ($params as $v) {
                        $row[$v] = $value->{$v};
                    }
                    $rows[$value->id] = $row;
                }
            } else {
                foreach ($data as $value) {
                    $rows[$value->id] = $value->attributes; //如果没有指定参数则返回表中所有字段
                }
            }
        }

        return $rows;
    }
    /**
     * 根据条件和参数等返回对应的数据
     * @param $condition 字符串 'name=:name and status=:status'
     * @param $params    数组  $condition中参数的对应值 array('name'=>'zhagnsan','status'=>1)
     * @param $select    数组 选择的字段
     * @param $order     排序
     * @return array
     */
    public function getInfoByCondition($condition, $params, $select, $order = null, $limit = null, $offset = null, $distinct = false)
    {
        $rows = array();
        $criteria = new CDbCriteria();
        $criteria->condition = $condition;
        if(!empty($params))
            $criteria->params = $params;
        if (!empty($select)) {
            $criteria->select = join(",", $select);
        }
        if (!empty($order)) {
            $criteria->order = $order;
        }
        if (!empty($limit)) {
            $criteria->limit = $limit;
        }
        if (isset($offset)) {
            $criteria->offset = $offset;
        }
        $criteria->distinct = $distinct;
        $data = $this->findAll($criteria);
        if (!empty($data)) {
            if (!empty($select)) {
                foreach ($data as $value) {
                    $row = array();
                    foreach ($select as $v) {
                        $row[$v] = $value->{$v};
                    }
                    $rows[$value->id] = $row;
                }
            } else {
                foreach ($data as $value) {
                    $rows[$value->id] = $value->attributes; //如果没有指定参数则返回表中所有字段
                }
            }
        }

        return $rows;
    }
    /**
     * 根据条件和参数等返回对应的数据
     * @param $condition    字符串 'name=:name and status=:status'
     * @param $params       数组  $condition中参数的对应值 array('name'=>'zhagnsan','status'=>1)
     * @param $select       数组  选择的非求和的字段
     * @param $sum_select   数组  选择的需要求和的字段
     * @param $group        数组  分组参数
     * @return array
     */
    public function getGroupInfoByCondition($condition, $params, $select = array(), $sum_select = array(), $group = array(), $order = null, $limit = null, $offset = null)
    {
        $rows = array();
        $criteria = new CDbCriteria();
        $criteria->condition = $condition;
        if(!empty($params))
            $criteria->params = $params;
        $criteria->group = join(",", $group);
        $criteria->select = $criteria->group;
        if (!empty($select)) {
            $criteria->select .= join(",", $select);
        }
        if (!empty($sum_select)) {
            foreach ($sum_select as $key) {
                if(is_array($key))
                    foreach ($key as $k=>$v) {
                        $criteria->select .= ', sum(cast(' . $k . ' as decimal(10,2))) as ' . $v;
                    }
                else
                    $criteria->select .= ', sum(cast(' . $key . ' as decimal(10,2))) as ' . $key;
            }
        }
        if (!empty($order)) {
            $criteria->order = $order;
        }
        if (!empty($limit)) {
            $criteria->limit = $limit;
        }
        if (isset($offset)) {
            $criteria->offset = $offset;
        }
        var_export($criteria);
        exit;
        $data = $this->findAll($criteria);

        $total_select = array_merge($select, $sum_select);
        if (!empty($data)) {
            if (!empty($total_select)) {
                foreach ($data as $value) {
                    $row = array();
                    foreach ($total_select as $v) {
                        $row[$v] = $value->{$v};
                    }
                    $rows[$value->id] = $row;
                }
            } else {
                foreach ($data as $value) {
                    $rows[$value->id] = $value->attributes; //如果没有指定参数则返回表中所有字段
                }
            }
        }

        return $rows;
    }

    /**
     * @alias           查询
     * @description     查询数据表
     * @param           $param过滤条件数组
     * @param           $select返回字段数组
     * @param           $order排序字段
     * @param           $limit返回数据最多条数
     * @param           $offset跳过条数
     * @param           $group是否去重
     * @return          查询结果数组
     */
    public function getGroup($params, $select = array(), $order = null, $limit = null, $offset = null, $group = false)
    {
        $models = $this->getGroupModel($params, $select, $order, $limit, $offset, $group);
        $result = array();
        foreach ($models as $model) {
            $item = $model->convertToArray($select);
            $result[] = $item;
        }

        return $result;
    }

    public function getGroupModel($params, $select = array(), $order = null, $limit = null, $offset = null, $group = false)
    {
        $criteria = new CDbCriteria;
        $criteria->condition = $this->_getCondition($params);
        if (!empty($select)) {
            $criteria->select = $this->selectFormat($select);
        }

        if (!empty($order)) {
            $criteria->order = $order;
        }

        if (!empty($limit)) {
            $criteria->limit = $limit;
        }
        if (isset($offset)) {
            $criteria->offset = $offset;
        }
        if (!empty($group)) {
            $criteria->group = $group;
        }
        return $this->findAll($criteria);
    }

    private function selectFormat($select)
    {
        $s = '';
        foreach($select as $k => $v)
        {
            $s .= ',' . (is_numeric($k) ? '`'.$v.'`' : $k . ' ' . $v);
        }
        return substr($s, 1);
    }
}
