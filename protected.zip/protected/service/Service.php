<?php
/**
 * Service class
 */
class Service
{
    private static $_instance = null;
    private static $service_objects = array();

	/**
	 * error code
	 */
	const ERROR_SYSTEM_EXCEPTION = 101;
	const ERROR_INVALID_PARAM = 102;
	const ERROR_RESOURCE_EXIST = 103;
	const ERROR_RESOURCE_NOT_EXIST = 104;
	const ERROR_OPT_FAIL = 105;

    public static function instance() {
        if (null === self::$_instance) {
            $class = __CLASS__;
            self::$_instance = new $class;
        }
        return self::$_instance;
    }

	public static function &getService($service) {
		$service = strtolower($service);
        $serviceClass = ucfirst($service) . 'API';
		if (isset(self::$service_objects[$service])) {
            return self::$service_objects[$service];
        }
		if (!class_exists($serviceClass)) {
            throw new ServiceException('The service ' . $serviceClass . ' not found', self::ERROR_SYSTEM_EXCEPTION);
		}
		$obj = new $serviceClass();
		self::$service_objects[$service] = &$obj;
		return $obj;
	}

    public function __get($name) {
        return self::getService($name);
    }
}
