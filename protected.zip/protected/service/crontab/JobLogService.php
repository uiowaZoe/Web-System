<?php
/**
 * Created by PhpStorm.
 * User: bgl
 * Date: 2015/9/16
 * Time: 19:39
 */
class JobLogService
{
   public static  function findJob()
   {
       $connection = Yii::app()->mongodb;
       $sql = "$connection->JobLog->findall()";
       var_dump( $sql);
   }

    public static function getPara()
    {
        $para = array();
        if (isset($_GET["job_time"]))//是否存在"job_time"的参数
        {
            $job_time = $_GET["job_time"];//存在
            if ($job_time != "") {
                $para["crontabtime"] = $job_time;
            }
        }
        if (isset($_GET["job_name"]))//是否存在"job_name"的参数
        {
            $job_name = $_GET["job_name"];//存在
            if ($job_name != "") {
                $para["cmd"] = $job_name;
            }
        }
        if (isset($_GET["job_sig"]))//是否存在"job_sig"的参数
        {
            $job_sig = $_GET["job_sig"];//存在
            if ($job_sig != "") {
                $para["single"] = $job_sig;
            }
        }
        return $para;
    }
}
