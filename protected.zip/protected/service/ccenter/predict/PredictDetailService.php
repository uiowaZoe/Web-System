<?php
/**
 * Created by PhpStorm.
 * User: meicai
 * Date: 2015/10/12
 * Time: 15:51
 */
class PredictDetailService
{
    public static function searchDetail($para,$user_info){
        $creat="
        create  table if not EXISTS ";
        $creat.="t_cc_predict_phase_ci" ."_".date("Ymd ",strtotime($para["delivery_time"]))." like t_cc_predict_phase_ci;";

        $sql = "

          SELECT
          timepoint,
          predict_num,
          high_predict_num,
          low_predict_num";
           $sql .= " FROM t_cc_predict_phase_ci" ."_".date("Ymd ",strtotime($para["delivery_time"]))." "."where"." ";
        if ($para["city"] != "") {
            $sql .= " city = " . $para["city"] . " ";
        }else {
            $sql = $sql . "  city in(" . $user_info["own_city"] . ")";
        }

        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }

        $sql .= " AND ciid = " . $para["ciid"] . " ";
        Yii::app()->cc->createCommand($creat)->execute();
        return Yii::app()->cc->createCommand($sql)->queryAll();

    }    
    public static function getPredictnum($para,$user_info,$recentdate){
        $creat="
        create  table if not EXISTS ";
        $creat.="t_cc_predict_phase_ci" ."_".date("Ymd ",strtotime($recentdate))." like t_cc_predict_phase_ci;";
        $sql = "

          SELECT
          timepoint,
          predict_num";
        $sql .= " FROM t_cc_predict_phase_ci"  ."_".date("Ymd ",strtotime($recentdate))." "."where"." ";
        // WHERE FROM_UNIXTIME(delivery_time,'%Y-%m-%d') =" ."'".$recentdate."'";
        if ($para["city"] != "") {
            $sql .= " city = " . $para["city"] . " ";
        }else {
            $sql = $sql . "  city in(" . $user_info["own_city"] . ")";
        }

        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }
        $sql .= " AND ciid = " . $para["ciid"] . " ";
        Yii::app()->cc->createCommand($creat)->execute();
        return Yii::app()->cc->createCommand($sql)->queryAll();
    }
    public static function getTimeline($para,$user_info,$recentdate){
        $creat="
        create  table if not EXISTS ";
        $creat.=" t_cc_predict_phase_ci" ."_".date("Ymd ",strtotime($recentdate)) ." "."like t_cc_predict_phase_ci;";

        $sql = "
          SELECT
          timepoint  ";
        $sql .= "FROM t_cc_predict_phase_ci" . "_".date("Ymd ",strtotime($recentdate))." "."where"." ";
        if ($para["city"] != "") {
            $sql .= " city = " . $para["city"] . " ";
        }else {
            $sql = $sql . " city in(" . $user_info["own_city"] . ")";
        }

        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }

        $sql .= " AND ciid = " . $para["ciid"] . " ";
        Yii::app()->cc->createCommand($creat)->execute();

        return Yii::app()->cc->createCommand($sql)->queryAll();
    }

    public static function getEcpectnum($para,$user_info,$recentdate){
        $creat="
        create  table if not EXISTS ";
        $creat.="t_order_item_mirror" ."_".date("Ymd ",strtotime($recentdate))." "."like t_order_item_mirror;";
        $sql = "
                select
                city_id city,
                warehouse ,
                sum(expect_num) expect_num from";
        $sql .= " "."t_order_item_mirror" ."_".date("Ymd ",strtotime($recentdate))." "."where"." ";
        if ($para["city"] != "") {
            $sql .= "  city_id = " . $para["city"] . " ";
        }else {
            $sql .= "  city_id in(" . $user_info["own_city"] . ")";
        }

        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }
        if ($para["ciid"] != "") {
            $sql .= " AND ci = " . $para["ciid"] . " ";
        }
        Yii::app()->cc->createCommand($creat)->execute();
        return Yii::app()->cc->createCommand($sql)->queryAll();
    }
    
    public static function getEcpectnum_v2($para,$user_info,$days_num){
    	$delivery_date = $para['delivery_time'];
    	$unix_delivery_date_end = strtotime($delivery_date);
    	$unix_delivery_date_start = $unix_delivery_date_end - $days_num * 24 * 3600;
    	
    /* 	$sql = "
                select
                city_id city,
                a.operate_area warehouse ,
                sum(expect_num) expect_num
				from t_order_item  a
         WHERE FROM_UNIXTIME(delivery_time,'%Y-%m-%d') =" ."'".$recentdate."'"; */
        $creat="
        create  table if not EXISTS ";
        $creat.="t_order_item_mirror" ."_".date("Ymd ",strtotime($para["delivery_time"]))." "."like t_order_item_mirror;";
    	$sql = "
                select
                city_id city,
                warehouse ,
                sum(expect_num) expect_num from";
        $sql .= " "."t_order_item_mirror" ."_".date("Ymd ",strtotime($para["delivery_time"]))." "."where"." ";

    	
    	if ($para["city"] != "") {
    		$sql .= " city_id = " . $para["city"] . " ";
    	}else {
    		$sql = $sql . "city_id in(" . $user_info["own_city"] . ")";
    	}
    
    	if ($para["warehouse"] != "") {
    		$sql .= " AND warehouse = " . $para["warehouse"] . " ";
    	}
    
    	$sql .= " AND ci = " . $para["ciid"] . " ";
    	//$sql .= " group by city_id,operate_area,lu_commodity_item_id";
    	$sql .= " group by delivery_time order by delivery_time desc";
        Yii::app()->cc->createCommand($creat)->execute();
    	return  Yii::app()->cc->createCommand($sql)->queryAll();
    	/* $rows_ret = array();
    	foreach ($rows_from_db as $index=>$value){
    		$row_ret[$value['delivery_time']]['city'] =  
    	} */
    }

}