<?php

/**
 * Created by PhpStorm.
 * User: guanzhongyang
 * Date: 2015/8/27
 * Time: 13:47
 */
class PredictDataService
{

    /**
     * 生产分拣
     * @params $distributeDate 配送日期
     * @params $cityId
     * @return array
     */
    public static function PredictCisSearch($para,$user_info)
    {
        $creat="
        create  table if not EXISTS ";
        $creat.="t_cc_predict_phase_ci" ."_".date("Ymd ",$para["delivery_time"])." like t_cc_predict_phase_ci;";

        $sql = "

          SELECT
          id,
          ciid,
          class1,
          class1_name,
          class2,
          class2_name,
          item_name,
          timepoint,
          predict_num,
          city,
          warehouse,
          high_predict_num,
          low_predict_num,
          FROM_UNIXTIME(delivery_time, '%Y-%m-%d') delivery_time";
        $sql .=" ". "FROM t_cc_predict_phase_ci"."_".date("Ymd ", $para["delivery_time"])." "."where"." ";
        if ($para["city"] != "") {
            $sql .= " city = " . $para["city"] . " ";
        }else {
            $sql = $sql . "city in(" . $user_info["own_city"] . ")";
        }
        if ($para["timepoint"] != "") {
            $sql .= "and timepoint = " . $para["timepoint"] . " ";
        }else{
            $sql2 = "
             SELECT
          ciid,
          class1,
          class1_name,
          class2,
          class2_name,
          item_name,
          predict_num,
          city,
          warehouse,
          FROM_UNIXTIME(delivery_time, '%Y-%m-%d') delivery_time,
          timepoint,
          high_predict_num,
          low_predict_num";
            $sql2 .=" ".  "FROM t_cc_predict_phase_ci"."_".date("Ymd ", $para["delivery_time"])." "."where"." ";
            if ($para["city"] != "") {
                $sql2 .= " city = " . $para["city"] . " ";
            }else {
                $sql2 = $sql2 . "city in(" . $user_info["own_city"] . ")";
            }
            if ($para["item_name"] != "") {
                $sql2 .= "AND item_name like '%".$para["item_name"] ."%'";
            }

            if ($para["warehouse"] != "") {
                $sql2 .= " AND warehouse = " . $para["warehouse"] . " ";
            }
            if ($para["class1"] != "") {
                $sql2 .= " AND class1 = " . $para["class1"] . " ";
            }
            if ($para["class2"] != "") {
                $sql2 .= " AND class2 = " . $para["class2"] . " ";
            }
            if ($para["ciid"] != "") {
                $sql2 .= " AND ciid = " ."'". $para["ciid"] ."'". " ";
            }

            $sql2 .= " And timepoint in(SELECT MAX(timepoint)";
            $sql2 .=" ". " FROM t_cc_predict_phase_ci"."_".date("Ymd ", $para["delivery_time"])." ";
            $sql2 .= "group by ciid,city,warehouse ) ";
            $sql2 .= "group by ciid,city,warehouse ";
            $sql2 .= " ORDER BY predict_num desc";
            Yii::app()->cc->createCommand($creat)->execute();
            return Yii::app()->cc->createCommand($sql2 )->queryAll();
        }
        if ($para["item_name"] != "") {
            $sql .= "AND item_name like '%".$para["item_name"] ."%'";
        }

        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }
        if ($para["class1"] != "") {
            $sql .= " AND class1 = " . $para["class1"] . " ";
        }
        if ($para["class2"] != "") {
            $sql .= " AND class2 = " . $para["class2"] . " ";
        }
        if ($para["ciid"] != "") {
            $sql .= " AND ciid = "."'" . $para["ciid"] ."'". " ";
        }
        $sql .= "group by ciid,city,warehouse ";
        $sql .= " ORDER BY predict_num desc";
        Yii::app()->cc->createCommand($creat)->execute();
        return Yii::app()->cc->createCommand($sql)->queryAll();

    }
    public static function getPage($para,$startNum,$user_info){
        $creat="
        create  table if not EXISTS ";
        $creat.="t_cc_predict_phase_ci" ."_".date("Ymd ",$para["delivery_time"])." like t_cc_predict_phase_ci;";

        $sql = "

          SELECT
          ciid,
          class1,
          class1_name,
          class2,
          class2_name,
          item_name,
          timepoint,
          predict_num,
          city,
          warehouse,
          FROM_UNIXTIME(delivery_time, '%Y-%m-%d') delivery_time,
          high_predict_num,
          low_predict_num";
        $sql .=" ".  "FROM t_cc_predict_phase_ci"."_".date("Ymd ", $para["delivery_time"])." "."where"." ";
        if ($para["city"] != "") {
            $sql .= "city = " . $para["city"] . " ";
        }else {
            $sql = $sql . " city in(" . $user_info["own_city"] . ")";
        }
        if ($para["timepoint"] != "") {
            $sql .= " AND timepoint = " . $para["timepoint"] . " ";
        }else{
            $sql2 = "
             SELECT
          ciid,
          class1,
          class1_name,
          class2,
          class2_name,
          item_name,
          predict_num,
          city,
          warehouse,
          FROM_UNIXTIME(delivery_time, '%Y-%m-%d') delivery_time,
         timepoint,
          high_predict_num,
          low_predict_num";
         $sql2 .=" ".  "FROM t_cc_predict_phase_ci" ."_".date("Ymd ", $para["delivery_time"])." "."where"." ";
            if ($para["city"] != "") {
                $sql2 .= "city = " . $para["city"] . " ";
            }else {
                $sql2 = $sql2 . " city in(" . $user_info["own_city"] . ")";
            }
            if ($para["item_name"] != "") {
                $sql2 .= "AND item_name like '%".$para["item_name"] ."%'";
            }

            if ($para["warehouse"] != "") {
                $sql2 .= " AND warehouse = " . $para["warehouse"] . " ";
            }
            if ($para["class1"] != "") {
                $sql2 .= " AND class1 = " . $para["class1"] . " ";
            }
            if ($para["class2"] != "") {
                $sql2 .= " AND class2 = " . $para["class2"] . " ";
            }
            if ($para["ciid"] != "") {
                $sql2 .= " AND ciid = "."'" . $para["ciid"] ."'". " ";
            }
            $sql2 .= " And timepoint in(SELECT MAX(timepoint)";
            $sql2 .=" ". " FROM t_cc_predict_phase_ci"."_".date("Ymd ", $para["delivery_time"]). " ";
            $sql2 .= "group by ciid,city,warehouse ) ";
            $sql2 .= "group by ciid,city,warehouse  ";

            $sql2 .= " ORDER BY predict_num desc";
            Yii::app()->cc->createCommand($creat)->execute();
            return Yii::app()->cc->createCommand($sql2." limit ". $startNum .",". 20 )->queryAll();
        }
        if ($para["item_name"] != "") {
            $sql .= "AND item_name like '%".$para["item_name"] ."%'";
        }

        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }
        if ($para["class1"] != "") {
            $sql .= " AND class1 = " . $para["class1"] . " ";
        }
        if ($para["class2"] != "") {
            $sql .= " AND class2 = " . $para["class2"] . " ";
        }
        if ($para["ciid"] != "") {
            $sql .= " AND ciid = "."'" . $para["ciid"] ."'". " ";
        } $sql .= "group by ciid,city,warehouse "." ";
        $sql .= " ORDER BY predict_num desc";
        Yii::app()->cc->createCommand($creat)->execute();
        return Yii::app()->cc->createCommand($sql." limit ". $startNum .",". 20 )->queryAll();
    }

    public static  function getTitle(){
        $sql = "DESC t_cc_predict_phase_ci";
        return Yii::app()->cc->createCommand($sql)->queryAll();
    }


}