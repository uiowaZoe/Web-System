﻿<?php
function sortByCi($row1, $row2) {
	if ($row1 ['ci'] == $row2 ['ci']) {
		return 0;
	}
	return $row1 ['ci'] < $row2 ['ci'] ? - 1 : 1;
}

function sortByCiid($row1, $row2) {
	if ($row1 ['ciid'] == $row2 ['ciid']) {
		return 0;
	}
	return $row1 ['ciid'] < $row2 ['ciid'] ? - 1 : 1;
}


class PredictFlushService {
	public $delivery_time; //
	public $delivery_time_start;
	public $predict_before_days; // 30
	public $predict_start_time; // 18
	public $predict_end_time; // 23
	public $predict_minimal_time; // 10
	public $predict_maxmal_time; // 23
	public $predict_interval; // hour
	function __construct() {
		$this->predict_before_days = intVal ( SystemSetService::getSystemKey ( 'predict_before_days' ), 10 ); // 30
		$this->predict_start_time = intVal ( SystemSetService::getSystemKey ( 'predict_start_time' ), 10 ); // 18
		$this->predict_end_time = intVal ( SystemSetService::getSystemKey ( 'predict_end_time' ), 10 ); // 23
		$this->predict_minimal_time = intVal ( SystemSetService::getSystemKey ( 'predict_minimal_time' ), 10 ); // 10
		$this->predict_maxmal_time = intVal ( SystemSetService::getSystemKey ( 'predict_maxmal_time' ), 10 ); // 23
		$this->predict_interval = intVal ( SystemSetService::getSystemKey ( 'predict_interval' ), 10 ); // hour
		echo $this->predict_before_days . '-' . $this->predict_start_time . '-' . $this->predict_end_time . '-' . $this->predict_minimal_time . '-' . $this->predict_maxmal_time . '-' . $this->predict_interval;
	}
	public function estimate_v2($delivery_time, $hour, $get_cur_hour) // 预估所有的订单值
	{
		$delivery_time = strtotime ( $delivery_time );
		$delivery_time_start = $delivery_time - $this->predict_before_days * 24 * 3600;
		$sql = "select lu_commodity_item_id ciid, city_id city,a.operate_area warehouse ,sum(expect_num)/$this->predict_before_days predict_num, 
sum(expect_num)/$this->predict_before_days expect_num, delivery_time, class2_id class2, From_unixtime(c_t, '%H') timepoint
		from t_order_item  a
		where delivery_time< $delivery_time and delivery_time>=$delivery_time_start and (status=2  or status=3)
		group by city_id,operate_area,lu_commodity_item_id";
	
		$connection_db = Yii::app ()->db;
		$command = $connection_db->createCommand ( $sql );
		$rows = $command->queryAll ();
		/**
		 * need to refactory
		*/
		$dataFlushService = new DataFlushService ();
		//$newRows = $dataFlushService->buildOIData ( $rows );
		$newRows = CCPubService::buildOIDataNewDb($rows);
		/**根据ci进行排序**/
		usort ( $newRows, 'sortByCiid' );
		if ($get_cur_hour) {
			$this->reCalculate ( $newRows, $delivery_time, $delivery_time_start, $hour, $this->predict_start_time );
		} else {
			$this->reCalculateBatch ( $newRows, $delivery_time, $delivery_time_start, $this->predict_start_time );
		}
	}
	private function reCalculateBatch(&$newRows, $delivery_time, $delivery_time_start, $starthour) {
		for($hour = $this->predict_minimal_time; $hour <= $this->predict_maxmal_time; $hour ++) {
			// echo $times++;
			$this->reCalculate ( $newRows, $delivery_time, $delivery_time_start, $hour, $starthour );
		}
		// exit(1);
	}
	private function reCalculate(&$newRows, $delivery_time, $delivery_time_start, $hour, $starthour) {
		$connection_db = Yii::app ()->db;
		$connection_cc = Yii::app ()->cc;
		//$unix_time = $delivery_time + $hour * 3600;
		
		$sql = '';
		print_r("\n");
		echo $hour;
		print_r("\n");
		print_r(count($newRows));
		print_r("\n");
		foreach ( $newRows as $row ) {
			$insert_row ['city'] = $row ["city"];
			$insert_row ['warehouse'] = $row ["warehouse"];
			$insert_row ['ciid'] = $row ["ciid"];
			$insert_row ['delivery_time'] = $delivery_time;
			$insert_row ['timepoint'] = $hour;
			$insert_row ['predict_num'] = $row ['predict_num'];
			$insert_row ['expect_num'] = $row['expect_num'];
			$insert_row ['class1'] = $row ["class1"];
			$insert_row ['class1_name'] = $row ["class1_name"];
			$insert_row ['class2'] = $row ['class2'];
			$insert_row ['class2_name'] = $row ["class2_name"];
			$insert_row ['item_name'] = $row ["item_name"];
			$insert_row ['low_predict_num'] = $row ['predict_num'];
			$insert_row ['high_predict_num'] = $row ['predict_num'];
			
			$my_predict_num [$row ['ciid'] . $row ['city'] . $row ['warehouse']] = $row ['predict_num'];
			
			$insert_rows [] = $insert_row;
		}
		// print_r($newRows);
		// exit(1);
		
		if ($hour >= $starthour) {
			
			 $sql_percent = "select * from t_cc_predict_base_percent where timepoint=$hour";
			 $command = $connection_cc->createCommand ( $sql_percent );
			 $rows_percent = $command->queryAll (); 
			 usort ( $rows_percent, 'sortByCi' );
			 print_r('-------rows percent='.count($rows_percent));
			 //print_r($rows_percent);
			$sql = "select lu_commodity_item_id ciid, city_id city,a.operate_area warehouse ,sum(expect_num) num,class2_id class2
				from t_order_item  a
				where delivery_time = $delivery_time and FROM_UNIXTIME(a.c_t,'%H')<$hour and (status=2  or status=3)
				group by city_id,operate_area,lu_commodity_item_id";
			$command = $connection_db->createCommand ( $sql );
			$rows_hours = $command->queryAll ();
			usort ( $rows_hours, 'sortByCiid' );
			//print_r($rows_hours);
			$row_hour_current = 0;
			$row_percent_current = 0;
			//print_r($insert_rows);
			foreach ( $insert_rows as $index => $row ) {
				$total_ave = $row['expect_num'];
				$insert_rows [$index] ['low_predict_num'] = $total_ave;
				$insert_rows [$index] ['high_predict_num'] = $total_ave;
				$percent = 0;
				$weight = 0;
				$bFind_total = false;
				$bfind_percent = false;
				$sum_hour = 0;
				$how_many_ciid_equal_percent = 0;
				for($i_percent = $row_percent_current; $i_percent<count($rows_percent);$i_percent++)
                                            //select * from t_cc_predict_base_percent where timepoint=$hour
				{
					if ($rows_percent[$i_percent]['ci']>$row['ciid']){
						$row_percent_current = $i_percent;
						break;
					}else if($rows_percent[$i_percent]['ci']<$row['ciid']){
						
					}else{
						if(($hour == $rows_percent[$i_percent] ['timepoint']) 
                                                         && ($rows_percent[$i_percent]['city'] == $row['city']) 
                                                         && ($rows_percent[$i_percent]['warehouse'] == $row['warehouse'])){
							$row_percent_current = $i_percent - $how_many_ciid_equal_percent - 1;
							if($row_percent_current < 0){
								$row_percent_current = 0;
							}
							$bfind_percent = true;
							
							$percent = $rows_percent[$i_percent] ['percent'];
							$low_percent = $rows_percent[$i_percent] ['low_percent'];
							$high_percent = $rows_percent[$i_percent] ['high_percent'];
							$weight = $rows_percent[$i_percent] ['weight'];
							
							break;
						}
						else{
							$how_many_ciid_equal_percent++;
						}
					}
				}
				
				if(!$bfind_percent){
					continue;//无百分比，则不参加预测
				}
				$how_many_ciid_equal = 0;
				for($i_hour = $row_hour_current;$i_hour<count($rows_hours);$i_hour++)
				{
					if($rows_hours[$i_hour]['ciid'] > $row['ciid'])
					{
						$row_hour_current = $i_hour;
						break;
					}else if($rows_hours[$i_hour]['ciid'] == $row['ciid']){
						if(($rows_hours[$i_hour]['city'] == $row['city']) && ($rows_hours[$i_hour]['warehouse'] == $row['warehouse'])){
							$bFind_total = true;
							$row_hour_current = $i_hour - $how_many_ciid_equal - 1;
							if($row_hour_current < 0){
								$row_hour_current = 0;
							}
							$sum_hour = $rows_hours[$i_hour] ['num'];
							break;
						}else{
							$how_many_ciid_equal++;
						}
						
					}else{
						
					}
				}
				if($bFind_total){
					if($percent != 0.0){
						$insert_rows [$index] ['predict_num'] = $sum_hour / $percent;
						$insert_rows [$index] ['low_predict_num'] = $sum_hour / $high_percent;
						if ($low_percent != 0.0){
							$insert_rows [$index] ['high_predict_num'] = $sum_hour / $low_percent;
						}else{
							$insert_rows [$index] ['high_predict_num'] = $sum_hour / $percent;
						}
					}else{
						$insert_rows [$index] ['predict_num'] = $total_ave;
						$insert_rows [$index] ['low_predict_num'] = $total_ave;
						$insert_rows [$index] ['high_predict_num'] = $total_ave;
					}
					/* if($low_percent != 0.0){
						$insert_rows [$index] ['high_predict_num'] = $sum_hour / $low_percent;
					}else{
						if($percent != 0.0){
							$insert_rows [$index] ['predict_num'] = $sum_hour / $percent;
						}else{
							$insert_rows [$index] ['predict_num'] = $total_ave;
						}
					}
					if($high_percent != 0.0){
						$insert_rows [$index] ['low_predict_num'] = $sum_hour / $high_percent;
					}else{
						$insert_rows [$index] ['predict_num'] = $total_ave;
					} */
				}else{
					$insert_rows [$index] ['predict_num'] = $total_ave;
					$insert_rows [$index]['low_predict_num'] = $total_ave;
					$insert_rows [$index]['high_predict_num'] = $total_ave;
				}
			}
		} else {
			// nothing happend
		}
		$dataFlushService = new DataFlushService ();
		// print_r($insert_rows);
		if (count ( $insert_rows ) > 0) {
			$str_delivery_time = date('Ymd', $delivery_time);
			$table_name = 't_cc_predict_phase_ci_'.$str_delivery_time;
			echo $table_name;
			$sql_create_table = "create  table if not EXISTS $table_name like t_cc_predict_phase_ci;";
			$command_create = $connection_cc->createCommand($sql_create_table);
			$command_create->execute();			
			
			// $newRows = $this->buildOIData($newRows);
			for($index = 0; $index < count ( $insert_rows ); $index += 1000) {
				$subarray = array_slice ( $insert_rows, $index, 1000 );
				$cccommand = Yii::app ()->cc->createCommand ( $dataFlushService->insertbatch ($table_name, $subarray ) );
				$cccommand->execute ();
				$cccommand->getPdoStatement ()->closeCursor ();
			}
		}
	}
	public function percent_v2($delivery_time) {
		$connection_cc = Yii::app ()->cc; // 已经建立了一个 "cc" 连接
		$connection_db = Yii::app ()->db;
		$sql = "DELETE FROM `t_cc_predict_base_percent`";
		$command = $connection_cc->createCommand ( $sql );
		$command->execute ();

		$delivery_time = strtotime ( $delivery_time );
		$delivery_time_start = $delivery_time - $this->predict_before_days * 24 * 3600;
		
		$num_interval = 100 / ($this->predict_end_time - $this->predict_start_time + 1);
		$dataFlushService = new DataFlushService ();
		for($r_index = 0; $r_index < 10; $r_index ++) {
			$table_name = 't_cc_predict_percent_everyday_' . $r_index;
			//$sql_percents = "SELECT ci, city, warehouse, timepoint, MAX(percent) high_percent, SUM(percent) percent, MIN(percent) low_percent from $table_name where delivery_time<$delivery_time and delivery_time >= $delivery_time_start GROUP BY ci, city, warehouse, timepoint";
			$sql_percents = "SELECT ci, city, warehouse, timepoint, MAX(percent) high_percent, avg(percent) percent, MIN(percent) l
ow_percent from $table_name where delivery_time<$delivery_time and delivery_time >= $delivery_time_start GROUP BY ci, city, warehouse, timepoint";
			echo $sql_percents;
			$command = $connection_cc->createCommand ( $sql_percents );
			$rows_all_percents = $command->queryAll ();
			foreach ( $rows_all_percents as $index => $row ) {
				$singleTimePoint = $rows_all_percents [$index] ['timepoint'];
				$rows_all_percents [$index] ['weight'] = ($singleTimePoint - $this->predict_start_time + 1) * $num_interval;
				//$rows_all_percents [$index] ['percent'] = $rows_all_percents [$index] ['percent'] / $this->predict_before_days ;
				$rows_all_percents [$index] ['percent'] = $rows_all_percents [$index] ['percent'];
				/* if ($rows_all_percents [$index] ['low_percent'] > $rows_all_percents [$index] ['percent']) {
					$rows_all_percents [$index] ['low_percent'] = $rows_all_percents [$index] ['percent'];
				} */
				/* if($rows_all_percents[$index]['low_percent'] == 0){
					$rows_all_percents[$index]['low_percent'] = $rows_all_percents [$index] ['percent'];
				} */
			}
			if(count($rows_all_percents) > 0)
			{
				$cccommand = $connection_cc->createCommand ( $dataFlushService->insertbatch ( "t_cc_predict_base_percent", $rows_all_percents ) );
				$cccommand->execute ();
				$cccommand->getPdoStatement ()->closeCursor ();
			}
			
			// print_r($rows_all_percents);
		}
		// exit(1);
	}
	public function preprocessing($delivery_time, $num_days) { // 保留所有整点百分比10-23
		$connection_cc = Yii::app ()->cc; // 已经建立了一个 "cc" 连接
		$connection_db = Yii::app ()->db;
		$delivery_time = strtotime ( $delivery_time );
		$delivery_time_start = $delivery_time - $num_days * 24 * 3600;
		
		$cursor = 0;
		
		// $order_elem_num = count($all_order_rows);
		for($dateCur = $delivery_time_start; $dateCur < $delivery_time; $dateCur += 24 * 3600) {
			echo date ( 'y-m-d', $dateCur );
			$time_point_row = array ();
			$sql_all_order_info = "SELECT lu_commodity_item_id ci, city_id, operate_area warehouse, delivery_time, 
FROM_UNIXTIME(c_t, '%H') time_point, expect_num from t_order_item 
where delivery_time=$dateCur and (status=2  or status=3);";
			
			// echo $sql_all_order_info;
			$command = $connection_db->createCommand ( $sql_all_order_info );
			$all_order_rows = $command->queryAll ();
			
			/**insert the total order info to the new table,t_order_item_mirror_$date**/
			
			if (count ( $all_order_rows ) > 0) {
				$dataFlushService = new DataFlushService ();
				$new_table_name="t_order_item_mirror_".date ( 'Ymd', $dateCur );
				$sql_create = "create table if not exists $new_table_name like t_order_item_mirror";
				$command_create = $connection_cc->createCommand($sql_create);
				$command_create->execute();
			
				for($index = 0; $index < count ( $all_order_rows ); $index += 1000) {
					$subarray = array_slice ( $all_order_rows, $index, 1000 );
					$cccommand = Yii::app ()->cc->createCommand ( $dataFlushService->insertbatch ($new_table_name, $subarray ) );
					$cccommand->execute ();
					$cccommand->getPdoStatement ()->closeCursor ();
				}
			}
				
				
			/**insert the total order info to the new table**/
			
			$rows_percent = array ();
			for($cursor = 0; $cursor < count ( $all_order_rows ); $cursor ++) {
				$int_time_point = intVal ( $all_order_rows [$cursor] ['time_point'], 10 );
				$int_cid = $all_order_rows [$cursor] ['ci'];
				$int_city_id = $all_order_rows [$cursor] ['city_id'];
				$int_warehouse = $all_order_rows [$cursor] ['warehouse'];
				$int_expcet_num = $all_order_rows [$cursor] ['expect_num'];
				//$time_point_row [$int_time_point] [$int_cid] [$int_city_id] [$int_warehouse] ['num'] = isset ( $time_point_row [$int_time_point] [$int_cid] [$int_city_id] [$int_warehouse] ['num'] ) ? ($int_expcet_num + $time_point_row [$int_time_point] [$int_cid] [$int_city_id] [$int_warehouse] ['num']) : $int_expcet_num;
				
				$time_point_row ['total'] [$int_cid] [$int_city_id] [$int_warehouse] = 
isset ( $time_point_row ['total'] [$int_cid] [$int_city_id] [$int_warehouse] ) ? 
($time_point_row ['total'] [$int_cid] [$int_city_id] [$int_warehouse] + $int_expcet_num) : $int_expcet_num;
				if ($time_point_row ['total'] [$int_cid] [$int_city_id] [$int_warehouse] != 0) {
					for($time_point_index = $int_time_point + 1; $time_point_index <= $this->predict_maxmal_time; $time_point_index ++) {
						//echo $time_point_index;
						$time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['num'] = 
isset ( $time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['num'] ) ? 
($int_expcet_num + $time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['num']) : $int_expcet_num;
						$time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['percent'] = 
$time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['num'] / $time_point_row ['total'] [$int_cid] [$int_city_id] [$int_warehouse];
					}
					
					for($time_point_index = $this->predict_minimal_time; $time_point_index < $int_time_point + 1; $time_point_index++){
						$num = isset($time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['num'])?
$time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['num']:0;
						$time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['percent'] = 
$num / $time_point_row ['total'] [$int_cid] [$int_city_id] [$int_warehouse];
					}
				}
				/* if(($int_city_id == 1) && ($int_cid==9301) && ($int_warehouse==2) && ($int_time_point==17)){
					echo 'total-------------'.$time_point_row ['total'] [$int_cid] [$int_city_id] [$int_warehouse];
					echo '17----------------'.$time_point_row [$time_point_index] [$int_cid] [$int_city_id] [$int_warehouse] ['num'];
				} */
			}
			
			// print_r($time_point_row);
			//exit(1); 
			$row_percent ['delivery_time'] = $dateCur;
			foreach ($time_point_row as $key_timepoint=>$timehour_value){
				if($key_timepoint == 'total'){
					//print_r($timehour_value);
					continue;
				}
				$row_percent ['timepoint'] = $key_timepoint;
				foreach ($timehour_value as $key_ci=>$ci_value){
					$row_percent ['ci'] = $key_ci;
					foreach ($ci_value as $key_city=>$city_value){
						$row_percent['city'] = $key_city;
						foreach ($city_value as $key_warehouse=>$warehouse_value){							
							$row_percent ['warehouse'] = $key_warehouse;
							$row_percent ['percent'] = isset($warehouse_value ['percent'])?$warehouse_value ['percent']:0;
							//$row_percent ['num'] = isset($warehouse_value ['num'])?warehouse_value ['num']:0?;
							if($time_point_row['total'][$key_ci][$key_city][$key_warehouse] >= 50){//去掉订单量小于50的样本数据，不作为计算标本
								$rows_percent[] = $row_percent;
							}
						}
					}					
				}
			}
			
			usort ( $rows_percent, 'sortByCi' );
			// print_r($rows_percent);
			// exit(1);
			$dataFlushService = new DataFlushService ();
			if (count ( $rows_percent ) > 0) {
				$pre_index = 0;
				$index = 1;
				for($index = 1; $index < count ( $rows_percent ); $index ++) {
					if ($rows_percent [$index] ['ci'] != $rows_percent [$index - 1] ['ci']) {
						$base_ci = $rows_percent [$pre_index] ['ci'];
						$prefix = $base_ci % 10;
						$subarray = array_slice ( $rows_percent, $pre_index, $index - $pre_index );
						$tablename = 't_cc_predict_percent_everyday_' . $prefix;
						// echo $tablename;
						// exit(1);
						$cccommand = $connection_cc->createCommand ( $dataFlushService->insertbatch ( $tablename, $subarray ) );
						$cccommand->execute ();
						$cccommand->getPdoStatement ()->closeCursor ();
						$pre_index = $index;
					}
				}
				$base_ci = $rows_percent [$pre_index] ['ci'];
				$prefix = $base_ci % 10;
				$subarray = array_slice ( $rows_percent, $pre_index, $index - $pre_index );
				$tablename = 't_cc_predict_percent_everyday_' . $prefix;
				// echo $tablename;
				// exit(1);
				$cccommand = $connection_cc->createCommand ( $dataFlushService->insertbatch ( $tablename, $subarray ) );
				$cccommand->execute ();
				$cccommand->getPdoStatement ()->closeCursor ();
			}
		}
	}
}
