<?php
/**
 * Created by PhpStorm.
 * User: meicai
 * Date: 2015/10/29
 * Time: 16:13
 */class ForTestService
{

    /**
     * 生产分拣
     * @params $distributeDate 配送日期
     * @params $cityId
     * @return array
     */
    public static function PredictCisSearch($para,$date)
    {


        $sql = "SELECT lu_commodity_item_id ci,
                class2_id class2,
                city_id city,
                operate_area warehouse,
                SUM(expect_num) expect_num,
                delivery_time, ";
        $sql .= $para["timepoint"]." "."timepoint"." ";
        $sql .=" FROM t_order_item
                WHERE (status=2 or status=3) and ";
        $sql .= " city_id = " . $para["city"] . " ";
        $sql .= " AND operate_area = " . $para["warehouse"] . " ";
        $sql .= " and delivery_time=".$date." ";
        $sql .="and FROM_UNIXTIME(c_t,'%H')<".$para["timepoint"]." ";
        if ($para["ciid"] != "") {
            $sql .= " AND lu_commodity_item_id = " . $para["ciid"] . " ";
        }
        $sql .="GROUP  BY city_id,lu_commodity_item_id,operate_area order by  lu_commodity_item_id";
        return Yii::app()->db->createCommand($sql)->queryAll();

    }

    public static function PredictSearchall($para,$date)
    {


        $sql = "SELECT lu_commodity_item_id ci,
                class2_id class2,
                city_id city,
                operate_area warehouse,
                SUM(expect_num) expect_num,
                delivery_time, ";
        $sql .= $para["timepoint"]." "."timepoint"." ";
        $sql .=" FROM t_order_item
                WHERE (status=2 or status=3) and ";
        $sql .= " city_id = " . $para["city"] . " ";
        $sql .= " AND operate_area = " . $para["warehouse"] . " ";
        $sql .= " and delivery_time=".$date." ";
        $sql .="and FROM_UNIXTIME(c_t,'%H')<24"." ";
        if ($para["ciid"] != "") {
            $sql .= " AND lu_commodity_item_id = " . $para["ciid"] . " ";
        }
        $sql .="GROUP  BY city_id,lu_commodity_item_id,operate_area order by  lu_commodity_item_id";
        return Yii::app()->db->createCommand($sql)->queryAll();

    }
//    public static function PredictCisSearch_v2($para,$user_info){
//                $creat="
//        create  table if not EXISTS ";
//        $creat.="t_cc_predict_phase_ci" ."_".date("Ymd ",$para["delivery_time"])." like t_cc_predict_phase_ci;";
//
//        $sql = "
//
//          SELECT
//          id,
//          sum(expect_num) expect_num,
//          ciid,
//          class1,
//          class1_name,
//          class2,
//          class2_name,
//          item_name,";
//        $sql .=$para["timepoint"]." "."timepoint,";
//        $sql.="
//          city,
//          warehouse,
//          FROM_UNIXTIME(delivery_time, '%Y-%m-%d') delivery_time";
//        $sql .=" ". "FROM t_cc_predict_phase_ci"."_".date("Ymd ", $para["delivery_time"])." "."where"." ";
//        if ($para["city"] != "") {
//            $sql .= " city = " . $para["city"] . " ";
//        }else {
//            $sql = $sql . "city in(" . $user_info["own_city"] . ")";
//        }
//        if ($para["timepoint"] != "") {
//            $sql .= "and timepoint < " . $para["timepoint"] . " ";
//        }
//        if ($para["item_name"] != "") {
//            $sql .= "AND item_name like '%".$para["item_name"] ."%'";
//        }
//
//        if ($para["warehouse"] != "") {
//            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
//        }
//        if ($para["class1"] != "") {
//            $sql .= " AND class1 = " . $para["class1"] . " ";
//        }
//        if ($para["class2"] != "") {
//            $sql .= " AND class2 = " . $para["class2"] . " ";
//        }
//        if ($para["ciid"] != "") {
//            $sql .= " AND ciid = " . $para["ciid"] . " ";
//        }
//        $sql .= "group by ciid,city,warehouse ";
//        Yii::app()->cc->createCommand($creat)->execute();
//        return Yii::app()->cc->createCommand($sql)->queryAll();
//    }
    public static function getPage($para,$startNum){
        $sql = "SELECT lu_commodity_item_id ciid,
                class2_id class2,
                city_id city,
                operate_area warehouse,
                SUM(expect_num) expect_num,";
        $sql .= $para["timepoint"]." "."timepoint"." ";
        $sql .=" FROM t_order_item
                 WHERE (status=2 or status=3) and ";
        $sql .= " city_id = " . $para["city"] . " ";
        $sql .= " AND operate_area = " . $para["warehouse"] . " ";
        $sql .= " and delivery_time=".$para["delivery_time"]." ";
        $sql .="and FROM_UNIXTIME(c_t,'%H')<".$para["timepoint"]." ";
        if ($para["ciid"] != "") {
            $sql .= " AND lu_commodity_item_id = " . $para["ciid"] . " ";
        }
        $sql .="GROUP  BY city_id,lu_commodity_item_id,operate_area order by lu_commodity_item_id";
        return Yii::app()->db->createCommand($sql." limit ". $startNum .",". 20 )->queryAll();
    }

//    public static function getPage_v2($para,$startNum,$user_info)
//    {
//        $creat="
//        create  table if not EXISTS ";
//        $creat.="t_cc_predict_phase_ci" ."_".date("Ymd ",$para["delivery_time"])." like t_cc_predict_phase_ci;";
//
//        $sql = "
//
//          SELECT
//          sum(expect_num) expect_num,
//          ciid,
//          class1,
//          class1_name,
//          class2,
//          class2_name,";
//        $sql .=$para["timepoint"] ." ". "timepoint, ";
//        $sql .="
//          item_name,
//          predict_num,
//          city,
//          warehouse,
//          FROM_UNIXTIME(delivery_time, '%Y-%m-%d') delivery_time,
//          high_predict_num,
//          low_predict_num";
//        $sql .=" ".  "FROM t_cc_predict_phase_ci"."_".date("Ymd ", $para["delivery_time"])." "."where"." ";
//        if ($para["city"] != "") {
//            $sql .= "city = " . $para["city"] . " ";
//        }else {
//            $sql .=  " city in(" . $user_info["own_city"] . ")";
//        }
//        if ($para["timepoint"] != "") {
//            $sql .= " AND timepoint < " . $para["timepoint"] . " ";
//        }
//        if ($para["item_name"] != "") {
//            $sql .= "AND item_name like '%".$para["item_name"] ."%'";
//        }
//
//        if ($para["warehouse"] != "") {
//            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
//        }
//        if ($para["class1"] != "") {
//            $sql .= " AND class1 = " . $para["class1"] . " ";
//        }
//        if ($para["class2"] != "") {
//            $sql .= " AND class2 = " . $para["class2"] . " ";
//        }
//        if ($para["ciid"] != "") {
//            $sql .= " AND ciid = " . $para["ciid"] . " ";
//        } $sql .= "group by ciid,city,warehouse "." ";
//        Yii::app()->cc->createCommand($creat)->execute();
//        return Yii::app()->cc->createCommand($sql." limit ". $startNum .",". 20 )->queryAll();
//    }

}