<?php

/**
 * Created by PhpStorm.
 * User: wangbiwen
 * Date: 2015/9/17
 * Time: 12:37
 */
class SystemSetService
{

    public static function  getSystemKey($key)
    {
        $sql = "SELECT     svalue
                        FROM
                            t_cc_systemset t
                        WHERE skey='" . $key . "'";
        $rows = Yii::app()->cc->createCommand($sql)->queryAll();
        if (count($rows) > 0) {
            return $rows[0]["svalue"];
        } else {
            return 0;
        }
    }

    public static function  updateSystemKey($key, $value)
    {
        $sql = "SELECT     svalue
                        FROM
                            t_cc_systemset t
                        WHERE skey='" . $key . "'";
        $rows = Yii::app()->cc->createCommand($sql)->queryAll();
        if (count($rows) == 0) {
            $connection = Yii::app()->cc;
            $sql = "insert into  t_cc_systemset (skey,sname,svalue) values ('" . $key . "','','" . $key . "')";
            $command = $connection->createCommand($sql);
            $command->execute();
        } else {
            $connection = Yii::app()->cc;
            $sql = "update t_cc_systemset set svalue='" . $value . "' where skey ='" . $key . "'";
            $command = $connection->createCommand($sql);
            $command->execute();
        }

    }
}