<?php

class ClassService
{
    public function getClass1Data($startTime, $city, $warehouse,$user_info)
    {
        $connection = Yii::app()->cc;
        $sql = "SELECT class1,
                    sum(t.real_num) real_num,
                    sum(t.expect_num) expect_num,
                    truncate(100*sum(t.real_num)/sum(t.expect_num),2) rate
                FROM
                    t_cc_moniter_sorting_ci t
                WHERE
                    t.delivery_time =$startTime ";
        if ($city != "") {
            $sql = $sql . ' and t.city= ' . $city;
        }else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($warehouse != "") {
            $sql = $sql . ' and  t.warehouse= ' . $warehouse;
        }
        $sql .= "       GROUP BY class1";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        return $rows;
    }

    /**
     * @param $startTime
     * @param $city
     * @param $warehouse
     * @param $class1
     * @return mixed
     */

    public function getNumData($startTime, $city, $warehouse,$user_info)
    {

        $connection = Yii::app()->cc;
        $sql = "SELECT
                    sum(t.real_num) real_num,
                    sum(t.expect_num) expect_num,
                     truncate(100*sum(t.real_num)/sum(t.expect_num),2) nrate
                FROM
                    t_cc_moniter_sorting_ci t
                WHERE
                    t.delivery_time =" . $startTime;
        if ($city != "") {
            $sql = $sql . ' and t.city= ' . $city;
        }else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($warehouse != "") {
            $sql = $sql . ' and  t.warehouse= ' . $warehouse;
        }
        $sql .= "    ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
//        var_dump($rows[0]);
        return $rows;
    }

    public function getClass2Data($startTime, $city, $warehouse, $class1Id,$user_info)
    {

        $connection = Yii::app()->cc;


        $sql = " SELECT class2,
                        class2_name,
                        sum(t.real_num) real_num,
                        sum(t.expect_num) expect_num,
                        truncate(100*sum(t.real_num)/sum(t.expect_num),2) rate
                    FROM
                        t_cc_moniter_sorting_ci t
                    WHERE
                        t.delivery_time =$startTime
                        and t.class1= $class1Id

                 ";
        if ($city != "") {
            $sql = $sql . ' and t.city= ' . $city;
        }else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($warehouse != "") {
            $sql = $sql . ' and  t.warehouse= ' . $warehouse;
        }

        $sql .= " GROUP BY t.class2 ";

        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        return $rows;
    }
}
