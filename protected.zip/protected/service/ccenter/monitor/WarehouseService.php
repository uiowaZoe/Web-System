<?php
class WarehouseService
{

	public function getCitysWeight() {
		# 获取城市列表
		$connection=Yii::app()->cc;   // 假设你已经建立了一个 "cc" 连接
		$sql="SELECT
					t.city_id,
					sum(t.expect_weight) expect_weight,
					sum(t.real_weight) real_weight,
					sum(t.real_weight)/sum(t.expect_weight) *100 frate
				FROM
					t_sorting_task t
				WHERE
					t.delivery_time = UNIX_TIMESTAMP('2015-5-9')
				GROUP BY
					t.city_id";
		$command=$connection->createCommand($sql);
		$rows=$command->queryAll();

		// do something
		return $rows;

	}

	public function getWarehouse($distribute_t,$city,$warehouse) {
		# 获取仓库列表

		 $startTime = strtotime($distribute_t);
		
		 $city_id = intval($city);
		
		 $warehouse_id = intval($warehouse);
		
		$connection=Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
		
		$sql="SELECT
					t.state_time state_time,
					t.expect_weight expect_weight,
					t.real_weight real_weight,
					truncate(t.real_weight/t.expect_weight,2) frate
				FROM
					t_cc_moniter_sorting_warehouse t
				WHERE
					t.city= $city_id
					and 
					t.warehouse= $warehouse_id
					and 
					 t.delivery_time =".$startTime."
					limit 20
				";

		//var_dump($sql);		
		$command=$connection->createCommand($sql);
		$rows=$command->queryAll();



		// do something
		return $rows;

	}


	public function getWarehouseRateSearchByTimeline($distribute_t,$city,$warehouse,$timeLine) {
		  $rows = $this->getWarehouse($distribute_t,$city,$warehouse);

        $frate = array();//先定义一个数组来接收数据库中查询的对应值


  //分拣率(根据时间轴数组来查)
        foreach ($timeLine as  $value) {//时间轴
        	# code...
        	foreach ($rows as  $warehousevalue) {
        		# code...
        		if ($warehousevalue["state_time"]== $value) {
        			
        			# code...
        			$frate[] = $warehousevalue["frate"];

        			continue 2;
        		}
        	}
        	$frate[] =0;
        }


        return $frate;
	}
}
