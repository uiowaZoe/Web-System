<?php

class CitysService
{
    public function getCitysNum($startTime,$user_info)
    {
        # 获取城市列表

        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                    t.city city_id,
                    sum(t.expect_num) expect,
                    sum(t.real_num)   'real',
                    truncate(100*sum(t.real_num)/sum(t.expect_num),2) rate
                FROM
                    t_cc_moniter_sorting_ci t
                WHERE
                    t.delivery_time =" . $startTime . "
                and city in(" . $user_info["own_city"] . ")
                GROUP BY
                    t.city";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        // do something
        return $rows;

    }

    public function getCitysExpect($startTime,$city_list,$user_info)
    {
        # 获取城市列表

        $rows = $this->getCitysNum($startTime,$user_info);
        $expect = array();
        foreach ($city_list as $key => $value) {
            foreach ($rows as $weightkey => $weightvalue) {
                if ($weightvalue["city_id"] == $key) {
                    $expect[] = empty($weightvalue["expect"]) ? 0 : $weightvalue["expect"];;
                    continue 2;
                }
            }
            $expect[] = 0;
        }

        // do something
        return $expect;

    }

    public function getCitysReal($startTime,$city_list,$user_info)
    {
        # 获取城市列表

        $rows = $this->getCitysNum($startTime,$user_info);
        $real = array();
        foreach ($city_list as $key => $value) {
            foreach ($rows as $weightkey => $weightvalue) {
                if ($weightvalue["city_id"] == $key) {
                    $real[] = empty($weightvalue["real"]) ? 0 : $weightvalue["real"];;
                    continue 2;
                }
            }
            $real[] = 0;
        }

        // do something
        return $real;

    }
    public function getCitysRate($distributeDate, $city_list,$user_info)
    {
        $rows = $this->getCitysNum($distributeDate,$user_info);
        $rate = array();
        foreach ($city_list as $key => $value) {
            foreach ($rows as $weightkey => $weightvalue) {
                if ($weightvalue["city_id"] == $key) {
                    $rate[] = empty($weightvalue["rate"]) ? 0 : $weightvalue["rate"];;
                    continue 2;
                }
            }
            $rate[] = 0;
        }

        // do something
        return $rate;

    }

}
