<?php

class TimeLineService
{
    public static function getNowData($distributeDate, $city, $warehouse, $class1, $class2, $user_info)
    {

        $data = array();

        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                     curtime() 'time',
                    sum(t.expect_num)  expect,
                    sum( t.real_num)   'real',
                    truncate(100*sum( t.real_num)/sum(t.expect_num),2)   rate
                FROM
                     t_cc_moniter_sorting_ci t
                WHERE
                    t.delivery_time =" . $distributeDate;
        if ($city != "") {
            $sql = $sql . ' and t.city= ' . $city;
        } else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($warehouse != "") {
            $sql = $sql . ' and  t.warehouse= ' . $warehouse;
        }

        if ($class1 != "") {
            $sql = $sql . ' and  t.class1= ' . $class1;
        }
        if ($class2 != "") {
            $sql = $sql . ' and  t.class2= ' . $class2;
        }
        $sql = $sql . "   ";
//        var_dump($sql);
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
//        $data["time"] = "10:28:12";
//        $data["expect"] = "1111";
//        $data["real"] = "22";
//        $data["rate"] = "18%";
        $rows[0]["sub"] ="";// "城市：" . $city . "   仓库：" . $warehouse . "   大类：" . $class1 . "   小类：" . $class2;
        return $rows[0];
    }

    public static function getTimeLineData($distributeDate, $city, $warehouse, $class1, $class2, $user_info)
    {

        $rows = array();
        $rows = TimeLineService::getHeadNumRate($distributeDate, $city, $warehouse, $class1, $class2, $user_info);
        return $rows;
    }


    public static function getHeadWeightRate($distributeDate, $city, $warehouse, $class1, $class2, $user_info)
    {
        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                    t.timepoint,
                    sum(t.expect_weight)  expect,
                    sum( t.real_weight)   real,
                    truncate(sum( t.real_weight)/sum(t.expect_weight),3)   rate
                FROM
                     t_cc_moniter_sorting_timeline t
                WHERE
                    t.delivery_time =" . $distributeDate;
        if ($city != "") {
            $sql = $sql . ' and t.city= ' . $city;
        } else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($warehouse != "") {
            $sql = $sql . ' and  t.warehouse= ' . $warehouse;
        }

        if ($class1 != "") {
            $sql = $sql . ' and  t.class1= ' . $class1;
        }
        if ($class2 != "") {
            $sql = $sql . ' and  t.class2= ' . $class2;
        }
        $sql = $sql . " group by  t .timepoint  ";
//        var_dump($sql);
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        return TimeLineService::buildRate($distributeDate, $rows);
    }


    public static function getHeadNumRate($distributeDate, $city, $warehouse, $class1, $class2, $user_info)
    {
        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                    t.timepoint,
                    sum(t.expect_num)  expect,
                    sum( t.real_num)   'real',
                    truncate(sum( t.real_num)/sum(t.expect_num),3)   rate
                FROM
                     t_cc_moniter_sorting_timeline t
                WHERE
                    t.delivery_time =" . $distributeDate;
        if ($city != "") {
            $sql = $sql . ' and t.city= ' . $city;
        } else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($warehouse != "") {
            $sql = $sql . ' and  t.warehouse= ' . $warehouse;
        }

        if ($class1 != "") {
            $sql = $sql . ' and  t.class1= ' . $class1;
        }
        if ($class2 != "") {
            $sql = $sql . ' and  t.class2= ' . $class2;
        }
        $sql = $sql . " group by  t .timepoint  ";
//        var_dump($sql);
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        return TimeLineService::buildRate($distributeDate, $rows);
    }


    public static function buildRate($distributeDate, $rows)
    {
        $timelineArray = CCPubService::getDataTimeLine($distributeDate);
        $rate = array();
        $timepointrate = array();
        foreach ($rows as $rkey => $rvalue) {
            $pointdata = array();
            $pointdata["rate"] = $rvalue["rate"] * 100;
            $pointdata["expect"] = $rvalue["expect"];
            $pointdata["real"] = $rvalue["real"];
            $pointdata["timepoint"] = date('m-d H:i:s', $rvalue["timepoint"]);
            $timepointrate[$rvalue["timepoint"]] = $pointdata;
        }

        foreach ($timelineArray as $key => $value) {
            if (isset ($timepointrate[$value]))//是否存在"id"的参数
            {
                $rate[] = $timepointrate[$value];
            } ELSE {
                $rate[] = 0;
            }
        }
        return $rate;
    }
}
