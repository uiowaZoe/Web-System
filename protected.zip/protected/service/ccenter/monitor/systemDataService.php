<?php
/**
 * Created by PhpStorm.
 * User: meicai
 * Date: 2015/9/23
 * Time: 11:32
 */
class systemDataService
{
    public static function getData()
    {
        $sql = "select skey ,sname,svalue from t_cc_systemset";
        return Yii::app()->cc->createCommand($sql)->queryAll();
    }

    public static function edit($skey,$sname,$svalue)
    {
        $updatecommand = Yii::app()->cc->createCommand();
        $updatecommand->update('t_cc_systemset', array(
            'sname' => $sname,
            'svalue' => $svalue
        ),"skey='$skey'");
        $result = $updatecommand->execute();
    }
}