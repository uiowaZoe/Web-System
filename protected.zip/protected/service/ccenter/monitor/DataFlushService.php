﻿<?php

class DataFlushService
{
    public function flush($delivery_time)
    {
        $result = SystemSetService::getSystemKey("dataflush");
        if ($result == 0) {
            return json_encode("已经暂停数据同步", true);
        }

        $flushtime = CCPubService::getDbTime();//取当前时间
        $flushtime = $flushtime - 5;//因为数据库延迟，处理5秒前的数据
        $row = $this->getPreTime($delivery_time);//上次刷新时间
        $pretime = 0;
        if ($row != 0) {
            $pretime = $row ["flush_timepoint"];
            if ($row ["busy_start"] > 0) {
                if ($flushtime - $row ["busy_start"] < 600000) {
                    return "其他线程正在运行！";//其他线程正在运行
                } else {
                    return "十分钟都没运行完成，请联系管理员处理！";
                }
            } else {
                $flushinterval = SystemSetService::getSystemKey("flushinter");
                if ($flushtime - $pretime < $flushinterval) {
                    return "刷新间隔时间太短，请等待！";
                }
            }
            $this->updateBusyTime($delivery_time, $flushtime);//开始忙了，打上时间点
        }
        if ($pretime == 0) {//如果发现当前日期刚开始，需要预制数据
            $this->flushInit($delivery_time);
        }
        $timepoint = $this->getTimelineFlushPoint($delivery_time);//取当前待处理最小的时间点
        if ($timepoint == 0) {//如果当天已经处理完毕，则不用处理，直接退出
            $this->updateBusyTime($delivery_time, 0);//忙时间关闭
            return;
        }
        if ($flushtime > $timepoint) {//因为时间点已经过了，发现是历史数据
            $flushtime = $timepoint;//把timeline待处理时间点设置为待处理点
            $this->flushAllCis($delivery_time, $flushtime);//处理上次点和本次点间的数据
            $this->flushClass($delivery_time, $flushtime);//往timeline——sorting表格中导入数据
            $this->updateTimeLine($delivery_time, $flushtime);//在timeline表格中的isflush置为1
        } else {// 如果时刻点还没到，只要刷新CI即可
            $this->flushAllCis($delivery_time, $flushtime);//处理上次点和本次点间的数据
        }
        $this->updateFlushTime($delivery_time, $flushtime);//维护已经处理的时间点
        return date("y-m-d H:i:s", $flushtime);
    }

    public function updateFlushTime($delivery_time, $flushtime)
    {
        $cccommand = Yii::app()->cc->createCommand("
               update t_cc_moniter_flush set flush_timepoint=$flushtime, busy_start=0
               where  delivery_time =$delivery_time ");
        $cccommand->execute();
    }

    public function updateBusyTime($delivery_time, $nowtime)
    {
        $cccommand = Yii::app()->cc->createCommand("
               update t_cc_moniter_flush set busy_start=$nowtime
               where  delivery_time =$delivery_time ");
        $cccommand->execute();
    }

    public function updateTimeLine($delivery_time, $timepoint)
    {
        $cccommand = Yii::app()->cc->createCommand("
               update t_cc_moniter_timepoint set isflush=1
               where  delivery_time =$delivery_time
               and timepoint=$timepoint");
        $cccommand->execute();
    }

    public function getPreTime($delivery_time)
    {
        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = " SELECT *
                 FROM
                    t_cc_moniter_flush t
                 WHERE
                    t.delivery_time =" . $delivery_time . "
                 ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        if (count($rows) == 0) {
            return 0;
        } else {
            return $rows[0];
        }
    }

    public function flushInit($delivery_time)
    {
        $startTime = $delivery_time - 3600 * 14;
        $endTime = $delivery_time + 3600 * 10;
        $insertcommand = Yii::app()->cc->createCommand();
        $insertcommand->insert('t_cc_moniter_flush', array(
            'delivery_time' => $delivery_time,
            'flush_timepoint' => $startTime,
        ));
        $timepoints = CCPubService::getTimeLineArray($startTime, $endTime, 1800);
        //var_dump($timepoints);
        foreach ($timepoints as $timepoint) {
            $insertcommand->insert('t_cc_moniter_timepoint', array(
                'delivery_time' => $delivery_time,
                'timepoint' => $timepoint,
                'isflush' => 0,
            ));
        }
        return true;
    }

    //全量更新
    public function flushAllCis($delivery_time, $workend)
    {
        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $oiRows = $this->getAllOrderItems($delivery_time, $workend);//从t_order_items表中获取这一段时间的数据
        $insertRow = $oiRows;
        $sql = "select     lu_commodity_item_id ciid,
                            city_id city,
                            tst.operate_area warehouse,
                            sum(real_weight) real_weight,
                            sum(1) real_num
                        FROM
                            t_sorting_task tst
                        WHERE delivery_time = $delivery_time
                        and u_t<=$workend
                        and tst.status=1
                        GROUP BY tst.city_id,tst.operate_area,tst.lu_commodity_item_id";
        $command = $connection->createCommand($sql);
        $sotingrows = $command->queryAll();//从t_sorting_task中获取这一段时间的数据
        $exitsarray = array();
        foreach ($sotingrows as $index => $row) {
            $exitsarray[intval($row["city"]) . '-' . intval($row["warehouse"]) . '-' . intval($row["ciid"])] = $row;
        }//在tst中已经存在的数据

        $newRows = array();
        foreach ($insertRow as $index => $row) {
            $key = intval($row["city"]) . '-' . intval($row["warehouse"]) . '-' . intval($row["ciid"]);
            if (isset($exitsarray[$key])) {
                $row["real_weight"] = $exitsarray[$key]["real_weight"];
                $row["real_num"] = $exitsarray[$key]["real_num"];//是否存在
            } else {
                $row["real_weight"] = 0;
                $row["real_num"] = 0;
            }
            $newRows[] = $row;
        }

        $connection = Yii::app()->cc;   // 已经建立了一个 "cc" 连接
        //先清空
        $sql = "DELETE FROM
                    `t_cc_moniter_sorting_ci`
                    WHERE delivery_time= $delivery_time
            ";
        $command = $connection->createCommand($sql);
        $command->execute();

        if (count($newRows) > 0) {//批量插入
           // $newRows = $this->buildOIData($newRows);
           $newRows = CCPubService::buildOIDataNewDb($newRows);
            for ($index = 0; $index < count($newRows); $index += 1000) {
                $subarray = array_slice($newRows, $index, 1000);
                $cccommand = Yii::app()->cc->createCommand($this->insertbatch("t_cc_moniter_sorting_ci", $subarray));
                $cccommand->execute();
                $cccommand->getPdoStatement()->closeCursor();
            }
        }
    }

    //增量更新
    public function flushCis($delivery_time, $workstart, $workend)
    {
        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $workendRight = $workend - 1;//不要包含右边界
        //取分拣单的订单数量  //getOrderItems($delivery_time, $workstart, $workendRight);
        $oiRows = $this->getOrderItems($delivery_time, $workstart, $workendRight);

        $insertRow = array();
        $oiupdateRows = array();
        //如果不存在就插入  存在则累加
        $sql = "select  city,ciid,warehouse,expect_weight,expect_num  from t_cc_moniter_sorting_ci where delivery_time= $delivery_time";
        $findoneCommand = Yii::app()->cc->createCommand($sql);
        $checkrows = $findoneCommand->queryAll();
        $exitsarray = array();
        foreach ($checkrows as $index => $row) {
            $exitsarray[intval($row["city"]) . '-' . intval($row["warehouse"]) . '-' . intval($row["ciid"])] = $row;
        }
        foreach ($oiRows as $index => $row) {
            $key = intval($row["city"]) . '-' . intval($row["warehouse"]) . '-' . intval($row["ciid"]);
            if (!isset($exitsarray[$key])) {
                $insertRow[] = $row;
            } else {
                $key = intval($row["city"]) . '-' . intval($row["warehouse"]) . '-' . intval($row["ciid"]);
                //  var_dump($key);
                $row["expect_weight"] = $row["expect_weight"] + $exitsarray[$key]["expect_weight"];
                $row["expect_num"] = $row["expect_num"] + $exitsarray[$key]["expect_num"];
                $oiupdateRows[] = $row;
            }
        }
        if (count($insertRow) > 0) {
            //$insertRow = $this->buildOIData($insertRow);
        	$newRows = CCPubService::buildOIDataNewDb($insertRow);
            // var_dump($insertRow);
            $cccommand = Yii::app()->cc->createCommand($this->insertbatch("t_cc_moniter_sorting_ci", $insertRow));
            $cccommand->execute();
            $cccommand->getPdoStatement()->closeCursor();
        }
        if (count($oiupdateRows) > 0) {
            //性能优化（1.分隔数组100为批量单位 2.在数据库中的t_cc_moniter_sorting_ci表中建立city，warehouse,ccid三个字段的复合b_tree索引）
            $oiupdateRowsNew = array();
            $oiupdateRowPiece = array();
            $num = 0;
            foreach ($oiupdateRows as $item) {
                $num++;
                $oiupdateRowPiece[] = $item;
                if ($num % 100 == 0) {
                    $oiupdateRowsNew[] = $oiupdateRowPiece;
                    unset($oiupdateRowPiece);
                }
            }
            if (!empty($oiupdateRowPiece)) {//最后的单数为一组
                $oiupdateRowsNew[] = $oiupdateRowPiece;
            }
            foreach ($oiupdateRowsNew as $oirow) {
                $sql = $this->updatebatch("t_cc_moniter_sorting_ci", $oirow, $delivery_time);
                $cccommand = Yii::app()->cc->createCommand($sql);
                $result = $cccommand->execute();
                $cccommand->getPdoStatement()->closeCursor();
            }
        }
        $findoneCommand->getPdoStatement()->closeCursor();
        //--------------------数据准备完毕------------------------------
        $sql = "select city,ciid,warehouse,real_weight,real_num  from t_cc_moniter_sorting_ci where delivery_time= $delivery_time";
        $findall = Yii::app()->cc->createCommand($sql);
        $checkrows = $findall->queryAll();
        $exitsarray = array();
        foreach ($checkrows as $index => $row) {
            $exitsarray[intval($row["city"]) . '-' . intval($row["warehouse"]) . '-' . intval($row["ciid"])] = $row;
        }
        $sql = "select     lu_commodity_item_id ciid,
                            city_id city,
                            tst.operate_area warehouse,
                            sum(real_weight) real_weight,
                            sum(1) real_num
                        FROM
                            t_sorting_task tst
                        WHERE delivery_time = $delivery_time
                        and  tst.u_t BETWEEN $workstart AND $workendRight
                        and tst.status=1
                        GROUP BY tst.city_id,tst.operate_area,tst.lu_commodity_item_id";
        $command = $connection->createCommand($sql);
        $sotingrows = $command->queryAll();
        $updateRow = array();
        foreach ($sotingrows as $index => $row) {
            $key = intval($row["city"]) . '-' . intval($row["warehouse"]) . '-' . intval($row["ciid"]);
            $row["real_weight"] = $row["real_weight"] + $exitsarray[$key]["real_weight"];
            $row["real_num"] = $row["real_num"] + $exitsarray[$key]["real_num"];
            $updateRow[] = $row;
        }
        if (count($updateRow) > 0) {
            $cccommand = Yii::app()->cc->createCommand($this->updatebatch("t_cc_moniter_sorting_ci", $updateRow, $delivery_time));
            $cccommand->execute();
            $cccommand->getPdoStatement()->closeCursor();
        }
    }

    public function flushClass($delivery_time, $timepoint)//分类计算总和，往sorting_timeline中导入数据
    {
        $connection = Yii::app()->cc;   // 已经建立了一个 "cc" 连接
        //先清空
        $sql = "DELETE FROM
                    `t_cc_moniter_sorting_timeline`
                    WHERE
                    timepoint = $timepoint
                    AND
                    delivery_time= $delivery_time
            ";
        $command = $connection->createCommand($sql);
        $command->execute();
        $sql = "INSERT INTO
                  `t_cc_moniter_sorting_timeline`
                  (`city`,`warehouse`,`class1`,`class2`,`delivery_time`,
                  `expect_weight`,`expect_num`,`real_weight`,`real_num`,`timepoint`,
                  `rate_weight`,`rate_num`,`datatype`)
                SELECT
                    city,
                    warehouse,
                    class1,
                    class2,
                    delivery_time,
                    sum(expect_weight) as expect_weight,
                    sum(expect_num) as expect_num,
                    sum(real_weight) as real_weight,
                    sum(real_num) as real_num,
                    $timepoint,
                    truncate( sum(expect_weight)/sum(real_weight),2) as rate_weight,
                    truncate( sum(expect_num)/sum(real_num),2) as rate_num,
                    4
                 from t_cc_moniter_sorting_ci t where  delivery_time=$delivery_time
                 GROUP  by city,warehouse,class1,class2
        ";
        $command = $connection->createCommand($sql);
        $command->execute();
        return true;
    }

    public function flushWarehouse($delivery_time)
    {
        return true;
    }

    public function getTimelineFlushPoint($delivery_time)
    {
        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT min(timepoint) timepoint
                 FROM
                    t_cc_moniter_timepoint t
                 WHERE isflush=0
                    and t.delivery_time =" . $delivery_time . "
                 ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        if (count($rows) > 0) {
            $newtimepoint = $rows[0]["timepoint"];
            return $newtimepoint;
        } else {
            return 0;
        }
    }

    public function insertbatch($tablename, $rows)
    {
        $names = array();
        foreach ($rows[0] as $key => $value) {
            $names[] = $key;
        }
        $sql = "insert into $tablename (" . implode(', ', $names) . ") values";
        $sql = substr($sql, 0, strlen($sql) - 1);
        foreach ($rows as $index => $row) {
            $newvalue = array();
            foreach ($row as $key => $value) {
                $newvalue[] = $value;
            }
            if ($index > 0) {
                $sql .= ',';
            }
            $sql .= "('" . implode("', '", $newvalue) . "')";
        }
        return $sql;
    }

    public function updatebatch($tablename, $updaterows, $delivery_time)
    {
        $names = array();
        foreach ($updaterows[0] as $key => $value) {
            $names[] = $key;
        }
        $batchsql = "";
        foreach ($updaterows as $index => $row) {
            $sql = "update  $tablename set   ";
            if (isset($row["expect_weight"])) {
                $sql .= "  expect_weight =" . $row["expect_weight"] . " , ";
                $sql .= "  expect_num =" . $row["expect_num"];
            } else {
                $sql .= "  real_weight =" . $row["real_weight"] . " , ";
                $sql .= "  real_num =" . $row["real_num"];
            }
            $sql .= "  where city=" . $row["city"] . " and  warehouse=" . $row["warehouse"] . " and ciid=" . $row["ciid"] . " and delivery_time=" . $delivery_time;
            if (strlen($batchsql) > 0) {
                $batchsql .= ";";
            }
            $batchsql .= $sql;
        }
        return $batchsql;
    }

    public function  datadisplay($deliveryTime)
    {
        $sql = "
          SELECT
          isflush,
          FROM_UNIXTIME(timepoint, '%Y-%m-%d %H:%i:%s') timepoint,
          FROM_UNIXTIME(delivery_time, '%Y-%m-%d %H:%i:%s') delivery_time
         FROM t_cc_moniter_timepoint
          where   delivery_time=$deliveryTime order by isflush ,timepoint ";
        return Yii::app()->cc->createCommand($sql)->queryAll();
    }

    public function  reset($deliverTime)
    {
        $cccommand = Yii::app()->cc->createCommand("delete from t_cc_moniter_flush  WHERE delivery_time=$deliverTime");
        $cccommand->execute();
        $cccommand = Yii::app()->cc->createCommand("delete from t_cc_moniter_sorting_ci WHERE delivery_time=$deliverTime");
        $cccommand->execute();
        $cccommand = Yii::app()->cc->createCommand("delete from t_cc_moniter_sorting_timeline WHERE delivery_time=$deliverTime");
        $cccommand->execute();
        $cccommand = Yii::app()->cc->createCommand("delete from t_cc_moniter_timepoint WHERE delivery_time=$deliverTime");
        $cccommand->execute();
    }

    public function  getSortingOrderItems($delivery_time, $workstart, $workendRight)
    {
        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $sql = "select     lu_commodity_item_id ciid,
                            city_id city,
                            tst.operate_area warehouse,
                            tst.class2_id class2,
                            sum(expect_weight ) expect_weight,
                            sum(1) expect_num
                        FROM
                            t_sorting_task tst
                        WHERE delivery_time = $delivery_time
                        and  tst.c_t BETWEEN $workstart AND $workendRight
                        and tst.status=1
                        GROUP BY tst.city_id,tst.operate_area,tst.lu_commodity_item_id ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        $newRows = array();
        foreach ($rows as $index => $row) {
            $row["delivery_time"] = $delivery_time;
            $newRows[] = $row;
        }

        return $newRows;
    }

    public function  getAllOrderItems($delivery_time, $workendRight)
    {
        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT     lu_commodity_item_id ciid,
                            city_id city,
                            tst.operate_area warehouse,
                            tst.class2_id class2,
                            sum(expect_num * ci_weight) expect_weight,
                            sum(1) expect_num
                        FROM
                            t_order_item tst
                        WHERE delivery_time = $delivery_time
                          AND tst.u_t <=  $workendRight
                              and tst.status=3
                        GROUP BY city ,tst.operate_area, ciid";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        $newRows = array();
        foreach ($rows as $index => $row) {
            $row["delivery_time"] = $delivery_time;
            $newRows[] = $row;
        }
        return $newRows;
    }

    public function  getOrderItems($delivery_time, $workstart, $workendRight)
    {
        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT     lu_commodity_item_id ciid,
                            city_id city,
                            tst.operate_area warehouse,
                            tst.class2_id class2,
                            sum(expect_num * ci_weight) expect_weight,
                            sum(1) expect_num
                        FROM
                            t_order_item tst
                        WHERE delivery_time = $delivery_time
                              AND tst.u_t BETWEEN $workstart AND  $workendRight
                              and tst.status=3
                        GROUP BY city ,tst.operate_area, ciid";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        $newRows = array();
        foreach ($rows as $index => $row) {
            $row["delivery_time"] = $delivery_time;
            $newRows[] = $row;
        }
        return $newRows;
    }

//lu_commodity_item_id ciid,
//lsi.id siid,
//city_id city,
//tst.operate_area warehouse,
//class1_id class1,
//tst.class2_id class2,
//$delivery_time delivery_time,
// expect_weight,
// expect_num

    public function  buildOIData($rows)
    {
        $class1s = "";
        $class2s = "";
        $ciids = "";
        $siids = "";
        foreach ($rows as $index => $row) {
            if ($index > 0) {
                $ciids .= ",";
                $class2s .= ",";
            }
            $ciids .= $row["ciid"];//rows中的ciid数据项拼接成ciids
            $class2s .= $row["class2"];//rows中的class2_id数据项拼接成class2s
        }
        $cissql = "
          SELECT id ciid,  lu_standard_item_id siid, standard_item_num from
          lu_commodity_item lsi where  lsi.id  in ($ciids)";//选出lsi中的相关id，name，idname都是此表中的字段名称
        $ciRows = Yii::app()->db->createCommand($cissql)->queryAll();

        $haveArray = array();
        foreach ($ciRows as $index => $row) {
            if (!isset($haveArray[$row["siid"]])) {
                if ($index > 0) {
                    $siids .= ",";
                }
                $siids .= $row["siid"];
                $haveArray[$row["siid"]] = 0;
            }

        }
        $cimaps = UtilService::rowsToMap($ciRows, "ciid", "siid");//使 lsi的  id，与name一一对应
        $cimaps_sin = UtilService::rowsToMap($ciRows, "ciid", "standard_item_num");//使 lsi的  id，与name一一对应
        $sissql = "
          SELECT id siid ,name,lu_basic_item_id biid, level, format from
          lu_standard_item lsi where  lsi.id  in ($siids)";//选出lsi中的相关id，name，idname都是此表中的字段名称
        $siRows = Yii::app()->db->createCommand($sissql)->queryAll();
        $siBiMap = UtilService::rowsToMap($siRows, "siid", "biid");//使 lsi的  id，与name一一对应
        $siBiMap_level = UtilService::rowsToMap($siRows, "siid", "level");//使 lsi的  id，与name一一对应
        $siBiMap_format = UtilService::rowsToMap($siRows, "siid", "format");//使 lsi的  id，与name一一对应
        
        $biids = "";
        $haveArray = array();
        foreach ($siRows as $index => $row) {
            if (!isset($haveArray[$row["biid"]])) {
                if ($index > 0) {
                    $biids .= ",";
                }
                $biids .= $row["biid"];
                $haveArray[$row["biid"]] = 0;
            }
        }

        $bissql = "
          SELECT id biid ,name from
          lu_basic_item t where  t.id  in ($biids)";//选出lsi中的相关id，name，idname都是此表中的字段名称
        $biRows = Yii::app()->db->createCommand($bissql)->queryAll();
        $BiNameMap = UtilService::rowsToMap($biRows, "biid", "name");//使 lsi的  id，与name一一对应

        $class2sql = "
          SELECT id class2_id,name,class1_id from
          class2  where  class2.id  in ($class2s)";

        $class2NameRows = Yii::app()->db->createCommand($class2sql)->queryAll();
        $class2NameMap = UtilService::rowsToMap($class2NameRows, "class2_id", "name");
        $haveArray = array();
        foreach ($class2NameRows as $index => $row) {
            if (!isset($haveArray[$row["class1_id"]])) {
                if ($index > 0) {
                    $class1s .= ",";
                }
                $class1s .= $row["class1_id"];  //在$class2NameRows中取出相关的class1_id，拼接成$class1s
                $haveArray[$row["class1_id"]] = 0;
            }
        }
        $class1sql = "
          SELECT id class1_id,name from
          class1  where  class1.id  in ($class1s)";
        $class1NameRows = Yii::app()->db->createCommand($class1sql)->queryAll();
        $class1NameMap = UtilService::rowsToMap($class1NameRows, "class1_id", "name");
        $class1IdMap = UtilService::rowsToMap($class2NameRows, "class2_id", "class1_id");
        $newRows = array();
        $iii = 0;
        foreach ($rows as $index => $row) {
        	$ciid =  $row["ciid"];
            $row["siid"] = $cimaps[$ciid]; //根据id取出的name作为rows数组中的itemname字段
            $temp_biid = $siBiMap[$row["siid"]];
            $row["item_name"] = $BiNameMap[$temp_biid].'-'.$cimaps_sin[$ciid].'-'.$siBiMap_format[$row["siid"]].'-'.$siBiMap_level[$row["siid"]]; //根据id取出的name作为rows数组中的itemname字段
            $row["class2_name"] = isset($class2NameMap[$row["class2"]])?$class2NameMap[$row["class2"]]:'';
            $row["class1"] = isset($class1IdMap[$row["class2"]])?$class1IdMap[$row["class2"]]:-1;
            $row["class1_name"] = isset($class1NameMap[$row["class1"]])?$class1NameMap[$row["class1"]]:'未定义';
            
            $newRows[] = $row;
        }
//        var_dump("-----");
//        var_dump($newRows);
        return $newRows;
    }


}

