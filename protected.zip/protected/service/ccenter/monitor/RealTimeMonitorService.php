<?php
/**
 * 实时监控服务
 * Created by PhpStorm.
 * User: wangzejie
 * Date: 15/3/27
 * Time: 下午2:09
 */

class RealTimeMonitorService {

    /**
     * 分拣统计
     * @params $distributeDate 配送日期
     * @params $cityId
     * @return array
     */
    public static function statSeparationByCity($distributeDate, $cityId){
        $startTime = strtotime($distributeDate);
        $endTime = strtotime($distributeDate." 23:59:59");
        $sql = <<<SQL
          select
            oi.car_group car_group_id,
            cg.name car_name,
            ca.name area_name,
            ca.operate_area,
            count(if(c2.class1_id=1,0,null)) vegetable_count,
            count(if(c2.class1_id=1 and oi.real_num is not null,0,null)) separated_vegetable_count,
            count(if(c2.class1_id!=1,0,null)) other_count,
            count(if(c2.class1_id!=1 and oi.real_num is not null,0,null)) separated_other_count
          from order_item oi
          join car_group cg on oi.car_group=cg.id
          join company_area ca on cg.area_id=ca.id
          join lu_commodity_item ci on oi.lu_commodity_item_id=ci.id
          join lu_standard_item si on ci.lu_standard_item_id=si.id
          join lu_basic_item bi on si.lu_basic_item_id=bi.id
          join class2 c2 on bi.class2_id=c2.id
          where oi.status>=3 and oi.delivery_time between $startTime and  $endTime  and oi.city_id= $cityId
          group by oi.car_group
          order by ca.operate_area, ca.id, oi.car_group

SQL;
        //var_dump($sql);
        return Yii::app()->db->createCommand($sql)->queryAll();
    }

    /**
     * 车配送状态统计
     * @param $distributeDate
     * @param $cityId
     * @return mixed
     */
    public static function statCarDistributeStateByCity($distributeDate, $cityId){
        $distributeTime = strtotime($distributeDate);
        $sql = <<<SQL
            select
              cg.name car_name,
              c.name poi_name,
              do.seq,
              f.pay_status,
              f.id,
              max(if(oi.cs_handle_type is null, -1, oi.cs_handle_type)) oi_status
            from order_item oi
            join car_group cg on oi.car_group = cg.id
            join distribute_order do on oi.distribute_order_id=do.id
            join f_receipt_order f on oi.f_receipt_order_id=f.id
            join company c on oi.company_id=c.id
            where oi.delivery_time = $distributeTime and oi.status>=3 and oi.city_id=$cityId
            group by cg.id,c.id,f.id
            order by cg.area_id,cg.id,do.seq

SQL;
        return Yii::app()->commodity_db->createCommand($sql)->queryAll();
    }


}