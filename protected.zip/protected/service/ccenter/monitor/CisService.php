<?php

/**
 * Created by PhpStorm.
 * User: guanzhongyang
 * Date: 2015/8/27
 * Time: 13:47
 */
class CisService
{

    /**
     * 生产分拣
     * @params $distributeDate 配送日期
     * @params $cityId
     * @return array
     */
    public static function CisSearch($para,$user_info)
    {

        $item_name=$para["item_name"];
        $sql = "

          SELECT
          ciid,
          siid,
          class1,
          class2_name,
          item_name,
          expect_weight,
          expect_num,
          real_weight,
          real_num,
          city,
          warehouse,
           truncate(100*t.real_num/t.expect_num,2) rate,
          FROM_UNIXTIME(delivery_time, '%Y%m%d') delivery_time
         FROM t_cc_moniter_sorting_ci t
         WHERE  delivery_time =" . $para["delivery_time"];
        if ($para["item_name"] != "") {
            $sql .= " AND item_name = " ."'". $para["item_name"] . "'";
        }
        if ($para["city"] != "") {
            $sql .= " AND city = " . $para["city"] . " ";
        }else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }
        if ($para["class1"] != "") {
            $sql .= " AND class1 = " . $para["class1"] . " ";
        }
        if ($para["class2"] != "") {
            $sql .= " AND class2 = " . $para["class2"] . " ";
        }
        $sql .= " ORDER BY rate ";
        return Yii::app()->cc->createCommand($sql)->queryAll();

    }
    public static function getPage($para,$startNum,$user_info){
        $item_name=$para["item_name"];
        $sql = "

          SELECT
          ciid,
          siid,
          class1,
          class2_name,
          item_name,
          expect_weight,
          expect_num,
          real_weight,
          real_num,
          city,
          warehouse,
           truncate(100*t.real_num/t.expect_num,2) rate,
          FROM_UNIXTIME(delivery_time, '%Y%m%d') delivery_time
         FROM t_cc_moniter_sorting_ci t
         WHERE item_name LIKE '%$item_name%' AND delivery_time =" . $para["delivery_time"];
        if ($para["city"] != "") {
            $sql .= " AND city = " . $para["city"] . " ";
        }else {
            $sql = $sql . " and city in(" . $user_info["own_city"] . ")";
        }
        if ($para["warehouse"] != "") {
            $sql .= " AND warehouse = " . $para["warehouse"] . " ";
        }
        if ($para["class1"] != "") {
            $sql .= " AND class1 = " . $para["class1"] . " ";
        }
        if ($para["class2"] != "") {
            $sql .= " AND class2 = " . $para["class2"] . " ";
        }
        $sql .= " ORDER BY rate ";
        return Yii::app()->cc->createCommand($sql." limit ". $startNum .",". 20 )->queryAll();
    }



}