<?php

/**
 * Created by PhpStorm.
 * User: wangbiwen
 * Date: 2015/8/27
 * Time: 15:52
 */
class CCPubService
{
    # 获取城市列表
    public static function getCityList($user_info)
    {
        $own_citys = explode(",", $user_info["own_city"]);
        $city_list = array();
        $header = array('Content-Type:application/json');
        $result = HttpClient::post(MEICAI_GIS . "/gis/city/all", json_encode(array()), true, $header);
        if ($result['ret'] == 1) {
            $citys = $result['data'];
            foreach ($citys as $key => $value) {
                if ($value['status'] && in_array($value["id"], $own_citys)) {
                    $city_list[$value["id"]] = $value['name'];
                }
            }
        }
        return $city_list;
    }

    public static function getALLCityList()
    {
        //$own_citys = explode(",", $user_info["own_city"]);
        $city_list = array();
        $header = array('Content-Type:application/json');
        $result = HttpClient::post(MEICAI_GIS . "/gis/city/all", json_encode(array()), true, $header);
        if ($result['ret'] == 1) {
            $citys = $result['data'];
            foreach ($citys as $key => $value) {
                if ($value['status']) {
                    $city_list[$value["id"]] = $value['name'];
                }
            }
        }
        return $city_list;
    }

    public static function getFirstCity($user_info)
    {
        $own_citys = explode(",", $user_info["city_id"]);
        $city_list = array();
        $header = array('Content-Type:application/json');
        $result = HttpClient::post(MEICAI_GIS . "/gis/city/all", json_encode(array()), true, $header);
        if ($result['ret'] == 1) {
            $citys = $result['data'];
            foreach ($citys as $key => $value) {
                if ($value['status'] && in_array($value["id"], $own_citys)) {
                    $city_list[$value["id"]] = $value['name'];
                }
            }
        }
        return $city_list;
    }

    public static function getWarehouseList($user_info)
    {
        $city_list = CCPubService::getCityList($user_info);
        $cityWarehouse = array();
        $header = array('Content-Type:application/json');
        $result = HttpClient::post(MEICAI_GIS . "/gis/warehouse/all?api_key=test", json_encode(array()), true, $header);
        if ($result['ret'] == 1) {
            $warehouses = $result['data'];
            foreach ($city_list as $ckey => $cvalue) {
                $warehouse = array();
                foreach ($warehouses as $wkey => $wvalue) {
                    if ($ckey == intval($wvalue["city_id"])) {
//                        foreach($warehouselist as $wkey_v2 => $wvalue_v2){
//                            if($wvalue_v2 == $wvalue["id"]){
                                $warehouseAtri = array();
                                $warehouseAtri["id"] = $wvalue["warehouse_id"];
                                $warehouseAtri["name"] = $wvalue["name"];
                                $warehouseAtri["status"] = $wvalue["status"];
                                $warehouse[$wvalue["warehouse_id"]] = $warehouseAtri;
 //                           }
 //                       }
                    }
                }
                $cityWarehouse[$ckey] = $warehouse;
            }
        }

        return $cityWarehouse;
    }

    public static function getClass1List()
    {

        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                    id,name
                FROM
                    class1 t
               ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();

        // do something
        return $rows;


    }
    public static function getClass1List_goods()
    {
    
    	$connection = Yii::app()->goods;   // 假设你已经建立了一个 "db" 连接
    	$sql = "SELECT
                    id,name
                FROM
                    t_goods_class where type=1 and parent_id=0
               ";
    	$command = $connection->createCommand($sql);
    	$rows = $command->queryAll();
    
    	// do something
    	return $rows;
    
    
    }

    public static function getClass1_List() //yzx_resolve the error about: array to string version
    {

        $class1_list = array();

        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                    *
                FROM
                    class1 t
               ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();

        foreach ($rows as $value) {
            $class1_list[] = $value;
        }

        return $class1_list;//


    }

    public static function getClass2List_goods()
    {
    	$class1_rows = CCPubService::getClass1List_goods();
    	$class1_ids="";
    	foreach ($class1_rows as $index=>$value){
    		if($index >0){
    			$class1_ids.=',';
    		}
    		$class1_ids.=$value['id'];
    	}
    	
    	$connection = Yii::app()->goods;   // 假设你已经建立了一个 "db" 连接
    	$sql = "SELECT
                   id,name,parent_id class1_id
                FROM
                    t_goods_class where parent_id in ($class1_ids) and type=1
               ";
    	$command = $connection->createCommand($sql);
    	$rows = $command->queryAll();
    	return $rows;
    }
    
    public static function getClass2List()
    {
        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                   id,name,class1_id
                FROM
                    class2 t
               ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();

//        $class1=CCPubService::getClass1List();
//        $class2str=array();
//        foreach ($class1 as $key => $value) {
//            $class2=array();
//            foreach ($rows as $ckey => $cvalue) {
//                if ($value['id']==$cvalue["class1_id"]) {
//                    $class2[]=$cvalue;
//                }
//            }
//            $class2str[$key."c"]=$class2;
//        }
        // do something
        return $rows;
    }

    public static function getClass2ListByClass1id_goods($class1Id)
    {
    	$connection = Yii::app()->goods;   // 假设你已经建立了一个 "db" 连接
    	$sql = "SELECT
    	id,name,parent_id class1_id
    	FROM
    	t_goods_class t
    	where   parent_id=$class1Id and type=1
    	";
    	$command = $connection->createCommand($sql);
    	$rows = $command->queryAll();
    
    	return $rows;
    }

    //function
    //#yzc_getclass2list_by_class1id

    public static function getClass2ListByClass1id($class1Id)
    {
        $connection = Yii::app()->db;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                   id,name,class1_id
                FROM
                    class2 t
                where   t.class1_id=$class1Id
               ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();

        return $rows;
    }


    # 获取用品分类列表
    public static function getClassList()
    {
        $good_list = array();
        $res = require_once dirname(__FILE__) . '/../../lib/static/Sort.php';
        foreach ($res as $key => $value) {
            if ($value['status']) {
                $good_list[$key] = $value['name'];
            }
        }
        return $good_list;
    }

    // ""
    public static function getTimeLineArray($startTimeInt, $endTimeInt, $inter)
    {
        $mytimeline = array();
        FOR ($currentTime = $startTimeInt; $currentTime <= $endTimeInt; $currentTime = $currentTime + $inter) {
            $mytimeline[] = $currentTime;
        }
        return $mytimeline;
    }

    public static function getDefaultDistributeDate()
    {
        $now = date('H', time());
        $distribute_t = "";
        if ($now < 10) {
            $distribute_t = date('y-m-d', time());
        } else {
            $distribute_t = date("Y-m-d", strtotime("+1 day"));
        }
        return $distribute_t;
    }

    // ""
    public static function getTimeLine($startTimeInt)
    {
        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                    t.timepoint
                FROM
                     t_cc_moniter_timepoint t
                WHERE
                    t.delivery_time =" . $startTimeInt . "";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        $mytimeline = array();
        foreach ($rows as $key => $value) {
            $mytimeline[] = $value["timepoint"];
        }
        return $mytimeline;
    }

    public static function getDbTime()
    {
        return time();
    }

    // ""
    public static function getDataTimeLine($startTimeInt)
    {

        $connection = Yii::app()->cc;   // 假设你已经建立了一个 "db" 连接
        $sql = "SELECT
                    t.timepoint
                FROM
                     t_cc_moniter_timepoint t
                WHERE
                    t.delivery_time =" . $startTimeInt . " and t.isflush=1 ";
        $command = $connection->createCommand($sql);
        $rows = $command->queryAll();
        $mytimeline = array();
        foreach ($rows as $key => $value) {
            $mytimeline[] = $value["timepoint"];
        }
        return $mytimeline;
    }

    public static function getRecentDate($delivery_time)
    {
        $recent =array();
       // $now =  $delivery_time;
        $now =  date("Y-m-d", strtotime("-1 day",strtotime($delivery_time)));
        $recent[0]=$now;
        for($num=1;$num<7;$num++){
            $before=$recent[$num-1];
            $recent[$num]=date("Y-m-d", strtotime("-1 day",strtotime($before)));
        }
        return $recent;
    }


    public static function getTimeLineX($startTimeInt)
    {
        $x = array();
        $timelineArray = CCPubService::getTimeLine($startTimeInt);
        foreach ($timelineArray as $key) {
            $x[] = date("H:i", $key);
        }
        return $x;
    }

    public static function getPara()
    {
        $para = array();
        $distribute_t = CCPubService::getDefaultDistributeDate();

        if (isset($_GET["distribute_t"]))//是否存在"id"的参数
        {
            $distribute_t = $_GET["distribute_t"];//存在
        }
        $page=1;
        if (isset($_GET["page"])){
            $page=$_GET["page"];
        }


        $ciid="";
        if (isset($_GET["ciid"])){
            $ciid=$_GET["ciid"];
        }
        $timepoint="";
        if (isset($_GET["timepoint"])){
            $timepoint=$_GET["timepoint"];
        }
        $city = "";
        if (isset($_GET["city"]))//是否存在"id"的参数
        {
            $city = $_GET["city"];//存在
        }
        $warehouse = "";
        if (isset($_GET["warehouse"]))//是否存在"id"的参数
        {
            $warehouse = $_GET["warehouse"];//存在
        }
        $class1 = "";
        if (isset($_GET["class1"]))//是否存在"id"的参数
        {
            $class1 = $_GET["class1"];//存在
        }

        $class2 = "";
        if (isset($_GET["class2"]))//是否存在"id"的参数
        {
            $class2 = $_GET["class2"];//存在
        }
        $item_name = "";
        if (isset($_GET["item_name"]))//是否存在"id"的参数
        {
            $item_name = $_GET["item_name"];//存在
        }
        $delivery_time = strtotime($distribute_t);

        if (isset($_GET["delivery_time"]))//是否存在"id"的参数
        {
            $delivery_time = $_GET["delivery_time"];//存在

        }
        $para["delivery_time"] = $delivery_time;
        $para["distribute_t"] = $distribute_t;
        $para["city"] = $city;
        $para["warehouse"] = $warehouse;
        $para["class1"] = $class1;
        $para["class2"] = $class2;
        $para["item_name"] = $item_name;
        $para["timepoint"] = $timepoint;
        $para["ciid"] = $ciid;
        $para["page"] = $page;

        //var_dump($para);
        return $para;
    }
    
    public static function buildOIDataNewDb($rows){
    	$goods_db = Yii::app ()->goods;
    	$class1s = "";
    	$class2s = "";
    	$ciids = "";
    	$siids = "";
    	
    	foreach ($rows as $index => $row) {
    		if ($index > 0) {
    			$ciids .= ",";
    			//$class2s .= ",";
    		}
    		$ciids .= $row["ciid"];//rows中的ciid数据项拼接成ciids
    		//$class2s .= $row["class2"];//rows中的class2_id数据项拼接成class2s
    	}
    	
    	$cisql = "select f_ci ciid, f_si siid, si_num standard_item_num from t_goods_ci_si where f_ci in ($ciids)";
    	$ciRows = $goods_db->createCommand($cisql)->queryAll();
    	$cisql_format = "select id ciid, format from t_goods_ci where id in ($ciids)";
    	$ciRows_format = $goods_db->createCommand($cisql_format)->queryAll();
    	$ciMap_format = UtilService::rowsToMap($ciRows_format, "ciid", "format");//使 lsi的  id，与name一一对应
    	$cimaps = UtilService::rowsToMap($ciRows, "ciid", "siid");//使 lsi的  id，与name一一对应
    	$cimaps_sin = UtilService::rowsToMap($ciRows, "ciid", "standard_item_num");//使 lsi的  id，与name一一对应
    	
    	$haveArray = array();
    	foreach ($ciRows as $index => $row) {
    		if (!isset($haveArray[$row["siid"]])) {
    			if ($index > 0) {
    				$siids .= ",";
    			}
    			$siids .= $row["siid"];
    			$haveArray[$row["siid"]] = 0;
    		}
    	}
    	$sisql = "select id siid, name, f_bi biid, level from t_goods_si where id in ($siids)";
    	$siRows = $goods_db->createCommand($sisql)->queryAll();
    	$siBiMap = UtilService::rowsToMap($siRows, "siid", "biid");//使 lsi的  id，与name一一对应
    	$siBiMap_level = UtilService::rowsToMap($siRows, "siid", "level");//使 lsi的  id，与name一一对应
    
    	$biids = "";
    	$haveArray = array();
    	foreach ($siRows as $index => $row) {
    		if (!isset($haveArray[$row["biid"]])) {
    			if ($index > 0) {
    				$biids .= ",";
    			}
    			$biids .= $row["biid"];
    			$haveArray[$row["biid"]] = 0;
    		}
    	}
    
    	$bissql = "SELECT id biid, name from t_goods_bi where id  in ($biids)";//选出lsi中的相关id，name，idname都是此表中的字段名称
    	$biRows = $goods_db->createCommand($bissql)->queryAll();
    	$BiNameMap = UtilService::rowsToMap($biRows, "biid", "name");//使 lsi的  id，与name一一对应
    
    	$class2sql = "select parent_id class2_id, f_leaf biid from t_goods_class where f_leaf in ($biids) and type=1";
    	$classsIDRows = $goods_db->createCommand($class2sql)->queryAll();
    	$bi2class2Id = UtilService::rowsToMap($classsIDRows, "biid", "class2_id");
    	
    	$haveArray = array();
	    foreach ($classsIDRows as $index => $row) {
	    		if (!isset($haveArray[$row["class2_id"]])) {
	    			if ($index > 0) {
	    				$class2s .= ",";
	    			}
	    			$class2s .= $row["class2_id"];
	    			$haveArray[$row["class2_id"]] = 0;
	    		}
	    }
	    
    	$class2sql = "SELECT id class2_id,name,parent_id class1_id from t_goods_class  where type=1 and id  in ($class2s)";
    	$class2NameRows = $goods_db->createCommand($class2sql)->queryAll();
    	$class2NameMap = UtilService::rowsToMap($class2NameRows, "class2_id", "name");
    	
    	$haveArray = array();
    	foreach ($class2NameRows as $index => $row) {
    		if (!isset($haveArray[$row["class1_id"]])) {
    			if ($index > 0) {
    				$class1s .= ",";
    			}
    			$class1s .= $row["class1_id"];  //在$class2NameRows中取出相关的class1_id，拼接成$class1s
    			$haveArray[$row["class1_id"]] = 0;
    		}
    	}
    	
    	$class1sql = "SELECT id class1_id,name from t_goods_class where type=1 and id in ($class1s)";
    	$class1NameRows = $goods_db->createCommand($class1sql)->queryAll();
    	
    	$class1NameMap = UtilService::rowsToMap($class1NameRows, "class1_id", "name");
    	$class1IdMap = UtilService::rowsToMap($class2NameRows, "class2_id", "class1_id");
    	
    	$newRows = array();

    	foreach ($rows as $index => $row) {
    		$ciid =  $row["ciid"];
    		$row["siid"] = isset($cimaps[$ciid])?$cimaps[$ciid]:0; //根据id取出的name作为rows数组中的itemname字段
    		$temp_biid = isset($siBiMap[$row["siid"]])?$siBiMap[$row["siid"]]:0;
    		$temp_class2_id = isset($bi2class2Id[$temp_biid])?($bi2class2Id[$temp_biid]):0;
    		
    		$row["item_name"] = (isset($BiNameMap[$temp_biid])?$BiNameMap[$temp_biid]:0).'-'.(isset($cimaps_sin[$ciid])?$cimaps_sin[$ciid]:0).'-'.(isset($ciMap_format[$ciid])?$ciMap_format[$ciid]:0).'-'.(isset($siBiMap_level[$row["siid"]])?$siBiMap_level[$row["siid"]]:0); //根据id取出的name作为rows数组中的itemname字段
    		$row["class2_name"] = isset($class2NameMap[$temp_class2_id])?$class2NameMap[$temp_class2_id]:'';
    		$row["class1"] = isset($class1IdMap[$temp_class2_id])?$class1IdMap[$temp_class2_id]:-1;
    		$row["class1_name"] = isset($class1NameMap[$row["class1"]])?$class1NameMap[$row["class1"]]:'未定义';
    		$row["class2"] = $temp_class2_id;
    
    		$newRows[] = $row;
    	}
    	return $newRows;
    }
}