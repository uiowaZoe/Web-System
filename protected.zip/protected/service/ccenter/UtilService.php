<?php

/**
 * Created by PhpStorm.
 * User: wangbiwen
 * Date: 2015/9/17
 * Time: 12:37
 */
class UtilService
{
    public static function  rowsToMap($rows, $keycol, $valuecol)
    {
        $map = array();
        foreach ($rows as $index => $row) {
            $map[$row[$keycol]] = $row[$valuecol];
        }
        return $map;
    }
}