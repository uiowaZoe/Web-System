<?php
return array(
    // uncomment the following to use a MySQL database
       'db' => array(
        'class' => 'MDbConnection',
        'connectionString' => 'mysql:host=10.2.2.41;port=3307;dbname=Commodity',
        'emulatePrepare' => true,
        'username' => 'admin_test',
        'password' => 'qHAZsCCw',
        'charset' => 'utf8',
        'schemaCachingDuration' => 86400,
        'timeout' => 2,
        'slaves' => array(
            array(
                'connectionString' => 'mysql:host=10.2.2.41;port=3307;dbname=Commodity',
                'username' => 'admin_test',
                'password' => 'qHAZsCCw',
            ),
        ),
    ),
		'goods' => array(
				'class' => 'MDbConnection',
				'connectionString' => 'mysql:host=192.168.2.18;port=3306;dbname=goods',
				'emulatePrepare' => true,
				'username' => 'root',
				'password' => 'meicai@!#',
				'charset' => 'utf8',
				'schemaCachingDuration' => 86400,
				'timeout' => 2,
				'slaves' => array(
						array(
								'connectionString' => 'mysql:host=192.168.2.18;port=3306;dbname=goods',
								'username' => 'root',
								'password' => 'meicai@!#',
						),
				),
		),
    'cc' => array(
        'class' => 'MDbConnection',
        'connectionString' => 'mysql:host=192.168.2.18;port=3306;dbname=command_center',
        'emulatePrepare' => true,
        'username' => 'root',
        'password' => 'meicai@!#',
        'charset' => 'utf8',
        'schemaCachingDuration' => 86400,
        'timeout' => 2,
        'slaves' => array(
            array(
                'connectionString' => 'mysql:host=192.168.2.18;port=3306;dbname=command_center',
                'username' => 'root',
                'password' => 'meicai@!#',
            ),
        ),
    ),
);