<?php

define('MEICAI_AUTH_SERVER', 'http://192.168.1.160:9010');
define('USER_INFO_URL', MEICAI_AUTH_SERVER . '/user/tokeninfo');
define('USER_LOGOUT_URL', MEICAI_AUTH_SERVER . '/adminuser/logout');

define('MEICAI_SYSTEM_KEY', 'command_center');
define('MEICAI_AUTH_TIMEOUT', 10);

define('MEICAI_GIS', 'http://172.18.0.44:8080/');

// 这些配置根据环境修改
define('MEICAI_AUTH_SSO_DOMAIN', 'http://sso.dev.yunshanmeicai.com');
define('MEICAI_AUTH_TOKEN_NAME', 'dev_user_token');

define('MEICAI_AUTH_LOGIN_URL', MEICAI_AUTH_SSO_DOMAIN . '/user/login?system_key=' . MEICAI_SYSTEM_KEY);
define('MEICAI_AUTH_LOGOUT_URL', MEICAI_AUTH_SSO_DOMAIN . '/user/logout?system_key=' . MEICAI_SYSTEM_KEY);

define('SYSTEM_LOG_PATH', '/wnmp/log/');

//SERVICE
define('DEMO_SERVICE_URL', 'http://192.168.1.160:9010');

//NSQ
define("NSQ_SERVER_URL", 'http://192.168.1.6:4151/put');
