<?php

// This is the configuration for yiic console application.
// Any writable CConsoleApplication properties can be configured here.
return array(
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'../',
	'name'=>'My Console Application',

	// preloading 'log' component
	'preload'=>array('log'),
		'import'=>array(
				'application.components.*',
				'application.lib.helper.*',
				'application.app.*',
				'application.app.demo.*',
				'application.service.*',
				'application.service.demo.*',
				'application.service.ccenter.*',
				'application.service.ccenter.monitor.*',
				'application.service.ccenter.predict.*',
				'application.service.crontab.*',
				'ext.YiiMongoDbSuite.*',
				'application.models.*',
				'application.extensions.phpexcel.*'
		),
	// application components
	'components'=>array_merge(require dirname(__FILE__).'/db_mirror.php', array(
			
		/* 'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning',
				),
			),
		), */
		'log'=> require dirname(__FILE__).'/log.php',
	)),
);
