<?php
define('YII_LOG_DATE', date('Ymd'));
return array(
    'class'=>'CLogRouter',
    'routes'=>array(
        //system error log
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'error, warning',
            'logFile'       => 'system_error.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 1048576, //1G
        ),
        array(
            'class'         => 'CProfileLogRoute',
            'levels'        => 'error, warning,info,trace,profile',
        ),
        //system api access log
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'info',
            'categories'    => 'meicai.system.access.api.*',
            'logFile'       => 'system_access_api.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 1048576, //1G
        ),
        //system notice access log
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'info',
            'categories'    => 'meicai.system.access.notice.*',
            'logFile'       => 'system_access_notice.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 1048576, //1G
        ),
        //db sql log，debug时开启
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'trace,profile',
            'categories'    => 'system.db.*',
            'logFile'       => 'sql.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 1048576, //1G
        ),
        //db master & slaves sql log,使用主从debug时开启
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'info,error',
            'categories'    => 'meicai.system.db.master_salve.*',
            'logFile'       => 'master_salve_sql.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 1048576, //1G
        ),
        //mq access log
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'info',
            'categories'    => 'meicai.mq.access.*',
            'logFile'       => 'mq_access.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 10240, //10M
        ),
        //mq failed log
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'error',
            'categories'    => 'meicai.mq.failed.*',
            'logFile'       => 'mq_failed.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 10240, //10M
        ),
        //http api access log
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'info',
            'categories'    => 'meicai.http_api.access',
            'logFile'       => 'http_api.access.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 1048576, //1G
        ),
        //http api error log
        array(
            'class'         => 'CFileLogRoute',
            'levels'        => 'error',
            'categories'    => 'meicai.http_api.error.*',
            'logFile'       => 'http_api.error.' . YII_LOG_DATE . '.log',
            'logPath'       => SYSTEM_LOG_PATH,
            'maxFileSize'   => 1048576, //1G
        ),
        // uncomment the following to show log messages on web pages
        /*
        array(
            'class'=>'CWebLogRoute',
        ),
        */
    ),
);