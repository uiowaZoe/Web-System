<?php
require dirname(__FILE__) . '/define.php';

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
return array(
    'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..',
    'name'=>'Demo Api',

    // preloading 'log' component
    'preload'=>array('log'),

    // autoloading model and component classes
    'import'=>array(
    	'application.components.*',
        'application.lib.helper.*',
        'application.app.*',
        'application.app.demo.*',
        'application.service.*',
        'application.service.demo.*',
        'application.service.ccenter.*',
        'application.service.ccenter.monitor.*',
        'application.service.ccenter.predict.*',
        'application.service.crontab.*',
        'ext.YiiMongoDbSuite.*',
        'application.models.*',
        'application.extensions.PHPExcel.*'
    ),

    'modules'=>array(
    	// uncomment the following to enable the Gii tool

    	'gii'=>array(
    		'class'=>'system.gii.GiiModule',
    		'password'=>'Enter Your Password Here',
    		// If removed, Gii defaults to localhost only. Edit carefully to taste.
    		'ipFilters'=>array('127.0.0.1','::1'),
    	),

    ),

    // application components
    'components'=>array_merge(require dirname(__FILE__).'/db.php', array(
    	// uncomment the following to enable URLs in path-format
    	'urlManager'=>array(
    		'urlFormat'=>'path',
    		'rules'=>array(
    			'<controller:\w+>/<id:\d+>'=>'<controller>/view',
    			'<controller:\w+>/<action:\w+>/<id:\d+>'=>'<controller>/<action>',
    			'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
    		),
    	),
    	'errorHandler'=>array(
    		// use 'site/error' action to display errors
    		'errorAction'=>'site/error',
    	),
        'cache'=>array(
            'class' => 'CFileCache',
        ),
        'mongodb' => array(
            'class'            => 'EMongoDB',
            'connectionString' => 'mongodb://192.168.134.185:27017',
            'dbName'           => 'Mytest',
            'fsyncFlag'        => true,
            'safeFlag'         => true,
            'useCursor'        => false
        ),
        'log'=> require dirname(__FILE__).'/log.php',
    )),

    // application-level parameters that can be accessed
    // using Yii::app()->params['paramName']
    'params'=>array(
    ),
);
